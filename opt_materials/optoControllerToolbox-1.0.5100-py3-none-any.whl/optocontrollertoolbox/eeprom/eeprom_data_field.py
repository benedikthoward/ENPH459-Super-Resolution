# -*- coding: utf-8 -*-
"""
Created on Fri Oct 18 09:01:10 2019

@author: roman.patscheider
"""

from bitstring import pack
from bitstring import BitStream



class EEPROMDataField:
    """Class representing an encoded Data Field in an EEPROM Structure.
    EEPROM Structures are made up of Data Fields with their associated descriptions as well as Data Arrays.

    A Data Field is a fixed length binary representation of a value. This value
    can be one of the following data types:
    * integer (signed or unsigned)
    * float (16 or 32 bit representations)
    * string

    The conversion can include a linear transformation (offset and scaling):
    .. math::
        Value_{encoded} = (Value-offset)/scale
    """

    def __init__(self,
                 description,
                 format,
                 offset=0,
                 scale=1,
                 mapping=None):
        """Create a specific EEPROMDataField.

        Upon instantiation, the definition of the field has to be given. The content
        can be filled later.
        :param description: Description of the Data Field.
        :type description: str
        :param format: Format string that includes data type and length of the data field in EEPROM.
            Valid format strings are for example:
            ==========  ==================================================================
            str:n       n bits as whole byte ASCII string.
            map:n       n bits as string mapped to hex:n
            int:n	    n bits as a signed integer.
            uint:n	    n bits as an unsigned integer.
            intle:n	    n bits as a little-endian whole byte signed integer.
            uintle:n	n bits as a little-endian whole byte unsigned integer.
            floatle:n	n bits as a little-endian floating point number.
            hex:n	    n bits as a hexadecimal string.
            oct:n	    n bits as an octal string.
            bin:n	    n bits as a binary string.
            bits:n	    n bits as a new bitstring.
            bool	    single bit as a boolean (True or False).
            ==========  ==================================================================
            All format strings that the package :py:bitstring: supports can be used.
        :type format: str
        :param offset: Offset to be applied to value before encoding:
            :math:'Value_{encoded} = (Value-offset)/scale'
        :type offset: float
        :param scale: Factor to be applied to value before encoding:
            :math:'Value_{encoded} = (Value-offset)/scale'
        :type scale: float
        :param mapping: Dictionary, mapping hex keys to any hashable value
        :type mapping: dict
        """
        self.description = description
        self._format = format

        if ('str' in format or 'map' in format) and (offset != 0 or scale != 1):
            raise ValueError(f"offset and scale can not be applied to data_type {format}")
        self._offset = offset
        self._scale = scale
        self._value = None
        bit_length = int(self._format.split(':')[-1])
        self._bits = BitStream(uint=0, length=bit_length)
        if mapping is not None:
            self._map = mapping
            self._inv_map = {v: k for k, v in self._map.items()}

    @property
    def value(self):
        """The decoded value of the field.

        :getter: Returns the value of the EEPROMDataField or None if it has not been set.
        :setter: Sets EEPROMDataField Value and encodes it to the bits property
        :type: str or int or float
        """
        return self._value

    @value.setter
    def value(self, val):
        if 'str' in self._format:
            bit_length = int(self._format.split(':')[-1])
            self._bits = BitStream(bytes=val.encode('ASCII'), length=bit_length)
            self._value = val
        elif 'map' in self._format:
            bit_length = int(self._format.split(':')[-1])
            self._bits = BitStream(hex=self._inv_map[val])

            self._value = val
        else:
            encoded_value = int(round((val - self._offset) / self._scale))
            self._bits = pack(self._format, encoded_value)
            self._value = encoded_value * self._scale + self._offset

    @property
    def bits(self):
        """The encoded bitstring of the field.

        :getter: Returns a Bits object containing the binary representation of the EEPROMDataField.
        :setter: Sets EEPROMDataField Bits and decodes it to the value property
        :type: Bits
        """
        return self._bits

    @bits.setter
    def bits(self, bts):
        if 'str' in self._format:
            bit_length = int(self._format.split(':')[-1])
            self._value = bts.bytes.decode('ASCII')
            self._bits = bts
        elif 'map' in self._format:
            bit_length = int(self._format.split(':')[-1])
            hex_string='0x' + bts.read(bit_length).hex
            self._value = self._map.get(hex_string,hex_string)
            self._bits = bts
        else:
            encoded_value = bts.read(self._format)
            self._value = encoded_value * self._scale + self._offset
            self._bits = bts

    def append_to_stream(self,bitstream):
        """Appends _bits to the BitStream object.

        :param bitstream: BitStream object to which the EEPROMDataField should be appended.
        :type bitstream: BitStream
        """
        bitstream.append(self._bits)

    def read_from_stream(self, bitstream):
        """
        Reads the amount of bits specified in self._format from the current position in the BitStream object and
        sets them to self.bits.

        :param bitstream: BitStream object from which the EEPROMDataField should be parsed.
        :type bitstream: BitStream
        """
        bit_length = int(self._format.split(':')[-1])
        self.bits = bitstream.read(f'bits:{bit_length}')
