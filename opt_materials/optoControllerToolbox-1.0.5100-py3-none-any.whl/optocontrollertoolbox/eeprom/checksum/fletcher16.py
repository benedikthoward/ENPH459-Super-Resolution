def generateFletcherChecksum(byteArray):
    """Function to calculate Fletcher 16 checksum of a byte Array.
    For a definition of the Fletcher 16 checksum see the `Fletcher's checksum page on Wikipedia
    <https://en.wikipedia.org/wiki/Fletcher%27s_checksum#Example_calculation_of_the_Fletcher-16_checksum>`_ :

    :param byteArray: byte.
    :type byteArray: bytearray
    :returns:  int -- the checksum as an integer (uint16).

    """
    sum1, sum2 = 0, 0

    for byte in byteArray:
        sum1 = (sum1 + byte) % 0xFF
        sum2 = (sum1 + sum2) % 0xFF

    return (sum2 << 8) | sum1
