from .eeprom_data_field import EEPROMDataField
from .eeprom_data_array import EEPROMDataArray
from .eeprom_checksum_field import EEPROMChecksumField
from .eeprom_errors import ChecksumError
from bitstring import BitStream
from bitstring import Bits
from collections import OrderedDict
import warnings
from math import ceil


def value_access(name):
    """Function to expose a EEPROMDataField.value as a property.

    :param name: attribute name of the EEPROMDataField.
    :type index: str
    :returns:  property -- the property for accessing the attributes' value.

    """
    return property(lambda self: getattr(getattr(self, name),'value'),
                    lambda self, val: setattr(getattr(self, name), 'value', val))


class EEPROMDataStructure(object):
    """Abstract Class representing an EEPROM Data Structure.
    The standard attribute dictionary ``self.__dict__`` is overridden with an OrderedDict ``self.__odict__``.

    Classes inheriting from EEPROMDataStructure shall declare EEPROMDataField, EEPROMChecksumField and EEPROMDataArray
    properties and initialize them in the correct order::

        class ExampleDataStructure(EEPROMDataStructure):
            half_word1 = value_access('_half_word1')
            length = value_access('_length')
            start = value_access('_start')
            checksum = value_access('_checksum')
            def __init__(self):
                self._half_word1 = EEPROMDataField('Edge Table Data Half-Word 1', 'int:8')
                self._length = EEPROMDataField('Length of Data Sets', 'unt:8')
                self._start = EEPROMDataField('Start Address of Data Sets', 'unt:8')
                self._checksum = EEPROMChecksumField('Checksum', 'fletcher:16', end_checksum=True)
                # additional fields or arrays, not included in checksum:
                self.data_sets = EEPROMDataArray('Data Sets', AWGDataSet, self._length, self._start)

    Note that the __init__() function of EEPROMChecksumField expects a boolean argument end_checksum, specifying if the
    checksum covers all fields in front of (True) or after (False) the checksum field. Any fields/structures/arrays
    after an "end_checksum" or in front of a "start_checksum" will not be covered in the checksum calculation.
    The content of all the EEPROMChecksumField is automatically updated when calling ``append_to_stream()`` on the
    EEPROMDataStructure Object and checked when calling ``read_from_stream()``

    EEPROMDataArray objects will always keep the length EEPROMDataField up to date and shall not be manually set.
    Start fields can be manually set or automatically updated to the next byte aligned address by calling
    ``update_start_fields()`` on the main EEPROMDataStructure Object.

    If the EEPROMDataStructure start address is linked to a EEPROMDataField, the inheriting class can store the
    EEPROMDataField object reference to ``self._start_field``. If this attribute exists and is not None, it will be
    updated when ``update_start_fields()`` is called.
    If the EEPROMDataStructure needs to be located at a fixed start address, a ``self._start_address`` (type:int)
    attribute can be set.
    """

    def __new__(cls, *args, **kwargs):
        instance = object.__new__(cls)
        instance.__odict__ = OrderedDict()
        return instance

    def __setattr__(self, key, value):
        if key != '__odict__':
            self.__odict__[key] = value
        object.__setattr__(self, key, value)

    def keys(self):
        return self.__odict__.keys()

    def items(self):
        return self.__odict__.items()

    def __str__(self):
        output=''
        for key, value in self.items():
            if isinstance(value, EEPROMDataArray):
                for i in range(len(value)):
                    output += str(value[i])

            elif isinstance(value, EEPROMDataStructure):
                output += str(value)

            elif isinstance(value, EEPROMDataField) and key != '_start_field':
                output+=(f'{value.description}: {value.value}\n')
        return output

    def update_start_fields(self, bitstream=None):
        """Function to update all the start fields in the structure.
        uptade_start_fields is recursively called on all arrays and sub-structures.

        :param bitstream: the bitstream from which to calculate the start address.
            If None, an empty BitStream will be created.
        :type bitstream: BitStream

        """
        if bitstream is None:
            bitstream=BitStream()

        if hasattr(self,'_start_field') and self._start_field is not None:
            self._start_field.value= ceil(len(bitstream)/8)
            if self._start_field.value * 8 > len(bitstream):
                # add padding
                padding = self._start_field.value * 8 - len(bitstream)
                bitstream.append(Bits(uint=0, length=padding))
                warnings.warn(f'Updated Start field "{self._start_field.description}" and added {padding} bits of padding to advance to a byte aligned position')
        for key, obj in self.__odict__.items():
            if isinstance(obj, EEPROMDataField) and key != '_start_field':
                obj.append_to_stream(bitstream)
            elif isinstance(obj, (EEPROMDataArray, EEPROMDataStructure)):
                obj.update_start_fields(bitstream)

    '''
    def update_checksum_fields(self):
        """
            do not use anymore. this is now automatically done in append_to_stream()
        """
        for key, obj in self.__odict__.items():
            if isinstance(obj, EEPROMChecksumField):
                obj.update_checksum()
            elif isinstance(obj, EEPROMDataField):
                pass
            elif isinstance(obj, (EEPROMDataArray, EEPROMDataStructure)):
                obj.update_checksum_fields()
'''

    def append_to_stream(self, bitstream):
        """Function to append all fields, arrays and sub-structures to the bitstream.
        If a hard coded start address or a start field exists (``self._start_address`` or ``self._start_field``),
        padding is added if necessary. In that case a warning is issued.
        append_to_stream(bitstream) is then recursively called on all EEPROMDataField, EEPROMDataArray or
        EEPROMDataStructure Objects in ``self.__odict__``.

        :param bitstream: the bitstream to be built.
        :type bitstream: BitStream
        :raises: Exception

        """
        try:
            if hasattr(self,'_start_address'):
                assert self._start_address*8 == len(bitstream)
        except:
            padding=self._start_address*8-len(bitstream)
            if padding < 0:
                raise Exception(f'Hard coded start address of "{self}" '
                                f'(bitpos: {self._start_address*8}) is smaller than the current length of the '
                                f'BitStream object (bitpos: {len(bitstream)})')
            bitstream.append(Bits(uint=0,length=padding))
            warnings.warn(f'Added {padding} bits of padding to advance to the hard coded start address: {self._start_address}')
        try:
            if hasattr(self,'_start_field') and self._start_field is not None:
                assert self._start_field.value*8 == len(bitstream)
        except:
            padding=self._start_field.value*8-len(bitstream)
            if padding < 0:
                raise Exception(f'Start address in  "{self._start_field}" '
                                f'(bitpos: {self._start_field.value*8}) is smaller than the current length of the '
                                f'BitStream object (bitpos: {len(bitstream)})')
            bitstream.append(Bits(uint=0,length=padding))
            warnings.warn(f'Added {padding} bits of padding to advance to the position read from the start field "{self._start_field.description}"')

        # store the position in the stream for possible checksum calculation
        start_position = bitstream.length
        checksum_position = start_position
        checksum_obj = None

        for key, obj in self.__odict__.items():
            if isinstance(obj, EEPROMChecksumField):
                # checksum verification
                if obj.end_checksum:
                    # bitstream fully generated -> update field
                    end_position = bitstream.length
                    obj.update_checksum(bitstream[start_position:end_position])
                    obj.append_to_stream(bitstream)

                else:
                    # length not yet known -> update start position and remember checksum field object for updating
                    # later after appending of the rest of the structure to the stream.
                    checksum_position = bitstream.length
                    obj.append_to_stream(bitstream)
                    start_position = bitstream.length
                    checksum_obj = obj

            elif isinstance(obj, (EEPROMDataField, EEPROMDataArray, EEPROMDataStructure)) and key != '_start_field':
                obj.append_to_stream(bitstream)
        if checksum_obj is not None:
            # checksum was positioned at the start of the structure. update now.
            end_position = bitstream.length
            checksum_obj.update_checksum(bitstream[start_position:end_position])
            #update bits in bitstream
            bitstream.overwrite(checksum_obj.bits, checksum_position)


    def read_from_stream(self,bitstream):
        """Function to parse the bitstream.
        If a hard coded start address exists (``self._start_address``), the bitstream bytepos is updated to match it.
        The jumped bits will be ignored and a warning issued.
        read_from_stram(bitstream) is then recursively called on all EEPROMDataField, EEPROMDataArray or
        EEPROMDataStructure Objects in ``self.__odict__``.

        :param bitstream: the bitstream to be parsed.
        :type bitstream: BitStream
        :raises: Exception

        """
        # check if the pointer is at the start address, otherwise set it and issue a warning
        try:
            if hasattr(self,'_start_address'):
                assert bitstream.bytepos == self._start_field.value
        except:
            if self._start_address*8<bitstream.bitpos:
                raise Exception(f'Hard coded start position of "{self}" '
                                f'(bitpos: {self._start_address*8}) is smaller than the bit position in the '
                                f'BitStream object (bitpos: {bitstream.bitpos})')
            warnings.warn("Updating bitstream.bytepos to the value read from the hard coded start adress")
            bitstream.bytepos = self._start_address

        try:
            if hasattr(self,'_start_field') and self._start_field is not None:
                assert bitstream.bytepos == self._start_field.value
        except:
            if self._start_field.value*8<bitstream.bitpos:
                raise Exception(f'Decoded bit position from field "{self._start_field.description}" '
                                f'(bitpos: {self._start_field.value*8}) is smaller than the bit position in the '
                                f'BitStream object (bitpos: {bitstream.bitpos})')
            warnings.warn(f'Updating bitstream.bytepos to the value read from the start field "{self._start_field.description}"')
            bitstream.bytepos = self._start_field.value


        # store the position in the stream for possible checksum calculation
        start_position = bitstream.bitpos
        checksum_obj = None

        # run through objects in __odict__
        for key, obj in self.__odict__.items():
            if isinstance(obj, EEPROMChecksumField):
                # checksum verification
                if obj.end_checksum:
                    # length known -> run verification
                    end_position = bitstream.bitpos
                    obj.read_from_stream(bitstream)
                    if not obj.check_checksum(bitstream[start_position:end_position]):
                        raise ChecksumError(f'failed checksum check of {type(self)}')
                else:
                    # length not yet known -> update start position and remember checksum field object for check after
                    # parsing of the rest of the structure.
                    obj.read_from_stream(bitstream)
                    start_position = bitstream.bitpos
                    checksum_obj = obj

            elif isinstance(obj, (EEPROMDataField, EEPROMDataArray, EEPROMDataStructure)) and key !='_start_field':
                obj.read_from_stream(bitstream)
        if checksum_obj is not None:
            # checksum was positioned at the start of the structure. run check now.
            end_position = bitstream.bitpos
            if not checksum_obj.check_checksum(bitstream[start_position:end_position]):
                print(f'failed checksum of {type(self)}')

    def generate_stream(self):
        # returns structure as a new stream (with all its start fields numbered relatively to start of this structure)
        self.update_start_fields()
        bs = BitStream()
        bs.pos = 0
        self.append_to_stream(bs)
        return bs

