# -*- coding: utf-8 -*-
"""
Created on Fri Oct 31 09:01:10 2019

@author: roman.patscheider
"""
from collections.abc import Sequence
from bitstring import Bits
from math import ceil
import warnings


class EEPROMDataArray(Sequence):
    """Class representing a list of EEPROMDataStructure objects of a given child class.

    A EEPROMDataArray accepts an EEPROMDataField Object that encodes the number of repetitions as an integer data type
    and will update its value to reflect the length of the list. Optionally it also accepts an EEPROMDataField Object
    that encodes the start address of the Array as an integer data type. update_start_fields(self, bitstream) needs
    to be called to update this value to reflect the current position in the BitStream object.
    """

    def __init__(self,
                 description,
                 sub_structure,
                 repetitions_field,
                 start_field = None
                 ):
        """Create a specific EEPROMDataArray.

        Upon instantiation, the definition of the field has to be given. The content
        can be filled later.

        :param description: Description of the Data Array.
        :type description: str
        :param sub_structure: EEPROMDataStructure Class reference that will be repeated in the array
        :type sub_structure: class
        :param repetitions_field: EEPROMDataField containing the number of repetitions
        :type repetitions_field: EEPROMDataField
        :param start_field: EEPROMDataField containing the start address of the array
        :type start_field: EEPROMDataField

        """
        self.description = description
        self._repetitions_field = repetitions_field
        self._repetitions_field.value=0
        self._start_field = start_field
        if self._start_field is not None:
            self._start_field.value=0
        self._sub_structure = sub_structure
        self._array=[]

    def __getitem__(self,index):
        """Function to get a list item.

        :param index: the index of the list item to return.
        :type index: int
        :returns:  EEPROMDataStructure -- the item in the list based on the index given.
        :raises: ValueError

        """
        return self._array[index]

    def __setitem__(self, key, value):
        """Function to set a list item.

        :param key: the index of the list item to set.
        :type key: int
        :param value: the object to set to the list at the index given.
        :type value: EEPROMDataStructure
        :raises: ValueError

        """
        if not isinstance(value, self._sub_structure):
            raise ValueError(f'Only {self._sub_structure} objects are accepted')
        else:
            self._array[key]=value

    def __len__(self):
        return len(self._array)

    def append(self,value):
        """Function to append a item to the list.
        Updates the repetitions field.

        :param value: the object to append to the list.
        :type value: EEPROMDataStructure
        :raises: ValueError

        """
        if not isinstance(value, self._sub_structure):
            raise ValueError(f'Only {self._sub_structure} objects are accepted')
        else:
            self._array.append(value)
            self._repetitions_field.value = len(self._array)

    def update_start_fields(self,bitstream):
        """Function to update the start field of the array, if it exists.
        The current bit position of the bitstream is rounded up to the next byte address, which is written to the
        start field. uptade_start_fields is then recursively called on all sub-structures in the array.

        :param bitstream: the bitstream from which to calculate the start address.
        :type bitstream: BitStream
        :raises: ValueError

        """
        if self._start_field is not None:
            self._start_field.value= ceil(len(bitstream)/8)
            #print(f'updating start field to {self._start_field.value}')
            if self._start_field.value * 8 > len(bitstream):
                # add padding
                padding = self._start_field.value * 8 - len(bitstream)
                bitstream.append(Bits(uint=0, length=padding))
                warnings.warn(f'Added {padding} bits of padding to advance to a byte aligned position')
        for sub_structure in self._array:
            sub_structure.update_start_fields(bitstream)

    def update_checksum_fields(self):
        """Recursively calls the functions to update the checksum fields in the sub structures.
        """
        for sub_structure in self._array:
            sub_structure.update_checksum_fields()

    def append_to_stream(self,bitstream):
        """Function to append the sub-structures' fields to the bitstream.
        Padding is added if necessary based on the start field content. In that case a warning is issued.
        append_to_stream(bitstream) is then recursively called on all sub-structures in the array.

        :param bitstream: the bitstream to be built.
        :type bitstream: BitStream
        :raises: Exception

        """
        # add padding if necessary
        try:
            assert self._start_field is None or self._start_field.value*8 == len(bitstream)
        except:
            padding=self._start_field.value*8-len(bitstream)
            if padding < 0:
                raise Exception(f'Decoded bit position from field "{self._start_field.description}" '
                                f'(bitpos: {self._start_field.value*8}) is smaller than the current length of the '
                                f'BitStream object (bitpos: {len(bitstream)})')
            bitstream.append(Bits(uint=0,length=padding))
            warnings.warn(f'Added {padding} bits of padding to advance to the position read from the start field')

        for sub_structure in self._array:
            sub_structure.append_to_stream(bitstream)

    def read_from_stream(self, bitstream):
        """Function to parse the bitstream.
        The bitstream bytepos is updated to match the start field content. The jumped bits will be ignored and a
        warning issued.
        read_from_stram(bitstream) is then recursively called on all sub-structures in the array.

        :param bitstream: the bitstream to be parsed.
        :type bitstream: BitStream
        :raises: Exception

        """
        # clear all content
        self._array=[]
        # check if the pointer is at the start address, otherwise set it and issue a warning
        try:
            assert self._start_field is None or bitstream.bytepos == self._start_field.value
        except:
            if self._start_field.value*8<bitstream.bitpos:
                raise Exception(f'Decoded bit position from field "{self._start_field.description}" '
                                f'(bitpos: {self._start_field.value*8}) is smaller than the bit position in the '
                                f'BitStream object (bitpos: {bitstream.bitpos})')
            warnings.warn("Updating bitstream.bytepos to the value read from the start field")
            bitstream.bytepos = self._start_field.value

        # initialize and populate the substructures
        for i in range(self._repetitions_field.value):
            self._array.append(self._sub_structure())
            self._array[i].read_from_stream(bitstream)


