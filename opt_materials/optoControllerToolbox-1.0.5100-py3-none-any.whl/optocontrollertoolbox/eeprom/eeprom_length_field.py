# -*- coding: utf-8 -*-
"""
Created on Fri Oct 18 09:01:10 2019

@author: roman.patscheider
"""

from bitstring import pack
from bitstring import BitStream
from .eeprom_data_field import EEPROMDataField


class EEPROMLengthField(EEPROMDataField):
    """Class representing an encoded Data Field storing an Array length in an EEPROM Structure.

    Differes from EEPROMDataField in the following way:
    The _bits property does not get set when setting a value, but only when appending the bits to a stream.
    Is initialized to 0 instead None

    """
    def __init__(self,
                 description,
                 format,
                 offset=0,
                 scale=1,
                 mapping=None):
        super(EEPROMLengthField, self).__init__(description=description, format=format, offset=offset, scale=scale,
                                                mapping=mapping)

        self.value = 0  # since it is counter, initialize it as zero instead of None

    @property
    def value(self):
        """The decoded value of the field.

        :getter: Returns the value of the EEPROMDataField or None if it has not been set.
        :setter: Sets EEPROMDataField Value
        :type: str or int or float
        """
        return self._value

    @value.setter
    def value(self, val):
        # length fields need to be numeric type:
        self._value = val

    def append_to_stream(self,bitstream):
        """Encodes the value to _bits and appends _bits to the BitStream object.

        :param bitstream: BitStream object to which the EEPROMDataField should be appended.
        :type bitstream: BitStream
        """
        encoded_value = int(round((self._value - self._offset) / self._scale))
        self._bits = pack(self._format, encoded_value)
        bitstream.append(self._bits)


