from .eeprom_data_structure import *
from .eeprom_data_field import EEPROMDataField
from .eeprom_data_array import EEPROMDataArray
from .eeprom_checksum_field import EEPROMChecksumField


class EEPROMDataStructureTI(EEPROMDataStructure):
    manufacturer_id = value_access('_manufacturer_id')
    model_number = value_access('_model_number')
    revision = value_access('_revision')
    config_reg = value_access('_config_reg')
    reserved1 = value_access('_reserved1')
    temperature = value_access('_temperature')
    status = value_access('_status')
    data_set_start = value_access('_data_set_start')
    num_data_sets = value_access('_num_data_sets')
    edge_table_start = value_access('_edge_table_start')
    num_edge_tables = value_access('_num_edge_tables')
    reserved2 = value_access('_reserved2')
    checksum = value_access('_checksum')

    def __init__(self):
        self._manufacturer_id=EEPROMDataField('Manufacturer ID', 'uintle:16')
        self._model_number=EEPROMDataField('Model Number', 'uintle:16')
        self._revision = EEPROMDataField('Revision', 'uintle:16')
        self._config_reg=EEPROMDataField('Configuration Register', 'uintle:16')
        self._reserved1 = EEPROMDataField('Reserved_1','uintle:16')
        self._temperature = EEPROMDataField('Temperature Register', 'uintle:16')
        self._status = EEPROMDataField('Status Register', 'uintle:32')
        self._data_set_start = EEPROMDataField('AWG Data Set Start', 'uintle:16')
        self._num_data_sets = EEPROMDataField('Number of AWG Data Sets', 'uintle:16')
        self._edge_table_start = EEPROMDataField('AWG Edge Table Start', 'uintle:16')
        self._num_edge_tables = EEPROMDataField('Number of AWG Edge Tables', 'uintle:16')
        self._reserved2 = EEPROMDataField('Reserved_2', 'uintle:48')
        self._checksum = EEPROMChecksumField('Checksum', 'fletcher:16', end_checksum=True,  big_endian=False)
        # additional arrays, not included in checksum:
        self.data_sets=EEPROMDataArray('AWG Data Sets', AWGDataSet, self._num_data_sets, self._data_set_start)
        self.edge_tables = EEPROMDataArray('AWG Edge Tables', AWGEdgeTable, self._num_edge_tables,
                                           self._edge_table_start)
        self.optotune_data = OptotuneData()


class AWGDataSet(EEPROMDataStructure):

    awc_number = value_access('_awc_number')
    frame_rate = value_access('_frame_rate')
    temperature = value_access('_temperature')
    reserved1 = value_access('_reserved1')
    output_select = value_access('_output_select')
    clock_width = value_access('_clock_width')
    fixed_output_value = value_access('_fixed_output_value')
    dac_gain = value_access('_dac_gain')
    dac_offset = value_access('_dac_offset')
    ramp_length = value_access('_ramp_length')
    segment_length = value_access('_segment_length')
    inv_pwm_a = value_access('_inv_pwm_a')
    inv_pwm_b = value_access('_inv_pwm_b')
    subframe_filter = value_access('_subframe_filter')
    reserved2 = value_access('_reserved2')
    subframe_delay = value_access('_subframe_delay')
    subframe_watchdog = value_access('_subframe_watchdog')
    reserved3 = value_access('_reserved3')
    checksum = value_access('_checksum')

    def __init__(self):
        self._awc_number=EEPROMDataField('AWC #', 'map:8',mapping={'0x00': 'Axis 0','0x01':'Axis 1'})
        self._frame_rate = EEPROMDataField('Frame Rate','map:8', mapping={'0x32':'50 Hz', '0x3C':'60 Hz'}) # kept mapping data type for concistency with AWGEdgeTable field
        self._temperature = EEPROMDataField('Temperature [deg C]', 'uintle:16')
        self._reserved1 = EEPROMDataField('Reserved_1', 'uintle:32')
        self._output_select = EEPROMDataField('Output Select', 'map:8', mapping={'0x00':'DAC', '0x01':'PWM'})
        self._clock_width = EEPROMDataField('Clock Width [ns]', 'uint:8', 40, 40)
        self._fixed_output_value = EEPROMDataField('Fixed Output Value', 'uint:8')
        self._dac_gain = EEPROMDataField('DAC Gain', 'uint:8', 0, 1/128)
        self._dac_offset = EEPROMDataField('DAC Offset', 'int:8') #todo: doublecheck with structure definition
        self._ramp_length = EEPROMDataField('Ramp Length', 'uint:8')
        self._segment_length = EEPROMDataField('Segment Length', 'uintle:16')
        self._inv_pwm_a =EEPROMDataField('Invert PWM A', 'map:8', mapping={'0x00':'not inverted', '0x01':'inverted'})
        self._inv_pwm_b = EEPROMDataField('Invert PWM B', 'map:8', mapping={'0x00': 'not inverted', '0x01': 'inverted'})
        self._subframe_filter = EEPROMDataField('Subframe Filter Value [us]', 'uint:8', 0, 60)
        self._reserved2 = EEPROMDataField('Reserved_2', 'uint:8')
        self._subframe_delay = EEPROMDataField('Subframe Delay Value [ns]', 'uintle:32', 0, 20)
        self._subframe_watchdog = EEPROMDataField('Subframe Watchdog [us]', 'uintle:16', 0, 60)
        self._reserved3 = EEPROMDataField('Reserved_3', 'uintle:32')
        self._checksum = EEPROMChecksumField('Checksum', 'fletcher:16', end_checksum=True, big_endian=False)


class AWGEdgeTable(EEPROMDataStructure):
    awc_number = value_access('_awc_number')
    frame_rate = value_access('_frame_rate')
    temperature = value_access('_temperature')
    type = value_access('_type')
    edge_table_word_size = value_access('_edge_table_word_size')
    reserved1 = value_access('_reserved1')
    edge_table_length = value_access('_edge_table_length')
    checksum = value_access('_checksum')

    def __init__(self):
        self._awc_number = EEPROMDataField('AWC #', 'map:8', mapping={'0x00': 'Axis 0', '0x01': 'Axis 1'})
        self._frame_rate = EEPROMDataField('Frame Rate', 'map:8', mapping={'0x32':'50 Hz', '0x3C':'60 Hz'})
        self._temperature = EEPROMDataField('Temperature [deg C]', 'uintle:16')
        self._type = EEPROMDataField('Type', 'map:8', mapping={'0x00': 'Uncompressed', '0x01': 'Compressed'})
        self._edge_table_word_size = EEPROMDataField('Edge Table Word Size',
                                                     'map:8',
                                                     mapping={'0x01': '1 byte', '0x02': '2 bytes'}) #not linked to Edge Table Entry Format
        self._reserved1 = EEPROMDataField('Reserved_1', 'uintle:48')
        self._edge_table_length = EEPROMDataField('Edge Table Length', 'uintle:16')
        self.edge_table_data = EEPROMDataArray('Edge Table Data', AWGEdgeTableEntry,self._edge_table_length)
        self._checksum = EEPROMChecksumField('Checksum', 'fletcher:16', end_checksum=True, big_endian=False)


class AWGEdgeTableEntry(EEPROMDataStructure):
    half_word1 = value_access('_half_word1')
    half_word2 = value_access('_half_word2')
    def __init__(self):
        self._half_word1 = EEPROMDataField('Edge Table Data Half-Word 1', 'int:8')
        self._half_word2 = EEPROMDataField('Edge Table Data Half-Word 2', 'int:8')


class OptotuneData(EEPROMDataStructure):
    reserved = value_access('_reserved')
    version = value_access('_version')
    serial_number = value_access('_serial_number')
    oqc_result = value_access('_oqc_result')
    nominal_t75_transition = value_access('_nominal_t75_transition')
    nominal_displacement = value_access('_nominal_displacement')
    sam_thermal_coefficient = value_access('_sam_thermal_coefficient')
    rfm_thermal_coefficient = value_access('_rfm_thermal_coefficient')
    waveform_order = value_access('_waveform_order')
    axis0_sam = value_access('_axis0_sam')
    axis0_rfm = value_access('_axis0_rfm')
    axis0_qfactor = value_access('_axis0_qfactor')
    axis1_sam = value_access('_axis1_sam')
    axis1_rfm = value_access('_axis1_rfm')
    axis1_qfactor = value_access('_axis1_qfactor')
    checksum = value_access('_checksum')

    def __init__(self):
        self._start_address = 4448

        self._reserved = EEPROMDataField('Reserved', 'uint:24')
        self._version = EEPROMDataField('Version', 'uint:8')
        self._serial_number = EEPROMDataField('Serial Number', 'str:64')
        self._oqc_result = EEPROMDataField('OQC result', 'map:8',mapping={'0x00': 'Fail', '0x01':'Pass'})
        self._nominal_t75_transition = EEPROMDataField('Nominal T75 transition [us]', 'uint:8', 500, 10)
        self._nominal_displacement = EEPROMDataField('Nominal Displacement [deg]', 'uint:8', 0, 0.005)
        self._sam_thermal_coefficient = EEPROMDataField('SAM thermal coefficient [%/100degC]','int:8', 0, 1/5)
        self._rfm_thermal_coefficient = EEPROMDataField('RFM thermal coefficient [%/100degC]','int:8', 0, 1/5)
        self._waveform_order = EEPROMDataField('Waveform order]','int:8')
        self._axis0_sam = EEPROMDataField('Axis 0 SAM', 'uint:16', 0, 1/1000)
        self._axis0_rfm = EEPROMDataField('Axis 0 RFM', 'uintle:16', 0, 1/250)
        self._axis0_qfactor = EEPROMDataField('Axis 0 Q-Factor', 'uint:16', 0, 1/100)
        self._axis1_sam = EEPROMDataField('Axis 1 SAM', 'uint:16', 0, 1/1000)
        self._axis1_rfm = EEPROMDataField('Axis 1 RFM', 'uintle:16', 0, 1/250)
        self._axis1_qfactor = EEPROMDataField('Axis 1 Q-Factor', 'uint:16', 0, 1/100)
        self._checksum = EEPROMChecksumField('Checksum', 'fletcher:16', end_checksum=True, big_endian=False)