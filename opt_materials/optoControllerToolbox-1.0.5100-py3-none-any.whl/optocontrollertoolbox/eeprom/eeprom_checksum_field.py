# -*- coding: utf-8 -*-
"""
Created on Wed Nov 6 09:01:10 2019

@author: roman.patscheider
"""
from bitstring import BitStream
from .eeprom_data_field import EEPROMDataField
from .checksum.fletcher16 import generateFletcherChecksum
from .checksum.crc_ccitt import CRCCCITT


class EEPROMChecksumField(EEPROMDataField):
    """Class representing a checksum Data Field in an EEPROM Structure.

    A Checksum Field is a fixed length binary representation of a defined checksum. Implemented Checksum algorithms are:
    * Fletcher 16 (see :mod:optoUtil.checksum.fletcher16)
    * CRC CCIT

    """
    def __init__(self, description, format, end_checksum=True, big_endian = True, *args, **kwargs):
        """Create a Checksum Field.

        Upon instantiation, the definition of the field has to be given. The content
        can be filled later.
        :param description: Description of the Data Field.
        :type description: str
        :param format: Format string that includes checksum type and length of the data field in EEPROM.
            Valid checksum format strings are:
            ==============  ==================================================================
            fletcher:16     16 bit fletcher checksum.
            crc_ccitt:8     8 bit CRC CCITT (polynomial 0x07, initial value 0xFF)
            crc_ccitt:16    16bit CRC CCITT (polynomial 0x1021, initial value 0xFFFF)
            ==============  ==================================================================
        :type data_type: str
        :param odict: Ordered Dictionary containing all EEPROMDataField, EEPROMDataArray or EEPROMDataStructure
            Objects over which the checksum shall be calculated
        :type odict: OrderedDict
        :raises: ValueError
        """

        self.end_checksum = end_checksum
        self.big_endian = big_endian
        if 'fletcher:16' in format:
            self._calculate_checksum=self._calculate_checksum_fletcher16
            format='bits:16'
        elif 'crc_ccitt:8' in format:
            self._calculate_checksum = self._calculate_checksum_crc_ccitt
            format = 'bits:8'
        elif 'crc_ccitt:16' in format:
            self._calculate_checksum=self._calculate_checksum_crc_ccitt
            format='bits:16'
        else:
            raise ValueError(f'Unknown Checksum: {format}.')
        super().__init__(description, format,*args, **kwargs)

    def update_checksum(self, bitstream):
        """Build the bitstream from the objects in ``self._odict`` and calculate the checksum.
        """

        self._bits = self._calculate_checksum(bitstream)
        self._value = self._bits

    def check_checksum(self, bitstream):
        """calculate the checksum over bitstream and validate against self._value.
        """

        return self._value == self._calculate_checksum(bitstream)

    def _calculate_checksum_fletcher16(self,bitstream):
        """Calculates the fletcher 16 checksum and returns the BitStream.

        :param bitstream: BitStream over which the checksum needs to be calculated
        :type bitstream: BitStream
        :returns: BitStream -- the checksum as a BitStream object
        """
        byte_array=bitstream.bytes
        if self.big_endian:
            return BitStream(uintbe=generateFletcherChecksum(byte_array), length=16)
        else:
            return BitStream(uintle=generateFletcherChecksum(byte_array), length=16)

    def _calculate_checksum_crc_ccitt(self,bitstream):
        """Calculates the crc checksum for the right bitsize and returns the BitStream.

        :param bitstream: BitStream over which the checksum needs to be calculated
        :type bitstream: BitStream
        :returns: BitStream -- the checksum as a BitStream object
        """
        bitsize = int(self._format.split(':')[-1])
        byte_array = bitstream.bytes
        crcgen=CRCCCITT(bitsize)
        if self.big_endian:
            return BitStream(uintbe=crcgen.calculateCRC(byte_array), length=bitsize)
        else:
            return BitStream(uintle=crcgen.calculateCRC(byte_array), length=bitsize)


