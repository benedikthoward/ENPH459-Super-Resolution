from optoICC.icc4c import ICC4cBoard


from .SmartFilterFunctions import gen_filters, set_filters_channel, get_eeprom_data_ti, PlantParam, \
    FilterSystemParam, FilterType


class SmartFilterSystem:

    def __init__(self, controller=None, channel=0, plant: PlantParam = None, fs=20e3):
        self.controller: ICC4cBoard = controller  # ICC4cBoard or compatible
        self.channel = channel
        self.plant: PlantParam = plant
        self.fs = fs
        self.filter_type = FilterType.IDEAL
        self.transition_time = 1.2e-3
        self.disable_smoothing = False

    def set_plant_parameters(self, plant: PlantParam) -> None:
        self.plant: PlantParam = plant

    # make enum for filter type
    def calculate_filter_coefficients(self) -> FilterSystemParam:

        filter_units = gen_filters(self.plant.gain, self.plant.fr, self.plant.q, fs=self.fs,
                                  filter_type=self.filter_type, transition_time=self.transition_time,
                                  disable_smoothing=self.disable_smoothing)

        return FilterSystemParam(filter_units)

    def configure_filter_coefficients(self, filter_system_param: FilterSystemParam) -> None:
        set_filters_channel(self.controller, self.channel, filter_system_param.filter_units, activate_filters=True)

    def switch_off(self) -> None:
        self.controller.channel[self.channel].OutputConditioningFilter.SetActiveFiltersMask(0)

    def switch_on(self) -> None:
        self.controller.channel[self.channel].OutputConditioningFilter.SetActiveFiltersMask(2 ** 2 - 1)


class SmartFilters:

    def __init__(self, controller=None):
        self.filter_type = FilterType.IDEAL
        self.transition_time = 1.2e-3
        self.disable_smoothing = False
        self.fs = 20e3
        self.controller = controller
        self.channels = [0, 1]
        self._smart_filters = []

    def _get_plant_parameters_from_eeprom(self, channel: int) -> PlantParam:
        data = get_eeprom_data_ti(self.controller)
        return PlantParam(gain=data['sams'][channel], fr=data['resonant_frequencies'][channel], q=data['q_factors'][channel])

    def configure_filters(self) -> None:
        self._smart_filters = []
        for ch in self.channels:
            plant = self._get_plant_parameters_from_eeprom(ch)
            smart_filter = SmartFilterSystem(controller=self.controller, channel=ch, plant=plant, fs=self.fs)
            smart_filter.transition_time = self.transition_time
            smart_filter.configure_filter_coefficients(filter_system_param=smart_filter.calculate_filter_coefficients())
            self._smart_filters.append(smart_filter)

    def switch_off(self) -> None:
        for smart_filter in self._smart_filters:
            smart_filter.switch_off()

    def switch_on(self) -> None:
        for smart_filter in self._smart_filters:
            smart_filter.switch_on()
