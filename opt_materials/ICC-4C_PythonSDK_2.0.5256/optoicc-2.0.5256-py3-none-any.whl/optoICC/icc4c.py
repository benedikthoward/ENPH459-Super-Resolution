# -*- coding: utf-8 -*-
from ._connections import Board as _Board, Channel as _Channel
from .registers import icc_registers as Registers
from .registers import boardEEPROM_registers as BoardEEPROMRegisters
from .tools.definitions import UnitType, DevicePlatform
from .tools.list_comports import get_icc4c_port

"""ICC-4c SDK.

The ICC-4c SDK is organized in the following way:

         Board.Channel.System.RegisterCommand(parameters)

  Board:      Low/mid level object for operating the firmware (vector patterns, simple/pro commands, etc)
  Channel:    A given channel, which can set input types, gain, etc.
  System:     Each channel has its own stages. From here can perform commands that get/set individual registers.
  registers:  Each system has several registers, which are dictionaries with elements regarding valid units/range.


To begin:
Import necessary module and initialize a board (verbose for console output)

>>>import optoICC4c
>>>icc4c = optoICC4c.connect4(port='COM12')  # this will connect and synchronize all channel with the firmware

Define the system you want to interact with (board.mirror.channel.system) (see registers.system_names for a list)
>>>sig_gen = icc4c.Mirror.Channel_0.SignalGenerator
Start setting individual registers
>>>sig_gen.SetAmplitude(0.1)

Additional operations are available directly through the Board object (get/set multiple, reset, etc)
For example, multiple set/get can be done. After this, the system will output a sinusoid on channel 0.
>>>icc4c.set_value([sig_gen.frequency, sig_gen.amplitude, sig_gen.unit, sig_gen.run], [10.0, 0.1, Units.CURRENT, 1])
>>>icc4c.get_value([sig_gen.frequency, sig_gen.amplitude, sig_gen.unit, sig_gen.run])

Example
-------
More examples to come...
"""


# standard ICC-4c Board
## Parent class => \link optoKummenberg.connections.Board Board\endlink <br>
class ICC4cBoard(_Board):
    r"""
        Board object from which to issue ICC-4C commands over a serial connection.

        Parameters
        ----------
        port, baudrate, comm_lock, verbose
        Standard serial connection parameters. Extended from Connection class.
        simple: bool, optional = False
        Determines whether or not Board will be set in simple-mode after initialization.
        board_reset: bool, optional = False
        Determines whether or not to reset the Board during initialization.
        Raises
        ------
        none

        Notes
        -----
        Board extends Connection class. Refer to Connection for methods, parameters, etc.
        Board inherits Commands. Refer to Commands for methods, parameters, etc.
    """
    def __init__(self, port: str or None = None, baudrate: int = 256000, comm_lock: bool = True,
                 verbose: bool = False, simple: bool = False, board_reset: bool = False,
                 inter_byte_timeout: float = 0.2, device_platform=DevicePlatform.ALL,
                 ip_address: str = None, ethernet_port: int = 5000):

        # Determine actual port
        if not ip_address and port is None:
            try:
                port = get_icc4c_port()
            except IndexError:
                print("ICC-4c Device Not Found. Serial port connection failed.")

        _Board.__init__(self, port=port,
                            baudrate=baudrate,
                            comm_lock=comm_lock,
                            verbose=verbose,
                            simple=simple,
                            inter_byte_timeout=inter_byte_timeout,
                            simulated=False,
                            ethernet=ip_address is not None,
                            ip_address=ip_address,
                            ethernet_port=ethernet_port)
        # board-level systems
        ## => \link optoICC.registers.icc_registers.ICCStatus ICCStatus\endlink
        self.Status = Registers.ICCStatus(board=self)
        ## => \link optoICC.registers.icc_registers.ICCTemperatureManager ICCTemperatureManager\endlink
        self.TemperatureManager = Registers.ICCTemperatureManager(board=self)
        ## => \link optoICC.registers.icc_registers.ICCMiscFeatures ICCMiscFeatures\endlink
        self.MiscFeatures = Registers.ICCMiscFeatures(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.Logger Logger\endlink
        self.Logger = Registers.Logger(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.SnapshotManager SnapshotManager\endlink
        self.SnapshotManager = Registers.SnapshotManager(board=self)

        # channel-level systems
        ## => \link optoICC.icc4c.ICC4cChannel ICC4cChannel\endlink
        self.Channel_0 = ICC4cChannel(self, 0, device_platform)
        ## => \link optoICC.icc4c.ICC4cChannel ICC4cChannel\endlink
        self.Channel_1 = ICC4cChannel(self, 1, device_platform)
        ## => \link optoICC.icc4c.ICC4cChannel ICC4cChannel\endlink
        self.Channel_2 = ICC4cChannel(self, 2, device_platform)
        ## => \link optoICC.icc4c.ICC4cChannel ICC4cChannel\endlink
        self.Channel_3 = ICC4cChannel(self, 3, device_platform)
        ## all available channels array of type
        ## => \link optoICC.icc4c.ICC4cChannel ICC4cChannel\endlink
        self.channel = [self.Channel_0, self.Channel_1, self.Channel_2, self.Channel_3]

        ## => \link optoICC.registers.icc_registers.ICCBoardEEPROM ICCBoardEEPROM\endlink
        self.EEPROM = BoardEEPROMRegisters.ICC4cBoardEEPROM(board=self)

        ## => \link optoKummenberg.registers.SignalFlowManager.SignalFlowManager SignalFlowManager\endlink
        self.SignalFlowManager = Registers.SignalFlowManager(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.VectorPatternMemory VectorPatternMemory\endlink
        self.VectorPatternMemory = Registers.VectorPatternMemory(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.ADCcontrol ADCcontrol\endlink
        self.ADCcontrol = Registers.ADCcontrol(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.DACcontrol DACcontrol\endlink
        self.DACcontrol = Registers.DACcontrol(board=self)
        ## => \link optoKummenberg.registers.SmartStepManager SmartStepManager\endlink
        self.SmartStep = Registers.SmartStepManager(board=self)
        ## => \link optoICC.registers.MiscSystems.XPRControl XPRControl\endlink
        self.XPRControl = Registers.XPRControl(board=self)

        if device_platform == DevicePlatform.ALL:
            ## => \link optoICC.registers.icc_registers.InertialMeasurementUnit InertialMeasurementUnit\endlink
            self.InertialMeasurementUnit = Registers.InertialMeasurementUnit(board=self)
            ## => \link optoICC.registers.icc_registers.SarynControl SarynControl\endlink
            self.SarynControl = Registers.SarynControl(board=self)

## Parent class => \link optoKummenberg.connections.Channel Channel\endlink <br>
class ICC4cChannel(_Channel):
    r"""
        Class to control single channel of the ICC-4C driver. It contains systems supported on specific channel.
    """
    def __init__(self, board, channel_number: int = 0, device_platform=DevicePlatform.ALL):
        _Channel.__init__(self, board, channel_number)

        if device_platform == DevicePlatform.ALL or device_platform == DevicePlatform.LENS:
            ## Based on device_platform <br>
            ## ALL/LENS => \link optoICC.registers.icc_registers.ICCStaticInput ICCStaticInput\endlink <br>
            ## XPR => \link optoKummenberg.registers.InputStage.StaticInput StaticInput\endlink
            self.StaticInput = Registers.ICCStaticInput(self._channel, self._board)
            ## Only available for device_platform =  ALL || LENS <br>
            ## => \link optoICC.registers.icc_registers.LensCompensation LensCompensation\endlink
            self.LensCompensation = Registers.LensCompensation(self._channel, self._board)
        if device_platform == DevicePlatform.XPR:
            self.StaticInput = Registers.StaticInput(self._channel, self._board)

        ## => \link optoKummenberg.registers.InputStage.Analog Analog\endlink
        self.Analog = Registers.Analog(self._channel, self._board)
        ## => \link optoKummenberg.registers.InputStage.SignalGenerator SignalGenerator\endlink
        self.SignalGenerator = Registers.ICCSignalGenerator(self._channel, self._board)
        ## => \link optoICC.registers.icc_registers.DeviceEEPROM DeviceEEPROM\endlink
        self.DeviceEEPROM = Registers.DeviceEEPROM(self._channel, self._board)
        ## => \link optoKummenberg.registers.InputStage.VectorPatternUnit VectorPatternUnit\endlink
        self.VectorPatternUnit = Registers.VectorPatternUnit(self._channel, self._board)
        ## => \link optoICC.registers.icc_registers.ICCDeviceTemperatureManager ICCDeviceTemperatureManager\endlink
        self.TemperatureManager = Registers.ICCDeviceTemperatureManager(self._channel, self._board)
        ## => \link optoKummenberg.registers.OutputConditioning.OutputConditioningFilter OutputConditioningFilter\endlink
        self.OutputConditioningFilter = Registers.OutputConditioningFilter(self._channel, self._board)


    def GetControlMode(self):
        r"""
        Retrieves board control mode for this channel.

        Parameters
        ----------

        Raises
        ------
        none

        Returns
        -----
        UnitType
            Control mode options set by register_tables.UnitType

        """
        response = self.Manager.get_register('control')

        if response == 0xB0 | self._channel:  # Feed Through Control Mode
            self._control_mode = UnitType.CURRENT
            return self._control_mode

        if response == 0xC8 | self._channel:  # Focal Power Control Mode
            self._control_mode = UnitType.FP
            return self._control_mode
