# -*- coding: utf-8 -*-
from ._connections import Board as _Board, Channel as _Channel
from .registers import icc_registers as Registers
from .registers import boardEEPROM_registers as BoardEEPROMRegisters
from .tools.list_comports import get_icc4c_port

"""ICC-1c SDK.

The ICC-1c SDK is organized in the following way:

         Board.Channel.System.RegisterCommand(parameters)

  Board:      Low/mid level object for operating the firmware (vector patterns, simple/pro commands, etc)
  Channel:    A given channel, which can set input types, gain, etc.
  System:     Each channel has its own stages. From here can perform commands that get/set individual registers.
  registers:  Each system has several registers, which are dictionaries with elements regarding valid units/range.


To begin:
Import necessary module and initialize a board (verbose for console output)

>>>import optoICC1c
>>>icc1c = optoICC1c.connect(port='COM12')  # this will connect and synchronize all channel with the firmware

Define the system you want to interact with (board.mirror.channel.system) (see registers.system_names for a list)
>>>sig_gen = icc1c.channel[0].SignalGenerator
Start setting individual registers
>>>sig_gen.SetAmplitude(0.1)

Additional operations are available directly through the Board object (get/set multiple, reset, etc)
For example, multiple set/get can be done. After this, the system will output a sinusoid on channel 0.
>>>icc1c.set_value([sig_gen.frequency, sig_gen.amplitude, sig_gen.unit, sig_gen.run], [10.0, 0.1, Units.CURRENT, 1])
>>>icc1c.get_value([sig_gen.frequency, sig_gen.amplitude, sig_gen.unit, sig_gen.run])

Example
-------
More examples to come...
"""


# standard ICC-1c Board
class ICC1cBoard(_Board):
    r"""
        Board object from which to issue ICC-1c commands over a serial connection.

        Parameters
        ----------
        port, baudrate, comm_lock, verbose
        Standard serial connection parameters. Extended from Connection class.
        simple: bool, optional = False
        Determines whether or not Board will be set in simple-mode after initialization.
        board_reset: bool, optional = False
        Determines whether or not to reset the Board during initialization.
        Raises
        ------
        none

        Notes
        -----
        Board extends Connection class. Refer to Connection for methods, parameters, etc.
        Board inherits Commands. Refer to Commands for methods, parameters, etc.
    """

    def __init__(self, port: str or None = None, baudrate: int = 256000, comm_lock: bool = True,
                 verbose: bool = False, simple: bool = False, inter_byte_timeout: float = 0.2,
                 ip_address: str = None, ethernet_port: int = 5000):

        # Determine actual port
        if not ip_address and port is None:
            try:
                port = get_icc4c_port()
            except IndexError:
                print("ICC-1c Device Not Found. Serial port connection failed.")

        _Board.__init__(self, port=port,
                            baudrate=baudrate,
                            comm_lock=comm_lock,
                            verbose=verbose,
                            simple=simple,
                            inter_byte_timeout=inter_byte_timeout,
                            simulated=False,
                            ethernet=ip_address is not None,
                            ip_address=ip_address,
                            ethernet_port=ethernet_port)

        # board-level systems
        ## => \link optoICC.registers.icc_registers.ICCStatus ICCStatus\endlink
        self.Status = Registers.ICCStatus(board=self)
        ## => \link optoICC.registers.icc_registers.ICCTemperatureManager ICCTemperatureManager\endlink
        self.TemperatureManager = Registers.ICCTemperatureManager(board=self)
        ## => \link optoICC.registers.icc_registers.ICCMiscFeatures ICCMiscFeatures\endlink
        self.MiscFeatures = Registers.ICCMiscFeatures(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.Logger Logger\endlink
        self.Logger = Registers.Logger(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.SnapshotManager SnapshotManager\endlink
        self.SnapshotManager = Registers.SnapshotManager(board=self)

        # channel-level systems
        ## => \link optoICC.icc1c.ICC1cChannel ICC1cChannel\endlink
        self.channel = [ICC1cChannel(self)]

        ## => \link optoICC.registers.icc_registers.ICCBoardEEPROM ICCBoardEEPROM\endlink
        self.EEPROM = BoardEEPROMRegisters.ICC1cBoardEEPROM(board=self)

        ## => \link optoKummenberg.registers.SignalFlowManager.SignalFlowManager SignalFlowManager\endlink
        self.SignalFlowManager = Registers.SignalFlowManager(board=self)
        ## => \link optoKummenberg.registers.MiscSystems.VectorPatternMemory VectorPatternMemory\endlink
        self.VectorPatternMemory = Registers.VectorPatternMemory(board=self)

        if verbose:
            print('Initialization Finalized.')


## Parent class => \link optoKummenberg.connections.Channel Channel\endlink <br>
class ICC1cChannel(_Channel):
    r"""
        Class to control single channel of the ICC-1c driver. It contains systems supported on specific channel.
    """
    def __init__(self, board, channel_number: int = 0,):
        _Channel.__init__(self, board, channel_number)
        ## ALL/LENS => \link optoICC.registers.icc_registers.ICCStaticInput ICCStaticInput\endlink <br>
        self.StaticInput = Registers.ICCStaticInput(self._channel, self._board)
        ## Only available for device_platform =  ALL || LENS <br>
        ## => \link optoICC.registers.icc_registers.LensCompensation LensCompensation\endlink
        self.LensCompensation = Registers.LensCompensation(self._channel, self._board)

        ## => \link optoICC.registers.icc_registers.ICCAnalogInput ICCAnalogInput\endlink
        self.Analog = Registers.Analog(self._channel, self._board)
        ## => \link optoKummenberg.registers.InputStage.SignalGenerator SignalGenerator\endlink
        self.SignalGenerator = Registers.SignalGenerator(self._channel, self._board)
        ## => \link optoKummenberg.registers.MiscFeatures.DeviceEEPROM DeviceEEPROM\endlink
        self.DeviceEEPROM = Registers.DeviceEEPROM(self._channel, self._board)
        ## => \link optoKummenberg.registers.InputStage.VectorPatternUnit VectorPatternUnit\endlink
        self.VectorPatternUnit = Registers.VectorPatternUnit(self._channel, self._board)