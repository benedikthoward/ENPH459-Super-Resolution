from .icc4c import ICC4cBoard as connect
from .ecc1c import ECC1cBoard as connectEcc
from .icc1c import ICC1cBoard as connectIcc1c
from .tools.definitions import *
from .tools.definitions import *

__version__ = '2.0.5256'
__git_version__ = '5a34e119708d473bac68c3e9d9c33c9ea051cfc7'
