import socket
import time

class EthernetDevice:
    def __init__(self, ip, port, serial_number):
        self.ip = ip
        self.port = port
        self.serial_number = serial_number

    def __repr__(self):
        return f"EthernetDevice(IP={self.ip}, Port={self.port}, Serial={self.serial_number})"

class EthernetSearcher:
    SOURCE_PORT = 30320
    DEST_PORT = 30321
    SEARCH_MESSAGE = b"OptotuneSearch"
    RESPONSE_PREFIX_ICC4c = "ICC4con"
    RESPONSE_PREFIX_ICC1c = "ICC1con"
    RESPONSE_TIMEOUT = 2  # seconds

    @staticmethod
    def get_local_ip_addresses():
        local_ips = []
        for iface_name in socket.if_nameindex():
            try:
                for info in socket.getaddrinfo(socket.gethostname(), None):
                    if info[0] == socket.AF_INET:
                        local_ips.append(info[4][0])
            except Exception:
                continue
        return list(set(local_ips))

    @staticmethod
    def search_ethernet_boards():
        devices = []
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.bind(('', EthernetSearcher.SOURCE_PORT))
        sock.settimeout(EthernetSearcher.RESPONSE_TIMEOUT)

        try:
            sock.sendto(EthernetSearcher.SEARCH_MESSAGE, ('<broadcast>', EthernetSearcher.DEST_PORT))
            start_time = time.time()
            while time.time() - start_time < EthernetSearcher.RESPONSE_TIMEOUT:
                try:
                    data, addr = sock.recvfrom(1024)
                    decoded = data.decode('utf-8')
                    if decoded.startswith((EthernetSearcher.RESPONSE_PREFIX_ICC4c,
                                           EthernetSearcher.RESPONSE_PREFIX_ICC1c)):
                        parts = decoded.split('-')
                        if len(parts) >= 2:
                            serial = parts[1]
                            device = EthernetDevice(addr[0], 5000, serial)
                            if device.ip not in [d.ip for d in devices]:
                                devices.append(device)
                except socket.timeout:
                    break
        finally:
            sock.close()
        return devices