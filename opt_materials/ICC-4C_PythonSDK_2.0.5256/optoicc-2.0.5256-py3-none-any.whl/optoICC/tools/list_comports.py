from optoKummenberg.tools.list_comports import *


def get_icc4c_port(hwid='0483:A31E'):
    """str: default hardware id of ICC-4c board, for port recognition.
    """
    devices = list_ports.comports()
    device = list([device.device for device in devices if hwid in device.hwid])
    return device.pop() if device else None
