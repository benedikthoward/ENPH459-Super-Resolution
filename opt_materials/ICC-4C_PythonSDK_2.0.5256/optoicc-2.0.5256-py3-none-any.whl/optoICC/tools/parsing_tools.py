from optoKummenberg.tools.parsing_tools import *


def parse_error_flags_icc(error_flag_data: int):
    r"""
    Parses error flag register values. Given error number, returns error string.

    Parameters
    ----------
    error_flag_data : int
        Error code hex number, will convert if string.

    Returns
    -------
    code: str
        Error code dictionary.
    """

    bits = []
    for i in range(0, 32):
        bits.append(error_flag_data & (1 << i) > 0)

    error_result = {
        'DRIVER_OUTPUT_CH0_FAULT_CONDITION': bits[0],
        'DRIVER_OUTPUT_CH0_HAD_FAULT_CONDITION': bits[1],
        'DRIVER_OUTPUT_CH1_FAULT_CONDITION': bits[2],
        'DRIVER_OUTPUT_CH1_HAD_FAULT_CONDITION': bits[3],
        'DRIVER_OUTPUT_CH2_FAULT_CONDITION': bits[4],
        'DRIVER_OUTPUT_CH2_HAD_FAULT_CONDITION': bits[5],
        'DRIVER_OUTPUT_CH3_FAULT_CONDITION': bits[6],
        'DRIVER_OUTPUT_CH3_HAD_FAULT_CONDITION': bits[7],
        'DRIVER_OVERHEAT_FAULT': bits[8],
        'DRIVER_HAD_OVERHEAT_FAULT': bits[9],
        'ACTUATOR_CH0_DEVICE_NOT_DETECTED': bits[10],
        'ACTUATOR_CH0_DEVICE_WAS_NOT_DETECTED': bits[11],
        'ACTUATOR_CH1_DEVICE_NOT_DETECTED': bits[12],
        'ACTUATOR_CH1_DEVICE_WAS_NOT_DETECTED': bits[13],
        'ACTUATOR_CH2_DEVICE_NOT_DETECTED': bits[14],
        'ACTUATOR_CH2_DEVICE_WAS_NOT_DETECTED': bits[15],
        'ACTUATOR_CH3_DEVICE_NOT_DETECTED': bits[16],
        'ACTUATOR_CH3_DEVICE_WAS_NOT_DETECTED': bits[17],
        'ACTUATOR_CH0_3V3_OVERCURRENT_FAULT': bits[18],
        'ACTUATOR_CH0_3V3_HAD_OVERCURRENT_FAULT': bits[19],
        'ACTUATOR_CH1_3V3_OVERCURRENT_FAULT': bits[20],
        'ACTUATOR_CH1_3V3_HAD_OVERCURRENT_FAULT': bits[21],
        'ACTUATOR_CH2_3V3_OVERCURRENT_FAULT': bits[22],
        'ACTUATOR_CH2_3V3_HAD_OVERCURRENT_FAULT': bits[23],
        'ACTUATOR_CH3_3V3_OVERCURRENT_FAULT': bits[24],
        'ACTUATOR_CH3_3V3_HAD_OVERCURRENT_FAULT': bits[25],
        'ACTUATOR_I2C_COMMUNICATION_ERROR': bits[26],
        'ACTUATOR_HAD_I2C_COMMUNICATION_ERROR': bits[27],
        'ACTUATOR_EEPROM_PARSING_ERROR': bits[28],
        'ACTUATOR_HAD_EEPROM_PARSING_ERROR': bits[29],
        'ACTUATOR_SENSOR_OUT_OF_RANGE': bits[30],
        'ACTUATOR_SENSOR_WAS_OUT_OF_RANGE': bits[31],
    }

    return error_result
