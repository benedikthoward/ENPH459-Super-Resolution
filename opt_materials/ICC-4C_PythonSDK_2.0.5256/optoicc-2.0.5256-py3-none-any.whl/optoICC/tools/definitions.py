# Kummenberg Internal Definitions
from optoKummenberg.tools.definitions import UnitType, GenericFilterFlag, CommandID, WaveformShape
from enum import IntEnum

# Specific Definitions
XPR4_CHANNEL_CNT = 4


class DevicePlatform(IntEnum):
    ALL    = 0
    LENS   = 1
    XPR    = 2


class DeviceModel(IntEnum) :
    DISCONNECTED = 0
    XPR20 = 1
    XPR20_2CH = 2
    EL1030TC = 3
    XPR46 = 4
    EL1640TC_5D = 5
    EL1230TC_NLP = 6
    EL1030C = 7
    XPR33 = 8
    XPR33_2CH = 9
    DEVICE_URSA = 10,
    DEVICE_ZAURAK = 11,
    XPR42 = 12,
    SARYN_F1 = 13,
    EL0930TC_NLP = 14,
    EL0310 = 15,
    XPRAUTO = 16,
    EL0310FPC = 17,
    EL1030HP = 18,
    EL0830TC_NLP = 19,
    EL1030TC_NLP = 20,
    EL1640GTC = 21,
    EL0720TC_NLP = 22,
    EL1230GTC_NLP = 23,
    EL42SMA = 24,
    MR_15_30 = 25,
    MR_15_30_2CH = 26,
    MR_10_30 = 27,
    EL1640TC_20D = 28,
    XPR18 = 29,
    XPR18_2CH = 30,
    XPR26 = 31,
    XPR26_2CH = 32,
    WASSAT = 33,
    WASSAT_2CH = 34,
    FMR = 35,
    FMR_2CH = 36,
    UNKNOWN = 255




