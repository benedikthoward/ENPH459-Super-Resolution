from optoKummenberg.registers.generic_registers import *


## Parent class => \link optoKummenberg.registers.MiscSystems.BoardEEPROM BoardEEPROM\endlink <br>
class ICC4cBoardEEPROM(BoardEEPROM):
    r"""
    * Board EEPROM system ID: <b>0x20</b>
    *
    * Board EEPROM system provides read and write functionality to the EEPROM located in the driver.
    * By default EEPROM data are write protected. To write data, the user has to explicitly unlock
    * the EEPROM by writing the key value to the lock register.
    *
    * ### Register Map:
    *
    * | Address | Name                           | Default Value | Description                                                       | Type   | Access    |
    * |---------|--------------------------------|---------------|-------------------------------------------------------------------|--------|-----------|
    * | 0x2000  | Lock                           | 1             | write the key to unlock, anything else to lock                    | float  | read write| Key value: 0x3f4744f6 (float 0.778396)
    * | 0x2001  | Board EEPROM version           | N/A           |                                                                   | uint16 | read only |
    * | 0x2002  | Board EEPROM subversion        | N/A           |                                                                   | uint8  | read only |
    * | 0x2003  | Part number                    | N/A           | Part number as an integer (2000mA->14521500, 500mA->14521400)     | uint32 | read only |
    * | 0x2004  | Part configuration             | N/A           |                                                                   | uint8  | read only |
    * | 0x2005  | Product version                | N/A           |                                                                   | uint8  | read only |
    * | 0x2006  | DHCP mode                      | true or 1     | DHCP enabled if not 0                                             | bool   | read write|
    * | 0x2007  | TCP-IP port                    | 5000          |                                                                   | bool   | read write|
    * | 0x2008  | UDP port                       | 30311         |                                                                   | bool   | read write|
    * | 0x2009  | I2C slave address              | 0x03          |                                                                   | uint8  | read write|
    * | 0x200A  | FE_autostart                   | true or 1     | Autostart if value!=0                                             | uint8  | read write|
    * | 0x200B  | FE_voltage                     | 12.0          |                                                                   | float  | read write|
    * | 0x200C  | PWM_freq                       | 0             | Startup PWM freq: 0=400kHz, 1=500kHz, 2=600kHz, 3=1MHz, 4=1.2MHz  | uint8  | read write|
    * | 0x200D  | PWM_enable_chan_mask           | 15            | Enable output PWM driver IC on channel (bitwise)                  | uint8  | read write|
    * | 0x200E  | Device_detect_chan_mask        | 15            | Enable autodetection on channel (bitwise)                         | uint8  | read write|
    * | 0x200F  | Device_3V3_state_chan_mask     | 0             | Enable device 3V3 startup state on channel (bitwise)              | uint8  | read write|
    * | 0x2010  | PS_temp_limit                  | 60            | Power supply temperature limit for shutdown                       | float  | read write|
    * | 0x2011  | PS_temp_hyst                   | 10            | Power supply temperature hysteresis for restart                   | float  | read write|
    * | 0x2012  | OS_temp_limit                  | 60            | Output stage temperature limit for shutdown                       | float  | read write|
    * | 0x2013  | OS_temp_hyst                   | 10            | Output stage temperature hysteresis for restart                   | float  | read write|
    * | 0x2014  | Start_auto_config              | 0             | 1=internal or 2=ext.triger starts auto-actuation (0=off)          | uint32 | read write|
    * | 0x2015  | Calibration Time-stamp         | N/A           | Unix Time format (seconds since 1.1.1970)                         | uint32 | read write|
    * | 0x2016  | Input interface configuration  | 0-Autobaudrate| Configuration of UART baudrate in Baud/s                          | uint32 | read write|
    * | 0x2017  | Slave I2C register count       | 2             | Set # of registers which can be read in one SignalFlow loop 1/2/4 | uint32 | read write|
    * | 0x2018  | Power On Delay                 | 0             | Delay before board initialisation in milliseconds (0-65535)       | uint32 | read write|
    * | 0x2019  | Board EEPROM Parsing result    | 0             | Result of Board EEPROM parsing. Value 0 means OK. See error codes | uint32 | read only |
    * | 0x201A  | Positive current limit chan0   | 0.318         | Positive current limit for unknown devices in mA - chan0          | uint16 | read write|
    * | 0x201B  | Negative current limit chan0   | 0.318         | Negative current limit for unknown devices in mA - chan0          | uint16 | read write|
    * | 0x201C  | Positive current limit chan1   | 0.318         | Positive current limit for unknown devices in mA - chan1          | uint16 | read write|
    * | 0x201D  | Negative current limit chan1   | 0.318         | Negative current limit for unknown devices in mA - chan1          | uint16 | read write|
    * | 0x201E  | Positive current limit chan2   | 0.318         | Positive current limit for unknown devices in mA - chan2          | uint16 | read write|
    * | 0x201F  | Negative current limit chan2   | 0.318         | Negative current limit for unknown devices in mA - chan2          | uint16 | read write|
    * | 0x2020  | Positive current limit chan3   | 0.318         | Positive current limit for unknown devices in mA - chan3          | uint16 | read write|
    * | 0x2021  | Negative current limit chan3   | 0.318         | Negative current limit for unknown devices in mA - chan3          | uint16 | read write|
    *
    * The board EEPROM system supports the following vectors (vectors have their own address space):
    *
    * | Address | Name                           | Default  | Description                 | Format and value |
    * |---------|--------------------------------|----------|-----------------------------|------------------|
    * | 0x2000  | Board EEPROM                   |   N/A    | supports bytes up to 0x2000 |                  |
    * | 0x2001  | Board serial number            |   N/A    | 8 bytes                     | read only        |
    * | 0x2002  | MAC address                    |   N/A    | 6 bytes                     | uint8            |
    * | 0x2003  | IPv4 address                   |   N/A    | 4 bytes                     | uint8            |
    * | 0x2004  | IPv6_address                   |   N/A    | 16 bytes                    | uint8            |
    * | 0x2005  | Output drive cal.coeff. chan0  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2006  | Output drive cal.coeff. chan1  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2007  | Output drive cal.coeff. chan2  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2008  | Output drive cal.coeff. chan3  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2009  | Input analog cal.coeff. chan0  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x200A  | Input analog cal.coeff. chan1  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x200B  | Input analog cal.coeff. chan2  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x200C  | Input analog cal.coeff. chan3  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x200D  | Int.meas.current cal.c. chan0  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x200E  | Int.meas.current cal.c. chan1  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x200F  | Int.meas.current cal.c. chan2  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2010  | Int.meas.current cal.c. chan3  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2011  | Int.meas.voltage cal.c. chan0  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2012  | Int.meas.voltage cal.c. chan1  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2013  | Int.meas.voltage cal.c. chan2  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2014  | Int.meas.voltage cal.c. chan3  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2015  | Int.meas. Uin cal.coefficient  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2016  | Int.meas. Iin cal.coefficient  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2017  | Int.meas. Ufe cal.coefficient  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2018  | Subnet Mask IPv4               |   N/A    | 4 bytes                     | uint8            |
    * | 0x2019  | Gateway IPv4                   |   N/A    | 4 bytes                     | uint8            |
    * | 0x201A  | DNS IPv4                       |   N/A    | 4 bytes                     | uint8            |
    * | 0x201B  | Subnet Mask IPv6               |   N/A    | 16 bytes                    | uint8            |
    * | 0x201C  | Gateway IPv6                   |   N/A    | 16 bytes                    | uint8            |
    * | 0x201D  | DNS IPv6                       |   N/A    | 16 bytes                    | uint8            |
    * |---------|--------------------------------|----------|-----------------------------|------------------|
    """

    @staticmethod
    def help():
        print(BoardEEPROM.__doc__)

    _is_a_system = False

    def __init__(self, board=None):
        BoardEEPROM.__init__(self, board=board)
        self.eeprom_version = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None, 'range': None,
                               'default': None,
                               'value': None}
        self.eeprom_subversion = {'id': self.sys_id << 8 | 0x02, 'type': int, 'unit': None, 'range': None,
                                  'default':
                                      None, 'value': None}
        self.part_number = {'id': self.sys_id << 8 | 0x03, 'type': int, 'unit': None, 'range': None,
                            'default': None, 'value': None}
        self.part_config = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None, 'range': None,
                            'default': None, 'value': None}
        self.prod_version = {'id': self.sys_id << 8 | 0x05, 'type': int, 'unit': None, 'range': None,
                             'default': None, 'value': None}
        self.DHCP_enable = {'id': self.sys_id << 8 | 0x06, 'type': int, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.TCPIP_port = {'id': self.sys_id << 8 | 0x07, 'type': int, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.UDP_port = {'id': self.sys_id << 8 | 0x08, 'type': int, 'unit': None, 'range': None,
                         'default': None, 'value': None}
        self.I2C_slave_addr = {'id': self.sys_id << 8 | 0x09, 'type': int, 'unit': None, 'range': None,
                               'default': None, 'value': None}
        self.FE_autostart = {'id': self.sys_id << 8 | 0x0A, 'type': int, 'unit': None, 'range': None,
                             'default': None, 'value': None}
        self.FE_voltage = {'id': self.sys_id << 8 | 0x0B, 'type': float, 'unit': None, 'range': None,
                           'default': None,
                           'value': None}
        self.PWM_freq = {'id': self.sys_id << 8 | 0x0C, 'type': int, 'unit': None, 'range': None,
                         'default': None, 'value': None}
        self.PWM_enable_chan_mask = {'id': self.sys_id << 8 | 0x0D, 'type': int, 'unit': None, 'range': None,
                                     'default': None, 'value': None}
        self.Device_detect_chan_mask = {'id': self.sys_id << 8 | 0x0E, 'type': int, 'unit': None, 'range': None,
                                        'default': None, 'value': None}
        self.Device_3V3_state_chan_mask = {'id': self.sys_id << 8 | 0x0F, 'type': int, 'unit': None, 'range': None,
                                           'default': None, 'value': None}
        self.PS_temp_limit = {'id': self.sys_id << 8 | 0x10, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.PS_temp_hyst = {'id': self.sys_id << 8 | 0x11, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.OS_temp_limit = {'id': self.sys_id << 8 | 0x12, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.OS_temp_hyst = {'id': self.sys_id << 8 | 0x13, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.Auto_config = {'id': self.sys_id << 8 | 0x14, 'type': int, 'unit': None, 'range': None,
                            'default': None, 'value': None}
        self.Cal_timestamp = {'id': self.sys_id << 8 | 0x15, 'type': int, 'unit': None, 'range': None,
                              'default': None, 'value': None}
        self.Input_control_setup = {'id': self.sys_id << 8 | 0x16, 'type': int, 'unit': None, 'range': None,
                                    'default': None, 'value': None}
        self.I2C_slave_num_of_registers = {'id': self.sys_id << 8 | 0x17, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.Power_on_delay = {'id': self.sys_id << 8 | 0x18, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.BoardEEPROM_parsing_result = {'id': self.sys_id << 8 | 0x19, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.Positive_current_limit_ch0 = {'id': self.sys_id << 8 | 0x1A, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.Negative_current_limit_ch0 = {'id': self.sys_id << 8 | 0x1B, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.Positive_current_limit_ch1 = {'id': self.sys_id << 8 | 0x1C, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.Negative_current_limit_ch1 = {'id': self.sys_id << 8 | 0x1D, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.Positive_current_limit_ch2 = {'id': self.sys_id << 8 | 0x1E, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.Negative_current_limit_ch2 = {'id': self.sys_id << 8 | 0x1F, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.Positive_current_limit_ch3 = {'id': self.sys_id << 8 | 0x20, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.Negative_current_limit_ch3 = {'id': self.sys_id << 8 | 0x21, 'type': int, 'unit': None, 'range': None,
                                         'default': None, 'value': None}

        self.eeprom = {'id': self.sys_id << 8, 'type': bytes}
        self.serial_number = {'id': self.sys_id << 8 | 0x01, 'type': bytes}
        self.MAC_addr = {'id': self.sys_id << 8 | 0x02, 'type': bytes}
        self.IPv4_addr = {'id': self.sys_id << 8 | 0x03, 'type': bytes}
        self.IPv6_addr = {'id': self.sys_id << 8 | 0x04, 'type': bytes}

        self.Out_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x05, 'type': float}
        self.Out_cal_coef_ch1 = {'id': self.sys_id << 8 | 0x06, 'type': float}
        self.Out_cal_coef_ch2 = {'id': self.sys_id << 8 | 0x07, 'type': float}
        self.Out_cal_coef_ch3 = {'id': self.sys_id << 8 | 0x08, 'type': float}
        self.Ain_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x09, 'type': float}
        self.Ain_cal_coef_ch1 = {'id': self.sys_id << 8 | 0x0a, 'type': float}
        self.Ain_cal_coef_ch2 = {'id': self.sys_id << 8 | 0x0b, 'type': float}
        self.Ain_cal_coef_ch3 = {'id': self.sys_id << 8 | 0x0c, 'type': float}
        self.Int_I_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x0d, 'type': float}
        self.Int_I_cal_coef_ch1 = {'id': self.sys_id << 8 | 0x0e, 'type': float}
        self.Int_I_cal_coef_ch2 = {'id': self.sys_id << 8 | 0x0f, 'type': float}
        self.Int_I_cal_coef_ch3 = {'id': self.sys_id << 8 | 0x10, 'type': float}
        self.Int_U_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x11, 'type': float}
        self.Int_U_cal_coef_ch1 = {'id': self.sys_id << 8 | 0x12, 'type': float}
        self.Int_U_cal_coef_ch2 = {'id': self.sys_id << 8 | 0x13, 'type': float}
        self.Int_U_cal_coef_ch3 = {'id': self.sys_id << 8 | 0x14, 'type': float}
        self.Uin_cal_coef = {'id': self.sys_id << 8 | 0x15, 'type': float}
        self.Iin_cal_coef = {'id': self.sys_id << 8 | 0x16, 'type': float}
        self.Ufe_cal_coef = {'id': self.sys_id << 8 | 0x17, 'type': float}

        self.IPv4_sn = {'id': self.sys_id << 8 | 0x18, 'type': bytes}
        self.IPv4_gw = {'id': self.sys_id << 8 | 0x19, 'type': bytes}
        self.IPv4_dns = {'id': self.sys_id << 8 | 0x1A, 'type': bytes}
        self.IPv6_sn = {'id': self.sys_id << 8 | 0x1B, 'type': bytes}
        self.IPv6_gw = {'id': self.sys_id << 8 | 0x1C, 'type': bytes}
        self.IPv6_dns = {'id': self.sys_id << 8 | 0x1D, 'type': bytes}

    ## Gets board EEPROM version
    def GetEepromVersion(self):
        return self.get_register('eeprom_version')

    ## Gets board EEPROM subversion
    def GetEepromSubVersion(self):
        return self.get_register('eeprom_subversion')

    ## Gets board serial number
    def GetSerialNumber(self):
        return self._board.get_vector(self.serial_number, 0, 8)[0]

    ## Gets board MAC address
    def GetMACaddr(self):
        return self._board.get_vector(self.MAC_addr, 0, 6)

    ## Sets board MAC address
    def SetMACaddr(self, mac_addr):
        return self._board.set_vector(self.MAC_addr, 0, mac_addr)

    ## Gets DHCP enabled flag, 0 = DHCP disabled, 1 = DHCP enabled
    def GetDHCP(self):
        return self.get_register('DHCP_enable')

    ## Sets DHCP enabled flag, 0 = DHCP disabled, 1 = DHCP enabled
    def SetDHCP(self, enable):
        return self.set_register('DHCP_enable', enable)

    ## Gets board IPv4 address
    def GetIPv4addr(self):
        return self._board.get_vector(self.IPv4_addr, 0, 4)

    ## Sets board IPv4 address
    def SetIPv4addr(self, addr):
        return self._board.set_vector(self.IPv4_addr, 0, addr)

    ## Gets board IPv4 subnet mask
    def GetIPv4subnet(self):
        return self._board.get_vector(self.IPv4_sn, 0, 4)

    ## Sets board IPv4 subnet mask
    def SetIPv4subnet(self, addr):
        return self._board.set_vector(self.IPv4_sn, 0, addr)

    ## Gets board IPv4 default gateway
    def GetIPv4gateway(self):
        return self._board.get_vector(self.IPv4_gw, 0, 4)

    ## Sets board IPv4 default gateway
    def SetIPv4gateway(self, addr):
        return self._board.set_vector(self.IPv4_gw, 0, addr)

    ## Gets board IPv4 DNS address
    def GetIPv4dns(self):
        return self._board.get_vector(self.IPv4_dns, 0, 4)

    ## Sets board IPv4 DNS address
    def SetIPv4dns(self, addr):
        return self._board.set_vector(self.IPv4_dns, 0, addr)

    ## Gets board IPv6 address
    def GetIPv6addr(self):
        return self._board.get_vector(self.IPv6_addr, 0, 16)

    ## Sets board IPv6 address
    def SetIPv6addr(self, addr):
        return self._board.set_vector(self.IPv6_addr, 0, addr)

    ## Gets board IPv6 subnet mask
    def GetIPv6subnet(self):
        return self._board.get_vector(self.IPv6_sn, 0, 16)

    ## Sets board IPv6 subnet mask
    def SetIPv6subnet(self, addr):
        return self._board.set_vector(self.IPv6_sn, 0, addr)

    ## Gets board IPv6 default gateway mask
    def GetIPv6gateway(self):
        return self._board.get_vector(self.IPv6_gw, 0, 16)

    ## Sets board IPv6 default gateway mask
    def SetIPv6gateway(self, addr):
        return self._board.set_vector(self.IPv6_gw, 0, addr)

    ## Gets board IPv6 DNS address
    def GetIPv6dns(self):
        return self._board.get_vector(self.IPv6_dns, 0, 16)

    ## Sets board IPv6 DNS address
    def SetIPv6dns(self, addr):
        return self._board.set_vector(self.IPv6_dns, 0, addr)

    ## Gets board TCP port
    def GetTCPIPport(self):
        return self.get_register('TCPIP_port')

    ## Sets board TCP port
    def SetTCPIPport(self, port):
        return self.set_register('TCPIP_port', port)

    ## Gets board UDP port
    def GetUDPport(self):
        return self.get_register('UDP_port')

    ## Sets board UDP port
    def SetUDPport(self, port):
        return self.set_register('UDP_port', port)

    ## Gets board I2C address
    def GetI2Caddr(self):
        return self.get_register('I2C_slave_addr')

    ## Sets board I2C address
    def SetI2Caddr(self, addr):
        return self.set_register('I2C_slave_addr', addr)

    ## Gets board FE autostart flag, 0 = disabled, 1 = enabled
    def GetFEautostart(self):
        return self.get_register('FE_autostart')

    ## Sets board FE autostart flag, 0 = disabled, 1 = enabled
    def SetFEautostart(self, val):
        return self.set_register('FE_autostart', val)

    ## Gets board FE voltage
    def GetFEvoltage(self):
        return self.get_register('FE_voltage')

    ## Sets board FE voltage
    def SetFEvoltage(self, val):
        return self.set_register('FE_voltage', val)

    ## Gets board PWM startup frequency,  0=400kHz, 1=500kHz, 2=600kHz, 3=1MHz, 4=1.2MHz
    def GetPWMfreq(self):
        return self.get_register('PWM_freq')

    ## Sets board PWM startup frequency,  0=400kHz, 1=500kHz, 2=600kHz, 3=1MHz, 4=1.2MHz
    def SetPWMfreq(self, val):
        return self.set_register('PWM_freq', val)

    ## Enables output PWM driver IC on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetPWMenableChanMask(self, mask):
        return self.set_register('PWM_enable_chan_mask', mask)

    ## Gets flag which enables output PWM driver IC on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetPWMenableChanMask(self):
        return self.get_register('PWM_enable_chan_mask')

    ## Enables device autodetection (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetDeviceDetectChanMask(self, val):
        return self.set_register('Device_detect_chan_mask', val)

    ## Gets device autodetection flag (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetDeviceDetectChanMask(self):
        return self.get_register('Device_detect_chan_mask')

    ## Enables device 3V3 startup state on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetDevice3V3chanMask(self, val):
        return self.set_register('Device_3V3_state_chan_mask', val)

    ## Gets device 3V3 startup state flag on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetDevice3V3chanMask(self):
        return self.get_register('Device_3V3_state_chan_mask')

    ## Sets power supply temperature limit for shutdown
    def SetPStempLimit(self, val):
        return self.set_register('PS_temp_limit', val)

    ## Gets power supply temperature limit for shutdown
    def GetPStempLimit(self):
        return self.get_register('PS_temp_limit')

    ## Sets power supply temperature hysteresis for restart
    def SetPStempHyst(self, val):
        return self.set_register('PS_temp_hyst', val)

    ## Gets power supply temperature hysteresis for restart
    def GetPStempHyst(self):
        return self.get_register('PS_temp_hyst')

    ## Sets output stage temperature limit for shutdown
    def SetOStempLimit(self, val):
        return self.set_register('OS_temp_limit', val)

    ## Gets output stage temperature limit for shutdown
    def GetOStempLimit(self):
        return self.get_register('OS_temp_limit')

    ## Sets output stage temperature hysteresis for restart
    def SetOStempHyst(self, val):
        return self.set_register('OS_temp_hyst', val)

    ## Gets output stage temperature hysteresis for restart
    def GetOStempHyst(self):
        return self.get_register('OS_temp_hyst')

    ## Gets board calibration timestamp
    def GetCalTimestamp(self):
        return self.get_register('Cal_timestamp')

    def SetAutoConfig(self, val):
        return self.set_register('Auto_config', val)

    def GetAutoConfig(self):
        return self.get_register('Auto_config')

    def SetControlSetup(self, addr):
        return self.set_register('Input_control_setup', addr)

    def GetControlSetup(self):
        return self.get_register('Input_control_setup')

    def SetSlaveNumOfRegisters(self, addr):
        return self.set_register('I2C_slave_num_of_registers', addr)

    def GetSlaveNumOfRegisters(self):
        return self.get_register('I2C_slave_num_of_registers')

    def SetPowerOnDelay(self, val):
        return self.set_register('Power_on_delay', val)

    def GetPowerOnDelay(self):
        return self.get_register('Power_on_delay')

    def GetBoardEEPROMParsingResult(self):
        return self.get_register('BoardEEPROM_parsing_result')

    def SetPositiveCurrentLimit(self, channel, value):
        if channel == 0:
            return self._board.set_register('Positive_current_limit_ch0', value)
        if channel == 1:
            return self._board.set_register('Positive_current_limit_ch1', value)
        if channel == 2:
            return self._board.set_register('Positive_current_limit_ch2', value)
        if channel == 3:
            return self._board.set_register('Positive_current_limit_ch3', value)

    def GetPositiveCurrentLimit(self, channel):
        if channel == 0:
            return self.get_register('Positive_current_limit_ch0')
        if channel == 1:
            return self.get_register('Positive_current_limit_ch1')
        if channel == 2:
            return self.get_register('Positive_current_limit_ch2')
        if channel == 3:
            return self.get_register('Positive_current_limit_ch3')

    def SetNegativeCurrentLimit(self, channel, value):
        if channel == 0:
            return self._board.set_register('Negative_current_limit_ch0', value)
        if channel == 1:
            return self._board.set_register('Negative_current_limit_ch1', value)
        if channel == 2:
            return self._board.set_register('Negative_current_limit_ch2', value)
        if channel == 3:
            return self._board.set_register('Negative_current_limit_ch3', value)

    def GetNegativeCurrentLimit(self, channel):
        if channel == 0:
            return self.get_register('Negative_current_limit_ch0')
        if channel == 1:
            return self.get_register('Negative_current_limit_ch1')
        if channel == 2:
            return self.get_register('Negative_current_limit_ch2')
        if channel == 3:
            return self.get_register('Negative_current_limit_ch3')

    def SetOutCalCoef(self, channel, value):
        if channel == 0:
            return self._board.set_vector(self.Out_cal_coef_ch0, 0, value)
        if channel == 1:
            return self._board.set_vector(self.Out_cal_coef_ch1, 0, value)
        if channel == 2:
            return self._board.set_vector(self.Out_cal_coef_ch2, 0, value)
        if channel == 3:
            return self._board.set_vector(self.Out_cal_coef_ch3, 0, value)

    def GetOutCalCoef(self, channel):
        if channel == 0:
            return self._board.get_vector(self.Out_cal_coef_ch0, 0, 6)
        if channel == 1:
            return self._board.get_vector(self.Out_cal_coef_ch1, 0, 6)
        if channel == 2:
            return self._board.get_vector(self.Out_cal_coef_ch2, 0, 6)
        if channel == 3:
            return self._board.get_vector(self.Out_cal_coef_ch3, 0, 6)

    def SetAinCalCoef(self, channel, value):
        if channel == 0:
            return self._board.set_vector(self.Ain_cal_coef_ch0, 0, value)
        if channel == 1:
            return self._board.set_vector(self.Ain_cal_coef_ch1, 0, value)
        if channel == 2:
            return self._board.set_vector(self.Ain_cal_coef_ch2, 0, value)
        if channel == 3:
            return self._board.set_vector(self.Ain_cal_coef_ch3, 0, value)

    def GetAinCalCoef(self, channel):
        if channel == 0:
            return self._board.get_vector(self.Ain_cal_coef_ch0, 0, 6)
        if channel == 1:
            return self._board.get_vector(self.Ain_cal_coef_ch1, 0, 6)
        if channel == 2:
            return self._board.get_vector(self.Ain_cal_coef_ch2, 0, 6)
        if channel == 3:
            return self._board.get_vector(self.Ain_cal_coef_ch3, 0, 6)

    def SetIntICalCoef(self, channel, value):
        if channel == 0:
            return self._board.set_vector(self.Int_I_cal_coef_ch0, 0, value)
        if channel == 1:
            return self._board.set_vector(self.Int_I_cal_coef_ch1, 0, value)
        if channel == 2:
            return self._board.set_vector(self.Int_I_cal_coef_ch2, 0, value)
        if channel == 3:
            return self._board.set_vector(self.Int_I_cal_coef_ch3, 0, value)

    def GetIntICalCoef(self, channel):
        if channel == 0:
            return self._board.get_vector(self.Int_I_cal_coef_ch0, 0, 6)
        if channel == 1:
            return self._board.get_vector(self.Int_I_cal_coef_ch1, 0, 6)
        if channel == 2:
            return self._board.get_vector(self.Int_I_cal_coef_ch2, 0, 6)
        if channel == 3:
            return self._board.get_vector(self.Int_I_cal_coef_ch3, 0, 6)

    def SetIntUCalCoef(self, channel, value):
        if channel == 0:
            return self._board.set_vector(self.Int_U_cal_coef_ch0, 0, value)
        if channel == 1:
            return self._board.set_vector(self.Int_U_cal_coef_ch1, 0, value)
        if channel == 2:
            return self._board.set_vector(self.Int_U_cal_coef_ch2, 0, value)
        if channel == 3:
            return self._board.set_vector(self.Int_U_cal_coef_ch3, 0, value)

    def GetIntUCalCoef(self, channel, byte_cnt=6):
        if channel == 0:
            return self._board.get_vector(self.Int_U_cal_coef_ch0, 0, byte_cnt)
        if channel == 1:
            return self._board.get_vector(self.Int_U_cal_coef_ch1, 0, byte_cnt)
        if channel == 2:
            return self._board.get_vector(self.Int_U_cal_coef_ch2, 0, byte_cnt)
        if channel == 3:
            return self._board.get_vector(self.Int_U_cal_coef_ch3, 0, byte_cnt)

    def SetUinCalCoef(self, value):
        resp = self._board.set_vector(self.Uin_cal_coef, 0, value)
        return resp

    def GetUinCalCoef(self, byte_cnt=6):
        return self._board.get_vector(self.Uin_cal_coef, 0, byte_cnt)

    def SetIinCalCoef(self, value):
        resp = self._board.set_vector(self.Iin_cal_coef, 0, value)
        return resp

    def GetIinCalCoef(self):
        return self._board.get_vector(self.Iin_cal_coef, 0, 6)

    def GetUfeCalCoef(self, byte_cnt=6):
        return self._board.get_vector(self.Ufe_cal_coef, 0, byte_cnt)

    def SetUfeCalCoef(self, value):
        resp = self._board.set_vector(self.Ufe_cal_coef, 0, value)
        return resp

    def LockEEPROM(self, enable=True):
        if enable:
            return self.set_register('lock', 0.0)
        else:
            return self.set_register('lock', self.lock['value'])

    def SetSerialNumber(self, serial):
        return self._board.set_vector(self.serial_number, 0, serial)

    def SetCalTimestamp(self, timestamp):
        return self.set_register('Cal_timestamp', timestamp)

## Parent class => \link optoKummenberg.registers.MiscSystems.BoardEEPROM BoardEEPROM\endlink <br>
class ICC1cBoardEEPROM(BoardEEPROM):
    r"""
    * Board EEPROM system ID: <b>0x20</b>
    *
    * Board EEPROM system provides read and write functionality to the EEPROM located in the driver.
    * By default EEPROM data are write protected. To write data, the user has to explicitly unlock
    * the EEPROM by writing the key value to the lock register.
    *
    * ### Register Map:
    *
    * | Address | Name                           | Default Value | Description                                                       | Type   | Access    |
    * |---------|--------------------------------|---------------|-------------------------------------------------------------------|--------|-----------|
    * | 0x2000  | Lock                           | 1             | write the key to unlock, anything else to lock                    | float  | read write| Key value: 0x3f4744f6 (float 0.778396)
    * | 0x2001  | Board EEPROM version           | 21            |                                                                   | uint16 | read only |
    * | 0x2002  | Board EEPROM subversion        | N/A           |                                                                   | uint8  | read only |
    * | 0x2003  | Part number                    | N/A           | Part number as an integer (2000mA->14521500, 500mA->14521400)     | uint32 | read only |
    * | 0x2004  | Part configuration             | N/A           |                                                                   | uint8  | read only |
    * | 0x2005  | Product version                | N/A           |                                                                   | uint8  | read only |
    * | 0x2006  | DHCP mode                      | true or 1     | DHCP enabled if not 0                                             | bool   | read write|
    * | 0x2007  | TCP-IP port                    | 5000          |                                                                   | bool   | read write|
    * | 0x2008  | UDP port                       | 30311         |                                                                   | bool   | read write|
    * | 0x2009  | I2C slave address              | 0x03          |                                                                   | uint8  | read write|
    * | 0x200A  | FE_autostart                   | true or 1     | Autostart if value!=0                                             | uint8  | read write|
    * | 0x200B  | FE_voltage                     | 12.0          |                                                                   | float  | read write|
    * | 0x200C  | PWM_freq                       | 0             | Startup PWM freq: 0=400kHz, 1=500kHz, 2=600kHz, 3=1MHz, 4=1.2MHz  | uint8  | read write|
    * | 0x200D  | PWM_enable_chan_mask           | 15            | Enable output PWM driver IC on channel (bitwise)                  | uint8  | read write|
    * | 0x200E  | Device_detect_chan_mask        | 15            | Enable autodetection on channel (bitwise)                         | uint8  | read write|
    * | 0x200F  | Device_3V3_state_chan_mask     | 0             | Enable device 3V3 startup state on channel (bitwise)              | uint8  | read write|
    * | 0x2010  | PS_temp_limit                  | 105           | Power supply temperature limit for shutdown                       | float  | read write|
    * | 0x2011  | PS_temp_hyst                   | 95            | Power supply temperature hysteresis for restart                   | float  | read write|
    * | 0x2012  | OS_temp_limit                  | 110           | Output stage temperature limit for shutdown                       | float  | read write|
    * | 0x2013  | OS_temp_hyst                   | 100           | Output stage temperature hysteresis for restart                   | float  | read write|
    * | 0x2014  | 	USBPD preferred profile      | 0             | Preferred USB PD: 0 =5V/3A, 1 = 9V/1.5A, 2 = 15V/1A, 3 = 20V/1A   | uint8  | read write|
    * | 0x2015  | Calibration Time-stamp         | N/A           | Unix Time format (seconds since 1.1.1970)                         | uint32 | read write|
    * | 0x2016  | Input interface configuration  | 0-Autobaudrate| Configuration of UART baudrate in Baud/s                          | uint32 | read write|
    * | 0x2017  | Slave I2C register count       | 2             | Set # of registers which can be read in one SignalFlow loop 1/2/4 | uint32 | read write|
    * | 0x2018  | Power On Delay                 | 0             | Delay before board initialisation in milliseconds (0-65535)       | uint32 | read write|
    * | 0x2019  | Board EEPROM Parsing result    | 0             | Result of Board EEPROM parsing. Value 0 means OK. See error codes | uint32 | read only |
    * | 0x201A  | Positive current limit         | 500           | Positive current limit for unknown devices in mA                  | uint16 | read write|
    * | 0x201B  | Negative current limit         | 500           | Negative current limit for unknown devices in mA                  | uint16 | read write|
    * | 0x201C  | Feedback mode                  | 0             | Start-up feedback mode: 0 - Current, 1 - Voltage                  | uint8  | read write|
    *
    * The board EEPROM system supports the following vectors (vectors have their own address space):
    *
    * | Address | Name                           | Default  | Description                 | Format and value |
    * |---------|--------------------------------|----------|-----------------------------|------------------|
    * | 0x2000  | Board EEPROM                   |   N/A    | supports bytes up to 0x2000 |                  |
    * | 0x2001  | Board serial number            |   N/A    | 8 bytes                     | read only        |
    * | 0x2002  | MAC address                    |   N/A    | 6 bytes                     | uint8            |
    * | 0x2003  | IPv4 address                   |   N/A    | 4 bytes                     | uint8            |
    * | 0x2004  | IPv6_address                   |   N/A    | 16 bytes                    | uint8            |
    * | 0x2005  | Output drive cal.coeff. chan0  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2009  | Input analog cal.coeff. chan0  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x200D  | Int.meas.current cal.c. chan0  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2011  | Int.meas.voltage cal.c. chan0  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2015  | Int.meas. Uin cal.coefficient  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2016  | Int.meas. Iin cal.coefficient  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2017  | Int.meas. Ufe cal.coefficient  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2018  | Subnet Mask IPv4               |   N/A    | 4 bytes                     | uint8            |
    * | 0x2019  | Gateway IPv4                   |   N/A    | 4 bytes                     | uint8            |
    * | 0x201A  | DNS IPv4                       |   N/A    | 4 bytes                     | uint8            |
    * | 0x201B  | Subnet Mask IPv6               |   N/A    | 16 bytes                    | uint8            |
    * | 0x201C  | Gateway IPv6                   |   N/A    | 16 bytes                    | uint8            |
    * | 0x201D  | DNS IPv6                       |   N/A    | 16 bytes                    | uint8            |
    * |---------|--------------------------------|----------|-----------------------------|------------------|
    """

    @staticmethod
    def help():
        print(BoardEEPROM.__doc__)

    _is_a_system = False

    def __init__(self, board=None):
        BoardEEPROM.__init__(self, board=board)
        self.eeprom_version = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None, 'range': None,
                               'default': None,
                               'value': None}
        self.eeprom_subversion = {'id': self.sys_id << 8 | 0x02, 'type': int, 'unit': None, 'range': None,
                                  'default':
                                      None, 'value': None}
        self.part_number = {'id': self.sys_id << 8 | 0x03, 'type': int, 'unit': None, 'range': None,
                            'default': None, 'value': None}
        self.part_config = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None, 'range': None,
                            'default': None, 'value': None}
        self.prod_version = {'id': self.sys_id << 8 | 0x05, 'type': int, 'unit': None, 'range': None,
                             'default': None, 'value': None}
        self.DHCP_enable = {'id': self.sys_id << 8 | 0x06, 'type': int, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.TCPIP_port = {'id': self.sys_id << 8 | 0x07, 'type': int, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.UDP_port = {'id': self.sys_id << 8 | 0x08, 'type': int, 'unit': None, 'range': None,
                         'default': None, 'value': None}
        self.I2C_slave_addr = {'id': self.sys_id << 8 | 0x09, 'type': int, 'unit': None, 'range': None,
                               'default': None, 'value': None}
        self.FE_autostart = {'id': self.sys_id << 8 | 0x0A, 'type': int, 'unit': None, 'range': None,
                             'default': None, 'value': None}
        self.FE_voltage = {'id': self.sys_id << 8 | 0x0B, 'type': float, 'unit': None, 'range': None,
                           'default': None,
                           'value': None}
        self.PWM_freq = {'id': self.sys_id << 8 | 0x0C, 'type': int, 'unit': None, 'range': None,
                         'default': None, 'value': None}
        self.PWM_enable_chan_mask = {'id': self.sys_id << 8 | 0x0D, 'type': int, 'unit': None, 'range': None,
                                     'default': None, 'value': None}
        self.Device_detect_chan_mask = {'id': self.sys_id << 8 | 0x0E, 'type': int, 'unit': None, 'range': None,
                                        'default': None, 'value': None}
        self.Device_3V3_state_chan_mask = {'id': self.sys_id << 8 | 0x0F, 'type': int, 'unit': None, 'range': None,
                                           'default': None, 'value': None}
        self.PS_temp_limit = {'id': self.sys_id << 8 | 0x10, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.PS_temp_hyst = {'id': self.sys_id << 8 | 0x11, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.OS_temp_limit = {'id': self.sys_id << 8 | 0x12, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.OS_temp_hyst = {'id': self.sys_id << 8 | 0x13, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.USBPD = {'id': self.sys_id << 8 | 0x14, 'type': int, 'unit': None, 'range': None,
                            'default': None, 'value': None}
        self.Cal_timestamp = {'id': self.sys_id << 8 | 0x15, 'type': int, 'unit': None, 'range': None,
                              'default': None, 'value': None}
        self.Input_control_setup = {'id': self.sys_id << 8 | 0x16, 'type': int, 'unit': None, 'range': None,
                                    'default': None, 'value': None}
        self.I2C_slave_num_of_registers = {'id': self.sys_id << 8 | 0x17, 'type': int, 'unit': None, 'range': None,
                                           'default': None, 'value': None}
        self.Power_on_delay = {'id': self.sys_id << 8 | 0x18, 'type': int, 'unit': None, 'range': None,
                               'default': None, 'value': None}
        self.BoardEEPROM_parsing_result = {'id': self.sys_id << 8 | 0x19, 'type': int, 'unit': None, 'range': None,
                                           'default': None, 'value': None}
        self.Positive_current_limit = {'id': self.sys_id << 8 | 0x1A, 'type': int, 'unit': None, 'range': None,
                                       'default': None, 'value': None}
        self.Negative_current_limit = {'id': self.sys_id << 8 | 0x1B, 'type': int, 'unit': None, 'range': None,
                                       'default': None, 'value': None}
        self.Feedback_mode = {'id': self.sys_id << 8 | 0x1C, 'type': int, 'unit': None, 'range': None,
                              'default': None, 'value': None}

        self.eeprom = {'id': self.sys_id << 8, 'type': bytes}
        self.serial_number = {'id': self.sys_id << 8 | 0x01, 'type': bytes}
        self.MAC_addr = {'id': self.sys_id << 8 | 0x02, 'type': bytes}
        self.IPv4_addr = {'id': self.sys_id << 8 | 0x03, 'type': bytes}
        self.IPv6_addr = {'id': self.sys_id << 8 | 0x04, 'type': bytes}

        self.Out_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x05, 'type': float}
        self.Ain_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x09, 'type': float}
        self.Int_I_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x0d, 'type': float}
        self.Int_U_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x11, 'type': float}
        self.Uin_cal_coef = {'id': self.sys_id << 8 | 0x15, 'type': float}
        self.Iin_cal_coef = {'id': self.sys_id << 8 | 0x16, 'type': float}
        self.Ufe_cal_coef = {'id': self.sys_id << 8 | 0x17, 'type': float}

        self.IPv4_sn = {'id': self.sys_id << 8 | 0x18, 'type': bytes}
        self.IPv4_gw = {'id': self.sys_id << 8 | 0x19, 'type': bytes}
        self.IPv4_dns = {'id': self.sys_id << 8 | 0x1A, 'type': bytes}
        self.IPv6_sn = {'id': self.sys_id << 8 | 0x1B, 'type': bytes}
        self.IPv6_gw = {'id': self.sys_id << 8 | 0x1C, 'type': bytes}
        self.IPv6_dns = {'id': self.sys_id << 8 | 0x1D, 'type': bytes}

    ## Gets board EEPROM version
    def GetEepromVersion(self):
        return self.get_register('eeprom_version')

    ## Gets board EEPROM subversion
    def GetEepromSubVersion(self):
        return self.get_register('eeprom_subversion')

    ## Gets board serial number
    def GetSerialNumber(self):
        return self._board.get_vector(self.serial_number, 0, 8)[0]

    ## Gets board MAC address
    def GetMACaddr(self):
        return self._board.get_vector(self.MAC_addr, 0, 6)

    ## Sets board MAC address
    def SetMACaddr(self, mac_addr):
        return self._board.set_vector(self.MAC_addr, 0, mac_addr)

    ## Gets DHCP enabled flag, 0 = DHCP disabled, 1 = DHCP enabled
    def GetDHCP(self):
        return self.get_register('DHCP_enable')

    ## Sets DHCP enabled flag, 0 = DHCP disabled, 1 = DHCP enabled
    def SetDHCP(self, enable):
        return self.set_register('DHCP_enable', enable)

    ## Gets board IPv4 address
    def GetIPv4addr(self):
        return self._board.get_vector(self.IPv4_addr, 0, 4)

    ## Sets board IPv4 address
    def SetIPv4addr(self, addr):
        return self._board.set_vector(self.IPv4_addr, 0, addr)

    ## Gets board IPv4 subnet mask
    def GetIPv4subnet(self):
        return self._board.get_vector(self.IPv4_sn, 0, 4)

    ## Sets board IPv4 subnet mask
    def SetIPv4subnet(self, addr):
        return self._board.set_vector(self.IPv4_sn, 0, addr)

    ## Gets board IPv4 default gateway
    def GetIPv4gateway(self):
        return self._board.get_vector(self.IPv4_gw, 0, 4)

    ## Sets board IPv4 default gateway
    def SetIPv4gateway(self, addr):
        return self._board.set_vector(self.IPv4_gw, 0, addr)

    ## Gets board IPv4 DNS address
    def GetIPv4dns(self):
        return self._board.get_vector(self.IPv4_dns, 0, 4)

    ## Sets board IPv4 DNS address
    def SetIPv4dns(self, addr):
        return self._board.set_vector(self.IPv4_dns, 0, addr)

    ## Gets board IPv6 address
    def GetIPv6addr(self):
        return self._board.get_vector(self.IPv6_addr, 0, 16)

    ## Sets board IPv6 address
    def SetIPv6addr(self, addr):
        return self._board.set_vector(self.IPv6_addr, 0, addr)

    ## Gets board IPv6 subnet mask
    def GetIPv6subnet(self):
        return self._board.get_vector(self.IPv6_sn, 0, 16)

    ## Sets board IPv6 subnet mask
    def SetIPv6subnet(self, addr):
        return self._board.set_vector(self.IPv6_sn, 0, addr)

    ## Gets board IPv6 default gateway mask
    def GetIPv6gateway(self):
        return self._board.get_vector(self.IPv6_gw, 0, 16)

    ## Sets board IPv6 default gateway mask
    def SetIPv6gateway(self, addr):
        return self._board.set_vector(self.IPv6_gw, 0, addr)

    ## Gets board IPv6 DNS address
    def GetIPv6dns(self):
        return self._board.get_vector(self.IPv6_dns, 0, 16)

    ## Sets board IPv6 DNS address
    def SetIPv6dns(self, addr):
        return self._board.set_vector(self.IPv6_dns, 0, addr)

    ## Gets board TCP port
    def GetTCPIPport(self):
        return self.get_register('TCPIP_port')

    ## Sets board TCP port
    def SetTCPIPport(self, port):
        return self.set_register('TCPIP_port', port)

    ## Gets board UDP port
    def GetUDPport(self):
        return self.get_register('UDP_port')

    ## Sets board UDP port
    def SetUDPport(self, port):
        return self.set_register('UDP_port', port)

    ## Gets board I2C address
    def GetI2Caddr(self):
        return self.get_register('I2C_slave_addr')

    ## Sets board I2C address
    def SetI2Caddr(self, addr):
        return self.set_register('I2C_slave_addr', addr)

    ## Gets board FE autostart flag, 0 = disabled, 1 = enabled
    def GetFEautostart(self):
        return self.get_register('FE_autostart')

    ## Sets board FE autostart flag, 0 = disabled, 1 = enabled
    def SetFEautostart(self, val):
        return self.set_register('FE_autostart', val)

    ## Gets board FE voltage
    def GetFEvoltage(self):
        return self.get_register('FE_voltage')

    ## Sets board FE voltage
    def SetFEvoltage(self, val):
        return self.set_register('FE_voltage', val)

    ## Gets board PWM startup frequency,  0=400kHz, 1=500kHz, 2=600kHz, 3=1MHz, 4=1.2MHz
    def GetPWMfreq(self):
        return self.get_register('PWM_freq')

    ## Sets board PWM startup frequency,  0=400kHz, 1=500kHz, 2=600kHz, 3=1MHz, 4=1.2MHz
    def SetPWMfreq(self, val):
        return self.set_register('PWM_freq', val)

    ## Enables output PWM driver IC on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetPWMenableChanMask(self, mask):
        return self.set_register('PWM_enable_chan_mask', mask)

    ## Gets flag which enables output PWM driver IC on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetPWMenableChanMask(self):
        return self.get_register('PWM_enable_chan_mask')

    ## Enables device autodetection (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetDeviceDetectChanMask(self, val):
        return self.set_register('Device_detect_chan_mask', val)

    ## Gets device autodetection flag (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetDeviceDetectChanMask(self):
        return self.get_register('Device_detect_chan_mask')

    ## Enables device 3V3 startup state on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetDevice3V3chanMask(self, val):
        return self.set_register('Device_3V3_state_chan_mask', val)

    ## Gets device 3V3 startup state flag on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetDevice3V3chanMask(self):
        return self.get_register('Device_3V3_state_chan_mask')

    ## Sets power supply temperature limit for shutdown
    def SetPStempLimit(self, val):
        return self.set_register('PS_temp_limit', val)

    ## Gets power supply temperature limit for shutdown
    def GetPStempLimit(self):
        return self.get_register('PS_temp_limit')

    ## Sets power supply temperature hysteresis for restart
    def SetPStempHyst(self, val):
        return self.set_register('PS_temp_hyst', val)

    ## Gets power supply temperature hysteresis for restart
    def GetPStempHyst(self):
        return self.get_register('PS_temp_hyst')

    ## Sets output stage temperature limit for shutdown
    def SetOStempLimit(self, val):
        return self.set_register('OS_temp_limit', val)

    ## Gets output stage temperature limit for shutdown
    def GetOStempLimit(self):
        return self.get_register('OS_temp_limit')

    ## Sets output stage temperature hysteresis for restart
    def SetOStempHyst(self, val):
        return self.set_register('OS_temp_hyst', val)

    ## Gets output stage temperature hysteresis for restart
    def GetOStempHyst(self):
        return self.get_register('OS_temp_hyst')

    ## Gets board calibration timestamp
    def GetCalTimestamp(self):
        return self.get_register('Cal_timestamp')

    def SetUSBPD(self, val):
        return self.set_register('USBPD', val)

    def GetUSBPD(self):
        return self.get_register('USBPD')

    def SetControlSetup(self, addr):
        return self.set_register('Input_control_setup', addr)

    def GetControlSetup(self):
        return self.get_register('Input_control_setup')

    def SetSlaveNumOfRegisters(self, addr):
        return self.set_register('I2C_slave_num_of_registers', addr)

    def GetSlaveNumOfRegisters(self):
        return self.get_register('I2C_slave_num_of_registers')

    def SetPowerOnDelay(self, val):
        return self.set_register('Power_on_delay', val)

    def GetPowerOnDelay(self):
        return self.get_register('Power_on_delay')

    def GetBoardEEPROMParsingResult(self):
        return self.get_register('BoardEEPROM_parsing_result')

    def SetPositiveCurrentLimit(self, val):
        return self.set_register('Positive_current_limit', val)

    def GetPositiveCurrentLimit(self):
        return self.get_register('Positive_current_limit')

    def SetNegativeCurrentLimit(self, val):
        return self.set_register('Negative_current_limit', val)

    def GetNegativeCurrentLimit(self):
        return self.get_register('Negative_current_limit')

    def SetFeedbackMode(self, val):
        return self.set_register('Feedback_mode', val)

    def GetFeedbackMode(self):
        return self.get_register('Feedback_mode')

    def SetOutCalCoef(self, value):
        return self._board.set_vector(self.Out_cal_coef_ch0, 0, value)

    def GetOutCalCoef(self, channel):
        return self._board.get_vector(self.Out_cal_coef_ch0, 0, 6)

    def SetAinCalCoef(self, channel, value):
        return self._board.set_vector(self.Ain_cal_coef_ch0, 0, value)

    def GetAinCalCoef(self, channel):
        return self._board.get_vector(self.Ain_cal_coef_ch0, 0, 6)

    def SetIntICalCoef(self, channel, value):
        return self._board.set_vector(self.Int_I_cal_coef_ch0, 0, value)

    def GetIntICalCoef(self, channel):
        return self._board.get_vector(self.Int_I_cal_coef_ch0, 0, 6)

    def SetIntUCalCoef(self, channel, value):
        return self._board.set_vector(self.Int_U_cal_coef_ch0, 0, value)

    def GetIntUCalCoef(self, channel, byte_cnt=6):
        return self._board.get_vector(self.Int_U_cal_coef_ch0, 0, byte_cnt)

    def SetUinCalCoef(self, value):
        resp = self._board.set_vector(self.Uin_cal_coef, 0, value)
        return resp

    def GetUinCalCoef(self, byte_cnt=6):
        return self._board.get_vector(self.Uin_cal_coef, 0, byte_cnt)

    def SetIinCalCoef(self, value):
        resp = self._board.set_vector(self.Iin_cal_coef, 0, value)
        return resp

    def GetIinCalCoef(self):
        return self._board.get_vector(self.Iin_cal_coef, 0, 6)

    def GetUfeCalCoef(self, byte_cnt=6):
        return self._board.get_vector(self.Ufe_cal_coef, 0, byte_cnt)

    def SetUfeCalCoef(self, value):
        resp = self._board.set_vector(self.Ufe_cal_coef, 0, value)
        return resp

    def LockEEPROM(self, enable=True):
        if enable:
            return self.set_register('lock', 0.0)
        else:
            return self.set_register('lock', self.lock['value'])

    def SetSerialNumber(self, serial):
        return self._board.set_vector(self.serial_number, 0, serial)

    def SetCalTimestamp(self, timestamp):
        return self.set_register('Cal_timestamp', timestamp)



## Parent class => \link optoKummenberg.registers.MiscSystems.BoardEEPROM BoardEEPROM\endlink <br>
class ECC1cBoardEEPROM(BoardEEPROM):
    r"""
    * Board EEPROM system ID: <b>0x20</b>
    *
    * Board EEPROM system provides read and write functionality to the EEPROM located in the driver.
    * By default EEPROM data are write protected. To write data, the user has to explicitly unlock
    * the EEPROM by writing the key value to the lock register.
    *
    * ### Register Map:
    *
    * | Address | Name                           | Default Value | Description                                                       | Type   | Access    |
    * |---------|--------------------------------|---------------|-------------------------------------------------------------------|--------|-----------|
    * | 0x2000  | Lock                           | 1             | write the key to unlock, anything else to lock                    | float  | read write|
    * | 0x2001  | Board EEPROM version           | 18            |                                                                   | uint16 | read only |
    * | 0x2002  | Board EEPROM subversion        | N/A           |                                                                   | uint8  | read only |
    * | 0x2003  | Part number                    | N/A           | Part number as an integer (14594400)                              | uint32 | read only |
    * | 0x2004  | Part configuration             | N/A           |                                                                   | uint8  | read only |
    * | 0x2005  | Product version                | N/A           |                                                                   | uint8  | read only |
    * | 0x2009  | I2C slave address              | 0x20          | 	Address for I2C communication. Device responds to this address   | uint8  | read write|
    * | 0x200D  | PWM_enable_chan_mask           | 1             | Enable output PWM driver IC on channel (bitwise)                  | uint8  | read write|
    * | 0x200E  | Device_detect_chan_mask        | 1             | Enable autodetection on channel (bitwise)                         | uint8  | read write|
    * | 0x200F  | Device_3V3_state_chan_mask     | 0             | Enable device 3V3 startup state on channel (bitwise)              | uint8  | read write|
    * | 0x2010  | PS_temp_limit                  | 105           | Power supply temperature limit for shutdown                       | float  | read write|
    * | 0x2011  | PS_temp_hyst                   | 95            | Power supply temperature hysteresis for restart                   | float  | read write|
    * | 0x2012  | OS_temp_limit                  | 110           | Output stage temperature limit for shutdown                       | float  | read write|
    * | 0x2013  | OS_temp_hyst                   | 100           | Output stage temperature hysteresis for restart                   | float  | read write|
    * | 0x2015  | Calibration Time-stamp         | N/A           | Unix Time format (seconds since 1.1.1970)                         | uint32 | read write|
    * | 0x2016  | Input interface configuration  | 0-Autobaudrate| Configuration of UART baudrate in Baud/s                          | uint32 | read write|
    * | 0x2017  | Slave I2C register count       | 2             | Set # of registers which can be read in one SignalFlow loop 1/2/4 | uint32 | read write|
    * | 0x2018  | Power On Delay                 | 0             | Delay before board initialisation in milliseconds (0-65535)       | uint32 | read write|
    * | 0x2019  | Board EEPROM Parsing result    | 0             | Result of Board EEPROM parsing. Value 0 means OK. See error codes | uint32 | read only |
    * | 0x201A  | Positive current limit         | 318           | Positive current limit for unknown devices in mA                  | uint16 | read write|
    * | 0x201B  | Negative current limit         | 318           | Negative current limit for unknown devices in mA                  | uint16 | read write|
    *
    * The board EEPROM system supports the following vectors (vectors have their own address space):
    *
    * | Address | Name                           | Default  | Description                 | Format and value |
    * |---------|--------------------------------|----------|-----------------------------|------------------|
    * | 0x2000  | Board EEPROM                   |   N/A    | supports bytes up to 0x2000 |                  |
    * | 0x2001  | Board serial number            |   N/A    | 8 bytes                     | read only        |
    * | 0x2005  | Output drive cal.coeff. posit  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2006  | Output drive cal.coeff. negat  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2009  | Input analog cal.coeff.        |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2011  | Int.meas.voltage cal.c. chan0  |   N/A    | 2 * float (24 bytes)        | float            |
    * | 0x2015  | Int.meas. Uin cal.coefficient  |   N/A    | 6 * float (24 bytes)        | float            |
    * | 0x2017  | Int.meas. Ufe cal.coefficient  |   N/A    | 2 * float (24 bytes)        | float            |
    * | 0x201E  | Temp calibration for I0        |   N/A    | 4 * float (12 bytes)        | float            |
    * | 0x201F  | Temp calibration for Imax      |   N/A    | 4 * float (12 bytes)        | float            |
    * | 0x2020  | Temp calibration for Imin      |   N/A    | 4 * float (12 bytes)        | float            |
    * |---------|--------------------------------|----------|-----------------------------|------------------|
    """

    @staticmethod
    def help():
        print(BoardEEPROM.__doc__)

    _is_a_system = False

    def __init__(self, board=None):
        BoardEEPROM.__init__(self, board=board)
        self.eeprom_version = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None, 'range': None,
                               'default': None,
                               'value': None}
        self.eeprom_subversion = {'id': self.sys_id << 8 | 0x02, 'type': int, 'unit': None, 'range': None,
                                  'default':
                                      None, 'value': None}
        self.part_number = {'id': self.sys_id << 8 | 0x03, 'type': int, 'unit': None, 'range': None,
                            'default': None, 'value': None}
        self.part_config = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None, 'range': None,
                            'default': None, 'value': None}
        self.prod_version = {'id': self.sys_id << 8 | 0x05, 'type': int, 'unit': None, 'range': None,
                             'default': None, 'value': None}
        self.I2C_slave_addr = {'id': self.sys_id << 8 | 0x09, 'type': int, 'unit': None, 'range': None,
                               'default': None, 'value': None}
        self.PWM_enable_chan_mask = {'id': self.sys_id << 8 | 0x0D, 'type': int, 'unit': None, 'range': None,
                                     'default': None, 'value': None}
        self.Device_detect_chan_mask = {'id': self.sys_id << 8 | 0x0E, 'type': int, 'unit': None, 'range': None,
                                        'default': None, 'value': None}
        self.Device_3V3_state_chan_mask = {'id': self.sys_id << 8 | 0x0F, 'type': int, 'unit': None,
                                           'range': None,
                                           'default': None, 'value': None}
        self.PS_temp_limit = {'id': self.sys_id << 8 | 0x10, 'type': float, 'unit': None, 'range': None,
                              'default':
                                  None, 'value': None}
        self.PS_temp_hyst = {'id': self.sys_id << 8 | 0x11, 'type': float, 'unit': None, 'range': None,
                             'default':
                                 None, 'value': None}
        self.OS_temp_limit = {'id': self.sys_id << 8 | 0x12, 'type': float, 'unit': None, 'range': None,
                              'default':
                                  None, 'value': None}
        self.OS_temp_hyst = {'id': self.sys_id << 8 | 0x13, 'type': float, 'unit': None, 'range': None,
                             'default':
                                 None, 'value': None}
        self.Cal_timestamp = {'id': self.sys_id << 8 | 0x15, 'type': int, 'unit': None, 'range': None,
                              'default': None, 'value': None}
        self.Input_control_setup = {'id': self.sys_id << 8 | 0x16, 'type': int, 'unit': None, 'range': None,
                                    'default': None, 'value': None}
        self.I2C_slave_num_of_registers = {'id': self.sys_id << 8 | 0x17, 'type': int, 'unit': None,
                                           'range': None,
                                           'default': None, 'value': None}
        self.Power_on_delay = {'id': self.sys_id << 8 | 0x18, 'type': int, 'unit': None, 'range': None,
                               'default': None, 'value': None}
        self.BoardEEPROM_parsing_result = {'id': self.sys_id << 8 | 0x19, 'type': int, 'unit': None,
                                           'range': None,
                                           'default': None, 'value': None}
        self.Positive_current_limit = {'id': self.sys_id << 8 | 0x1A, 'type': int, 'unit': None, 'range': None,
                                       'default': None, 'value': None}
        self.Negative_current_limit = {'id': self.sys_id << 8 | 0x1B, 'type': int, 'unit': None, 'range': None,
                                       'default': None, 'value': None}

        self.eeprom = {'id': self.sys_id << 8, 'type': bytes}
        self.serial_number = {'id': self.sys_id << 8 | 0x01, 'type': bytes}
        self.Out_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x05, 'type': float}
        self.Out_cal_coef_ch1 = {'id': self.sys_id << 8 | 0x06, 'type': float}
        self.Ain_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x09, 'type': float}
        self.Int_U_cal_coef_ch0 = {'id': self.sys_id << 8 | 0x11, 'type': float}
        self.Uin_cal_coef = {'id': self.sys_id << 8 | 0x15, 'type': float}
        self.Ufe_cal_coef = {'id': self.sys_id << 8 | 0x17, 'type': float}
        self.Temp_cal_I0 = {'id': self.sys_id << 8 | 0x1E, 'type': float}
        self.Temp_cal_Imax = {'id': self.sys_id << 8 | 0x1F, 'type': float}
        self.Temp_cal_Imin = {'id': self.sys_id << 8 | 0x20, 'type': float}

    ## Gets board EEPROM version
    def GetEepromVersion(self):
        return self.get_register('eeprom_version')

    ## Gets board EEPROM subversion
    def GetEepromSubVersion(self):
        return self.get_register('eeprom_subversion')

    ## Gets board serial number
    def GetSerialNumber(self):
        return self._board.get_vector(self.serial_number, 0, 8)[0]

    ## Gets board I2C address
    def GetI2Caddr(self):
        return self.get_register('I2C_slave_addr')

    ## Sets board I2C address
    def SetI2Caddr(self, addr):
        return self.set_register('I2C_slave_addr', addr)

    ## Enables output PWM driver IC on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetPWMenableChanMask(self, mask):
        return self.set_register('PWM_enable_chan_mask', mask)

    ## Gets flag which enables output PWM driver IC on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetPWMenableChanMask(self):
        return self.get_register('PWM_enable_chan_mask')

    ## Enables device autodetection (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetDeviceDetectChanMask(self, val):
        return self.set_register('Device_detect_chan_mask', val)

    ## Gets device autodetection flag (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetDeviceDetectChanMask(self):
        return self.get_register('Device_detect_chan_mask')

    ## Enables device 3V3 startup state on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def SetDevice3V3chanMask(self, val):
        return self.set_register('Device_3V3_state_chan_mask', val)

    ## Gets device 3V3 startup state flag on channel (bitwise), 0 bit = channel 0, 1 bit = channel 1, ...
    def GetDevice3V3chanMask(self):
        return self.get_register('Device_3V3_state_chan_mask')

    ## Sets power supply temperature limit for shutdown
    def SetPStempLimit(self, val):
        return self.set_register('PS_temp_limit', val)

    ## Gets power supply temperature limit for shutdown
    def GetPStempLimit(self):
        return self.get_register('PS_temp_limit')

    ## Sets power supply temperature hysteresis for restart
    def SetPStempHyst(self, val):
        return self.set_register('PS_temp_hyst', val)

    ## Gets power supply temperature hysteresis for restart
    def GetPStempHyst(self):
        return self.get_register('PS_temp_hyst')

    ## Sets output stage temperature limit for shutdown
    def SetOStempLimit(self, val):
        return self.set_register('OS_temp_limit', val)

    ## Gets output stage temperature limit for shutdown
    def GetOStempLimit(self):
        return self.get_register('OS_temp_limit')

    ## Sets output stage temperature hysteresis for restart
    def SetOStempHyst(self, val):
        return self.set_register('OS_temp_hyst', val)

    ## Gets output stage temperature hysteresis for restart
    def GetOStempHyst(self):
        return self.get_register('OS_temp_hyst')

    ## Gets board calibration timestamp
    def GetCalTimestamp(self):
        return self.get_register('Cal_timestamp')

    def SetAutoConfig(self, val):
        return self.set_register('Auto_config', val)

    def GetAutoConfig(self):
        return self.get_register('Auto_config')

    def SetControlSetup(self, addr):
        return self.set_register('Input_control_setup', addr)

    def GetControlSetup(self):
        return self.get_register('Input_control_setup')

    def SetSlaveNumOfRegisters(self, addr):
        return self.set_register('I2C_slave_num_of_registers', addr)

    def GetSlaveNumOfRegisters(self):
        return self.get_register('I2C_slave_num_of_registers')

    def SetPowerOnDelay(self, val):
        return self.set_register('Power_on_delay', val)

    def GetPowerOnDelay(self):
        return self.get_register('Power_on_delay')

    def GetBoardEEPROMParsingResult(self):
        return self.get_register('BoardEEPROM_parsing_result')

    def SetPositiveCurrentLimitIcc1c(self, val):
        return self.set_register('Positive_current_limit', val)

    def GetPositiveCurrentLimitIcc1c(self):
        return self.get_register('Positive_current_limit')

    def SetNegativeCurrentLimitIcc1c(self, val):
        return self.set_register('Negative_current_limit', val)

    def GetNegativeCurrentLimitIcc1c(self):
        return self.get_register('Negative_current_limit')

    def SetOutCalCoefPositive(self, value):
        return self._board.set_vector(self.Out_cal_coef_ch0, 0, value)

    def GetOutCalCoefPositive(self):
        return self._board.get_vector(self.Out_cal_coef_ch0, 0, 6)

    def SetOutCalCoefNegative(self, value):
        return self._board.set_vector(self.Out_cal_coef_ch1, 0, value)

    def GetOutCalCoefNegative(self):
        return self._board.get_vector(self.Out_cal_coef_ch1, 0, 6)

    def SetAinCalCoef(self, channel, value):
        return self._board.set_vector(self.Ain_cal_coef_ch0, 0, value)

    def GetAinCalCoef(self):
        return self._board.get_vector(self.Ain_cal_coef_ch0, 0, 6)

    def SetIntUCalCoef(self, channel, value):
        return self._board.set_vector(self.Int_U_cal_coef_ch0, 0, value)

    def GetIntUCalCoef(self, channel, byte_cnt=6):
        return self._board.get_vector(self.Int_U_cal_coef_ch0, 0, byte_cnt)

    def SetUinCalCoef(self, value):
        resp = self._board.set_vector(self.Uin_cal_coef, 0, value)
        return resp

    def GetUinCalCoef(self, byte_cnt=6):
        return self._board.get_vector(self.Uin_cal_coef, 0, byte_cnt)

    def GetUfeCalCoef(self, byte_cnt=6):
        return self._board.get_vector(self.Ufe_cal_coef, 0, byte_cnt)

    def SetUfeCalCoef(self, value):
        resp = self._board.set_vector(self.Ufe_cal_coef, 0, value)
        return resp

    def LockEEPROM(self, enable=True):
        if enable:
            return self.set_register('lock', 0.0)
        else:
            return self.set_register('lock', self.lock['value'])

    def SetSerialNumber(self, serial):
        return self._board.set_vector(self.serial_number, 0, serial)

    def SetCalTimestamp(self, timestamp):
        return self.set_register('Cal_timestamp', timestamp)

    def SetOutTempCalI0(self, value):
        return self._board.set_vector(self.Temp_cal_I0, 0, value)

    def GetOutTempCalI0(self):
        return self._board.get_vector(self.Temp_cal_I0, 0, 6)

    def SetOutTempCalImax(self, value):
        return self._board.set_vector(self.Temp_cal_Imax, 0, value)

    def GetOutTempCalImax(self):
        return self._board.get_vector(self.Temp_cal_Imax, 0, 6)

    def SetOutTempCalImin(self, value):
        return self._board.set_vector(self.Temp_cal_Imin, 0, value)

    def GetOutTempCalImin(self):
        return self._board.get_vector(self.Temp_cal_Imin, 0, 6)