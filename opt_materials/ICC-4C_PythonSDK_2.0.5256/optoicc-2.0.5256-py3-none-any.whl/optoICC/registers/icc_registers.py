import time
from optoKummenberg.registers.generic_registers import *
from ..tools.definitions import XPR4_CHANNEL_CNT, DeviceModel
# memory systems
from ..tools.parsing_tools import parse_error_flags_icc


## Parent class => \link optoKummenberg.registers.MiscSystems.Status Status\endlink <br>
class ICCStatus(Status):
    r"""
 * Register map:
 *
 * Address | Name                  | Default      | Description                                     | Format and value        | Access     |
 * --------|-----------------------|--------------|-------------------------------------------------|-------------------------|------------|
 * 0x1000  |FW Id                  |              |                                                 | uint32                  | read only  |
 * 0x1001  |FW Branch              |              |                                                 | uint32                  | read only  |
 * 0x1002  |FW Type                |              |                                                 | uint32                  | read only  |
 * 0x1003  |FW Version Major       |              |                                                 | uint32                  | read only  |
 * 0x1004  |FW Version Minor       |              |                                                 | uint32                  | read only  |
 * 0x1005  |FW Version Build       |              |                                                 | uint32                  | read only  |
 * 0x1006  |FW Version Revision    |              |                                                 | uint32                  | read only  |
 * 0x1007  |System status errors   | 0 - No error | Register encodes system status and errors       | Read:<br/>   Bit#<br/>0 - Channel 0 output fault condition<br/>1 - Channel 0 output had fault condition<br/>2 - Channel 1 output fault condition<br/>3 - Channel 1 output had fault condition<br/>4 - Channel 2 output fault condition<br/>5 - Channel 2 output had fault condition<br/>6 - Channel 3 output fault condition<br/>7 - Channel 3 output had fault condition<br/>8 - Driver over-heat fault<br/>9 - Driver had over-heat fault<br/>10 - Device on channel 0 not detected<br/>11 - Device on channel 0 was not detected<br/>12 - Device on channel 1 not detected<br/>13 - Device on channel 1 was not detected<br/>14 - Device on channel 2 not detected<br/>15 - Device on channel 2 was not detected<br/>16 - Device on channel 3 not detected<br/>17 - Device on channel 3 was not detected<br/>18 - Channel 0 has over-current fault on 3V3 supply line<br/>19 - Channel 0 had over-current fault on 3V3 supply line<br/>20 - Channel 1 has over-current fault on 3V3 supply line<br/>21 - Channel 1 had over-current fault on 3V3 supply line<br/>22 - Channel 2 has over-current fault on 3V3 supply line<br/>23 - Channel 2 had over-current fault on 3V3 supply line<br/>24 - Channel 3 has over-current fault on 3V3 supply line<br/>25 - Channel 3 had over-current fault on 3V3 supply line<br/>26-31 - Reserved<br/>Write:<br/> Writing to this register resets all history error flags (odd bits 1, 3, .. 25)<br/> | read write |
 * 0x1008  |Dev.EEPROM active chan.| 0 = channel 0| Register switches I2C bus among channels        | uint32                  | read write |
 * 0x1009  |Dev.detect switch mask | 0            | SW switch parallel to Dev.Det.switches          | uint32                  | read write |
 * 0x100a  |DEV_TYPE0              | 0            | get device type on channel 0                    | uint32                  | read only  |
 * 0x100b  |DEV_TYPE1              | 0            | get device type on channel 1                    | uint32                  | read only  |
 * 0x100c  |DEV_TYPE2              | 0            | get device type on channel 2                    | uint32                  | read only  |
 * 0x100d  |DEV_TYPE3              | 0            | get device type on channel 3                    | uint32                  | read only  |
 * 0x100e  |MCU ID                 | 0            | get MCU type identification number              | uint32                  | read only  |
 * 0x100f  |MCU load               | 0            | get Signal Flow execution load in %             | uint32                  | read only  |
 * 0x1010  |MCU overload counter   | 0            | increments if Signal Flow execution load > 95%  | uint32                  | read only  |
 * 0x1011  |System status warning  | 0            | Register encodes system status and warnings     | uint32                  | read only  |
 *
 *
 *
 * Vector map (vectors have their own address space):
 * Address | Name           | Default  | Description | Format and value | Access    |
 * --------|----------------|----------|-------------|------------------|-----------|
 * 0x1000  |Firmware SN     |          |             | ascii string     | read only |
 * 0x1001  |Git HEAD SHA1   |          |             | ascii string     | read only |
 * 0x1002  |MCU type string |          |             | ascii string     | read only |
 *
 *
    """
    @staticmethod
    def help():
        print(Status.__doc__)

    _is_a_system = False

    def __init__(self, board=None):
        Status.__init__(self, board=board)

        self.device_eeprom_active_channel = {'id': self.sys_id << 8 | 0x08,
                                             'type': int,
                                             'unit': None,
                                             'range': None,
                                             'default': None,
                                             'value': None}
        self.device_detect_switch_mask = {'id': self.sys_id << 8 | 0x09,
                                          'type': int,
                                          'unit': None,
                                          'range': None,
                                          'default': None,
                                          'value': None}
        self.device_type_chan0 = {'id': self.sys_id << 8 | 0x0a,
                                  'type': int,
                                  'unit': None,
                                  'range': None,
                                  'default': None,
                                  'value': None}
        self.device_type_chan1 = {'id': self.sys_id << 8 | 0x0b,
                                  'type': int,
                                  'unit': None,
                                  'range': None,
                                  'default': None,
                                  'value': None}
        self.device_type_chan2 = {'id': self.sys_id << 8 | 0x0c,
                                  'type': int,
                                  'unit': None,
                                  'range': None,
                                  'default': None,
                                  'value': None}
        self.device_type_chan3 = {'id': self.sys_id << 8 | 0x0d,
                                  'type': int,
                                  'unit': None,
                                  'range': None,
                                  'default': None,
                                  'value': None}
        self.mcu_id = {'id': self.sys_id << 8 | 0x0e,
                       'type': int,
                       'unit': None,
                       'range': None,
                       'default': None,
                       'value': None}

        self.mcu_load = {'id': self.sys_id << 8 | 0x0f,
                         'type': int,
                         'unit': None,
                         'range': None,
                         'default': None,
                         'value': None}

        self.mcu_overload_counter = {'id': self.sys_id << 8 | 0x10,
                                     'type': int,
                                     'unit': None,
                                     'range': None,
                                     'default': None,
                                     'value': None}

        self.warning_flag_register = {'id': self.sys_id << 8 | 0x11,
                                     'type': int,
                                     'unit': None,
                                     'range': None,
                                     'default': None,
                                     'value': None}

        self.mcu_type = {'id': self.sys_id << 8 | 0x02, 'type': str}

        self.name = self.__class__.__name__

    ## Gets the number of the EEPROM active channel. When reading device EEPROM, data is read from this channel.
    def GetDeviceEEPROMactiveChannel(self):
        return self.get_register('device_eeprom_active_channel')

    ## Sets the number of the EEPROM active channel. When reading device EEPROM data is read from this channel.
    def SetDeviceEEPROMactiveChannel(self, channel):
        return self.set_register('device_eeprom_active_channel', channel)

    ## Parses status register value based on active bits which are corresponding to the individual errors.
    ## This method is used inside of the method GetErrorFlagRegister
    def parse_error_flags(self, error_flag_data: int):
        return parse_error_flags_icc(error_flag_data)

    ## Gets the value of the device detect switch. SW switch parallel to Device Detect switches.
    ## (bit 0 => Channel 0, bit 1 => Channel 1,...)
    def GetDeviceDetectSwitchMask(self):
        return self.get_register('device_detect_switch_mask')

    ## Sets the value of the device detect switch. SW switch parallel to Device Detect switches.
    ## (bit 0 => Channel 0, bit 1 => Channel 1,...)
    def SetDeviceDetectSwitchMask(self, mask):
        return self.set_register('device_detect_switch_mask', mask)

    ## Gets MCU type identification number
    def GetMCUid(self):
        return self.get_register('mcu_id')

    ## Gets MCU type string
    def GetMCUtype(self, index, count):
        return self._board.get_vector(self.mcu_type, index, count)

    ## Gets the Signal Flow execution load in %
    def GetMCUload(self):
        return self.get_register('mcu_load')

    ## Counter that increments if Signal Flow execution load > 95%. This register resets after reading.
    def GetMCUoverloadCounter(self):
        return self.get_register('mcu_overload_counter')

    def GetDeviceID(self, channel) -> DeviceModel:
        reg = self.get_register('device_type_chan' + str(channel))
        return DeviceModel(reg)


class DeviceEEPROM(System):
    r"""
Device Functionality - DeviceEEPROM Read/Write
System ID: 0x21

 * | Address | Name                           | Default Value | Description                                                       | Type   | Access    |
 * |---------|--------------------------------|---------------|-------------------------------------------------------------------|--------|-----------|
 * | 0x2100  | Device EEPROM lock             | 1 (locked)    | Write the key (0x3edeb7aa) to unlock, anything else to lock.      | uint32 | read write|
 * | 0x2101  | Device EEPROM version          | N/A           |                                                                   | uint16 | read only |
 * | 0x2102  | Device EEPROM subversion       | N/A           |                                                                   | uint8  | read only |
 * | 0x2103  | Part configuration             | N/A           |                                                                   | uint8  | read only |
 * | 0x2104  | Part configuration version     | N/A           |                                                                   | uint8  | read only |
 * | 0x2105  | Maximum positive current       | N/A           |                                                                   | uint16 | read only |
 * | 0x2106  | Maximum negative current       | N/A           |                                                                   | uint16 | read only |
 * | 0x2107  | OQC result                     | N/A           | Encoding: 0x00 = None, 0x01 = Pass, 0x02 = Fail                   | uint8  | read only |
 * | 0x2108  | Production Time-stamp          | N/A           | Unix Time format (seconds since 1.1.1970)                         | uint32 | read only |
 * | 0x2109  | Force device EEPROM re-parsing | N/A           | Read register to trigger. Automatic parsing of device EEPROM happens only at system start up | uint32 | read only |
 * | 0x210A  | Device EEPROM size             | N/A           |                                                                   | uint16 | read only |
 *
 *
 *
 * Vector map (vectors have their own address space):
 * Address | Name                  | Default  | Description      | Format and value | Access    |
 * --------|-----------------------|----------|------------------|------------------|-----------|
 * 0x2100  |Firmware SN            |          | bytes up to 0x7f | bytes            | read write|
 * 0x2101  |Device serial number   |          | 8 bytes SN       | ascii string     | read only |
 *
    """

    @staticmethod
    def help():
        print(DeviceEEPROM.__doc__)

    _is_a_system = False

    def __init__(self, channel: int = 0, board=None):
        self.channel = channel
        self.sys_id = 0x21
        self.lock = {'id': self.sys_id << 8 | 0x00, 'type': float, 'unit': None, 'range': None, 'default': 0.0,
                     'value': 0.434995}
        self.eeprom_version = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None, 'range': None, 'default':
            0.0, 'value': 0}
        self.eeprom_subversion = {'id': self.sys_id << 8 | 0x02, 'type': int, 'unit': None, 'range': None, 'default':
            0.0, 'value': 0}
        self.part_config = {'id': self.sys_id << 8 | 0x03, 'type': int, 'unit': None, 'range': None,
                            'default': 0, 'value': 0}
        self.part_config_version = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None, 'range': None,
                                    'default': 0, 'value': 0}
        self.max_pos_current = {'id': self.sys_id << 8 | 0x05, 'type': float, 'unit': None, 'range': None,
                                'default': 0.0, 'value': 0}
        self.max_neg_current = {'id': self.sys_id << 8 | 0x06, 'type': float, 'unit': None, 'range': None,
                                'default': 0.0, 'value': 0}
        self.oqc_result = {'id': self.sys_id << 8 | 0x07, 'type': int, 'unit': None, 'range': None,
                           'default': 0, 'value': 0}
        self.prod_time = {'id': self.sys_id << 8 | 0x08, 'type': int, 'unit': None, 'range': None,
                          'default': 0, 'value': 0}
        self.reparse = {'id': self.sys_id << 8 | 0x09, 'type': int, 'unit': None, 'range': None, 'default': 0.0,
                        'value': 0}
        self.eeprom_size = {'id': self.sys_id << 8 | 0x0a, 'type': int, 'unit': None, 'range': None, 'default': 0.0,
                            'value': 0}
        self.eeprom = {'id': self.sys_id << 8, 'type': bytes}
        self.serial_number = {'id': self.sys_id << 8 | 0x01, 'type': bytes}

        System.__init__(self, board=board)

    def _SetEEPROMSegment(self, index, vector):
        resp = self._board.set_vector(self.eeprom, index, vector)
        return resp

    def _GetEEPROMSegment(self, index, count):
        return self._board.get_vector(self.eeprom, index, count)

    ## Enables/disables EEPROM writing
    def EEPROMLockEnable(self, enable=True):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        if enable:
            return self.set_register('lock', 0.0)
        else:
            return self.set_register('lock', self.lock['value'])

    ## Gets the EEPROM data of the device connected to this channel
    def GetEEPROM(self, index, count):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        vec = bytearray([])
        end_index = index + count
        chunk_size_in_bytes = CHUNK_SIZE * 2
        for i in range(index, index + count, chunk_size_in_bytes):
            if i + chunk_size_in_bytes > end_index:
                aux = self._GetEEPROMSegment(i, count % chunk_size_in_bytes)
            else:
                aux = self._GetEEPROMSegment(i, chunk_size_in_bytes)
            try:
                vec.extend(bytes(aux[0]))
            except IndexError:
                return vec

        return vec

    ## Sets the EEPROM data of the device connected to this channel
    def SetEEPROM(self, index, vector):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        chunk_size_in_bytes = CHUNK_SIZE * 2
        for i in range(0, len(vector), chunk_size_in_bytes):
            aux = vector[i:i + chunk_size_in_bytes]
            self._SetEEPROMSegment(i + index, aux)
        return vector

    ## Compares stored EEPROM with vector provided as parameter
    def VerifyEEPROM(self, index, vector):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        stored_eeprom = self.GetEEPROM(index, len(vector))
        return stored_eeprom == vector, stored_eeprom

    ## After writing new EEPROM, configuration needs to be reparsed by this method
    def ReparseEEPROM(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('reparse')

    ## Gets the serial number of the device connected to this channel
    def GetSerialNumber(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self._board.get_vector(self.serial_number, 0, 8)[0]

    ## Gets the EEPROM version of the device connected to this channel
    def GetEEPROMversion(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('eeprom_version')

    ## Gets the EEPROM subversion of the device connected to this channel
    def GetEEPROMsubversion(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('eeprom_subversion')

    ## Gets the part configuration of the device connected to this channel
    def GetPartConfig(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('part_config')

    ## Gets the part configuration version of the device connected to this channel
    def GetPartConfigVersion(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('part_config_version')

    ## Gets the maximum positive current value (as absolute value) of the device connected to this channel
    def GetMaxPosCurrent(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('max_pos_current')

    ## Gets the maximum negative current value (as absolute value) of the device connected to this channel
    def GetMaxNegCurrent(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('max_neg_current')

    ## Gets the OQC result of the device connected to this channel
    def GetOQCresult(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('oqc_result')

    ## Gets the production timestamp of the device connected to this channel
    def GetProdTime(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('prod_time')

    ## Gets the size of the EEPROM (in bytes) of the device connected to this channel
    def GetEEPROMSize(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('eeprom_size')

    def SetSerialNumber(self, serial):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self._board.set_vector(self.serial_number, 0, serial)

    def SetMaxPosCurrent(self, posCurrent):
        return self.set_register('max_pos_current', posCurrent)

    def SetMaxNegCurrent(self, negCurrent):
        return self.set_register('max_neg_current', negCurrent)


class ICCTemperatureManager(System):
    r"""
Device Functionality - Device Temperature Readout
System ID: 0x22

 * | Address | Name                                      | Default | Description     | Type  | Access
 * |---------|-------------------------------------------|---------|-----------------|-------|-----------
 * | 0x2200  | Device temperature                        | N/A     | Degrees Celsius | float | read only
 * | 0x2201  | Device temperature threshold              | 80      | Degrees Celsius. If this threshold is reached the output of the driver is disabled to cool down. Temperature has to fall by 10 degrees so that the output is enabled again | float | read write
 * | 0x2202  | Driver output stage temperature           | N/A     | Degrees Celsius | float | read only
 * | 0x2203  | Driver output stage temperature threshold | 80      | Degrees Celsius. If this threshold is reached the output of the driver is disabled to cool down. Temperature has to fall by 10 degrees so that the output is enabled again | float | read/write
 * | 0x2204  | Driver power supply temperature           | N/A     | Degrees Celsius | float | read only
 * | 0x2205  | Driver power supply temperature threshold | 80      | Degrees Celsius. If this threshold is reached the output of the driver is disabled to cool down. Temperature has to fall by 10 degrees so that the output is enabled again | float | read write
 * | 0x2206  | MCU temperature                           | N/A     | Degrees Celsius | float | read only
 * | 0x2207  | MCU temperature threshold                 | 90      | Degrees Celsius. If this threshold is reached the MCU of the driver is disabled to cool down. Temperature has to fall by 10 degrees so that the output is enabled again | float | read write
    """

    @staticmethod
    def help():
        print(ICCTemperatureManager.__doc__)

    _is_a_system = False

    def __init__(self, board=None):
        self.sys_id = 0x22

        self.device_temperature = {'id': self.sys_id << 8 | 0x00, 'type': float, 'unit': '°C', 'range': None,
                                   'default': None, 'value': None}
        self.device_temp_threshold = {'id': self.sys_id << 8 | 0x01, 'type': float, 'unit': '°C', 'range': None,
                                      'default': None, 'value': None}

        self.board_out_temperature = {'id': self.sys_id << 8 | 0x02, 'type': float, 'unit': '°C', 'range': None,
                                      'default': None, 'value': None}
        self.board_out_threshold = {'id': self.sys_id << 8 | 0x03, 'type': float, 'unit': '°C', 'range': None,
                                    'default': None, 'value': None}
        self.board_pwr_temperature = {'id': self.sys_id << 8 | 0x04, 'type': float, 'unit': '°C', 'range': None,
                                      'default': None, 'value': None}
        self.board_pwr_threshold = {'id': self.sys_id << 8 | 0x05, 'type': float, 'unit': '°C', 'range': None,
                                    'default': None, 'value': None}
        self.board_mcu_temperature = {'id': self.sys_id << 8 | 0x06, 'type': float, 'unit': '°C', 'range': None,
                                    'default': None, 'value': None}
        self.board_mcu_threshold = {'id': self.sys_id << 8 | 0x07, 'type': float, 'unit': '°C', 'range': None,
                                    'default': None, 'value': None}
        System.__init__(self, board=board)

    ## Gets actual device temperature of the active channel. Active cahnnel is set by
    # 'Status.SetDeviceEEPROMactiveChannel(channel_index)'. This temperature can be also obtained by
    # channel's TemperatureManager 'Channel_0.TemperatureManager.GetDeviceTemperature()'
    def GetDeviceTemperature(self):
        return self.get_register('device_temperature')

    ## Gets device temperature threshold of the active channel. Active cahnnel is set by
    # 'Status.SetDeviceEEPROMactiveChannel(channel_index)'. If this threshold is reached the output of the driver is
    # disabled to cool down. Temperature has to fall by 10 degrees so that the output is enabled again. This temperature
    # threshold can be also obtained by channel's TemperatureManager
    # 'Channel_0.TemperatureManager.GetDeviceTemperatureThreshold()'
    def GetDeviceTemperatureThreshold(self):
        return self.get_register('device_temp_threshold')

    ## Sets device temperature threshold of the active channel. Active cahnnel is set by
    # 'Status.SetDeviceEEPROMactiveChannel(channel_index)'. If this threshold is reached the output of the driver is
    # disabled to cool down. Temperature has to fall by 10 degrees so that the output is enabled again. This temperature
    # threshold can be also obtained by channel's TemperatureManager
    # 'Channel_0.TemperatureManager.GetDeviceTemperatureThreshold()'
    def SetDeviceTemperatureThreshold(self, threshold=0):
        return self.set_register('device_temp_threshold', threshold)

    ## Gets driver output stage temperature
    def GetBoardOutTemperature(self):
        return self.get_register('board_out_temperature')

    ## Gets driver output stage temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def GetBoardOutTemperatureThreshold(self):
        return self.get_register('board_out_threshold')

    ## Sets driver output stage temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def SetBoardOutTemperatureThreshold(self, threshold=0):
        return self.set_register('board_out_threshold', threshold)

    ## Gets driver power supply temperature
    def GetBoardPowTemperature(self):
        return self.get_register('board_pwr_temperature')

    ## Gets driver power supply temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def GetBoardPowTemperatureThreshold(self):
        return self.get_register('board_pwr_threshold')

    ## Sets driver power supply temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def SetBoardPowTemperatureThreshold(self, threshold=0):
        return self.set_register('board_pwr_threshold', threshold)

    ## Gets Micro-controller unit temperature
    def GetBoardMcuTemperature(self):
        return self.get_register('board_mcu_temperature')

    ## Gets Micro-controller unit temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def GetBoardMcuTemperatureThreshold(self):
        return self.get_register('board_mcu_threshold')

    ## Sets Micro-controller unit temperature threshold. If this threshold is reached the output of the driver is disabled
    # to cool down. Temperature has to fall by 10 degrees so that the output is enabled again
    def SetBoardMcuTemperatureThreshold(self, threshold=0):
        return self.set_register('board_mcu_threshold', threshold)


class ICCMiscFeatures(System):
    """
/*
 * \page MiscFeatures Miscellaneous Features
 *
 * Miscellaneous Features system ID : <b>0x25</b>
 *
 * ### Register Map:
 *
 *  | Address | Name                             | Default Value | Description                                                      | Type   |  Access    |
 *  | --------|----------------------------------|---------------|------------------------------------------------------------------|------- | -----------|
 *  | 0x2500  | Reset firmware                   | N/A           | Reading triggers function                                        | uint32 | read only  |
 *  | 0x2501  | FrontEnd power state             | false=0       | Setting of FrontEnd power supply state                           | boolean| read write |
 *  | 0x2502  | FrontEnd voltage                 | 12.0          | Setting of FrontEnd supply voltage [V]                           | float  | read write |
 *  | 0x2503  | Output stage PWM frequency       | 1000          | Setting of PWM frequency [400, 500, 600, 1000 and 1200 kHz]      | uint32 | read write |
 *  | 0x2504  | Enable output stage channel 0    | false=0       | Setting of output stage state channel 0                          | boolean| read write |
 *  | 0x2505  | Enable output stage channel 1    | false=0       | Setting of output stage state channel 1                          | boolean| read write |
 *  | 0x2506  | Enable output stage channel 2    | false=0       | Setting of output stage state channel 2                          | boolean| read write |
 *  | 0x2507  | Enable output stage channel 3    | false=0       | Setting of output stage state channel 3                          | boolean| read write |
 *  | 0x2508  | ADCI0						     | N/A	         | Reading of current on channel 0                                  | float  | read only  |
 *  | 0x2509  | ADCI1						     | N/A	         | Reading of current on channel 1                                  | float  | read only  |
 *  | 0x250a  | ADCI2						     | N/A	         | Reading of current on channel 2                                  | float  | read only  |
 *  | 0x250b  | ADCI3						     | N/A	         | Reading of current on channel 3                                  | float  | read only  |
 *  | 0x250c  | ADCV0						     | N/A	         | Reading of voltage on channel 0                                  | float  | read only  |
 *  | 0x250d  | ADCV1						     | N/A	         | Reading of voltage on channel 1                                  | float  | read only  |
 *  | 0x250e  | ADCV2						     | N/A	         | Reading of voltage on channel 2                                  | float  | read only  |
 *  | 0x250f  | ADCV3						     | N/A	         | Reading of voltage on channel 3                                  | float  | read only  |
 *  | 0x2510  | DEV_POWER0					     | 0	         | Setting 3v3 for device on channel 0                              | uint32 | read write |
 *  | 0x2511  | DEV_POWER1					     | 0	         | Setting 3v3 for device on channel 1                              | uint32 | read write |
 *  | 0x2512  | DEV_POWER2					     | 0	         | Setting 3v3 for device on channel 2                              | uint32 | read write |
 *  | 0x2513  | DEV_POWER3					     | 0	         | Setting 3v3 for device on channel 3                              | uint32 | read write |
 *  | 0x2514  | DEV_MODEL0					     | 0	         | get \ref DeviceModel on channel 0                                | uint32 | read only  |
 *  | 0x2515  | DEV_MODEL1					     | 0	         | get \ref DeviceModel on channel 1                                | uint32 | read only  |
 *  | 0x2516  | DEV_MODEL2					     | 0	         | get \ref DeviceModel on channel 2  		                        | uint32 | read only  |
 *  | 0x2517  | DEV_MODEL3					     | 0	         | get \ref DeviceModel on channel 3          		                | uint32 | read only  |
 *  | 0x2518  | Uin							     | N/A	         | Reading input voltage		                                    | float  | read only  |
 *  | 0x2519  | Iin							     | N/A	         | Reading input current		                                    | float  | read only  |
 *  | 0x251a  | Ufe							     | N/A	         | Reading FE voltage			                                    | float  | read only  |
 *  | 0x251b  | ANLGIN0						     | N/A	         | Reading of analog input channel 0                                | float  | read only  |
 *  | 0x251c  | ANLGIN1						     | N/A	         | Reading of analog input channel 1                                | float  | read only  |
 *  | 0x251d  | ANLGIN2						     | N/A	         | Reading of analog input channel 2                                | float  | read only  |
 *  | 0x251e  | ANLGIN3						     | N/A	         | Reading of analog input channel 3                                | float  | read only  |
 *  | 0x251f  | AUTO_CONFIG     			     | 0	         | Reading returns parameter value stored in driver's board eeprom <br/> Writing (1=internal, 2=ext.triger) starts auto-actuation (0=off) | uint32 | read write |
 *  | 0x2520  | WRITE_CTRL                       | 0             | Reading returns WC state, writing sets state of WC output signal | uint32 | read write |
 *  | 0x2521  | LOAD_CH0                         | 0	         | Reading load resistance on channel 0 (set some DC current before)| float  | read only  |
 *  | 0x2522  | LOAD_CH1                         | 0	         | Reading load resistance on channel 1 (set some DC current before)| float  | read only  |
 *  | 0x2523  | LOAD_CH2                         | 0	         | Reading load resistance on channel 2 (set some DC current before)| float  | read only  |
 *  | 0x2524  | LOAD_CH3                         | 0	         | Reading load resistance on channel 3 (set some DC current before)| float  | read only  |
 *  | 0x2525  | Enable calibration coefficients  | true=1 *(1)   | Enable calibration coefficients for measurements in this system  | boolean| read write |
 *  | 0x2526  | SET_STATE         			     | -	         | 1 set driver to init state, 2 set to project independent default | uint32 | write only |
 *  | 0x2527  | GPIO_STATE                       | 0             | Set logical level on GPIO pins (bitwise; 0=LOW, 1=HIGH)          | Bit#<br/>0 - external GPIO0<br/>1 - external GPIO1<br/>2 - external GPIO2<br/>3 - external GPIO3<br/>4 - internal GPIO_IN0<br/>5 - internal GPIO_IN1<br/>6 - internal GPIO_IN4<br/>7 - internal GPIO_IN5| read write |
 *  | 0x2528  | GPIO_DIRECTION                   | 0             | Set direction of GPIO pins (bitwise; 0=INPUT, 1=OUTPUT)          | Bit#<br/>0 - external GPIO0<br/>1 - external GPIO1<br/>2 - external GPIO2<br/>3 - external GPIO3<br/>4 - internal GPIO_IN0<br/>5 - internal GPIO_IN1<br/>6 - internal GPIO_IN4<br/>7 - internal GPIO_IN5| read write |
 *  | 0x2529  | FB_MODE						     | 0	         | Set feedback mode bitwise per channel (0=current, 1=voltage) *(2)| uint32 | read write |
 *  | 0x252A  | Pin_avg						     | N/A	         | Reading average input power (integration time = 1 second)        | float  | read only  |
 *  *(1) Calibration coefficients are enabled for measurements in this system only in official ICC-4-C builds<br/>
 *  *(2) Feedback mode selection is available only on drivers with HW revision 2 and greater
 *
 * The Miscellaneous system supports the following vectors (vectors have their own address space):
 *
 * | Address | Name                           | Default     | Description                            | Format and value    |
 * |---------|--------------------------------|-------------|----------------------------------------|---------------------|
 * | 0x2500  | i2c address list on channel0   |   0         | 16 bytes representing specific address | 4*int32, read only  |
 * | 0x2501  | i2c address list on channel1   |   0         | 16 bytes representing specific address | 4*int32, read only  |
 * | 0x2502  | i2c address list on channel2   |   0         | 16 bytes representing specific address | 4*int32, read only  |
 * | 0x2503  | i2c address list on channel3   |   0         | 16 bytes representing specific address | 4*int32, read only  |
 * | 0x2504  | output current all channels    |   0         | 16 bytes, 4 floats for each channel    | 4*float, read only  |
 * | 0x2505  | output voltage all channels    |   0         | 16 bytes, 4 floats for each channel    | 4*float, read only  |
 * | 0x2506  | load resistance all channels   |   0         | 16 bytes, 4 floats for each channel    | 4*float, read only  |
 * | 0x2507  | analog inputs all channels     |   0         | 16 bytes, 4 floats for each channel    | 4*float, read only  |
 * | 0x2508  | out.current calib.coef. chan#0 |{0,1,0,0,0,0}| 5th grade polynomial for chan#0        | 6*float, read write |
 * | 0x2509  | out.current calib.coef. chan#1 |{0,1,0,0,0,0}| 5th grade polynomial for chan#1        | 6*float, read write |
 * | 0x250A  | out.current calib.coef. chan#2 |{0,1,0,0,0,0}| 5th grade polynomial for chan#2        | 6*float, read write |
 * | 0x250B  | out.current calib.coef. chan#3 |{0,1,0,0,0,0}| 5th grade polynomial for chan#3        | 6*float, read write |
 * | 0x250C  | out.voltage calib.coef. chan#0 |{0,1,0,0,0,0}| 5th grade polynomial for chan#0        | 6*float, read write |
 * | 0x250D  | out.voltage calib.coef. chan#1 |{0,1,0,0,0,0}| 5th grade polynomial for chan#1        | 6*float, read write |
 * | 0x250E  | out.voltage calib.coef. chan#2 |{0,1,0,0,0,0}| 5th grade polynomial for chan#2        | 6*float, read write |
 * | 0x250F  | out.voltage calib.coef. chan#3 |{0,1,0,0,0,0}| 5th grade polynomial for chan#3        | 6*float, read write |
 * | 0x2510  | analog input calib.coef.chan#0 |{0,1,0,0,0,0}| 5th grade polynomial for chan#0        | 6*float, read write |
 * | 0x2511  | analog input calib.coef.chan#1 |{0,1,0,0,0,0}| 5th grade polynomial for chan#1        | 6*float, read write |
 * | 0x2512  | analog input calib.coef.chan#2 |{0,1,0,0,0,0}| 5th grade polynomial for chan#2        | 6*float, read write |
 * | 0x2513  | analog input calib.coef.chan#3 |{0,1,0,0,0,0}| 5th grade polynomial for chan#3        | 6*float, read write |
 * | 0x2514  | Uin voltage calib.coefficient  |{0,1,0,0,0,0}| 5th grade polynomial                   | 6*float, read write |
 * | 0x2515  | Iin voltage calib.coefficient  |{0,1,0,0,0,0}| 5th grade polynomial                   | 6*float, read write |
 * | 0x2516  | Ufe voltage calib.coefficient  |{0,1,0,0,0,0}| 5th grade polynomial                   | 6*float, read write |
 *
*/
    """

    @staticmethod
    def help():
        print(ICCMiscFeatures.__doc__)

    _is_a_system = True

    def __init__(self, board=None):
        self.sys_id = 0x25
        self.reset_FW = {'id': self.sys_id << 8 | 0x00, 'type': int, 'unit': None, 'range': None, 'default': None,
                         'value': None}
        self.FE_power = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None, 'range': None, 'default': None,
                         'value': None}
        self.FE_voltage = {'id': self.sys_id << 8 | 0x02, 'type': float, 'unit': None, 'range': None, 'default': None,
                           'value': None}
        self.PWM_frequency = {'id': self.sys_id << 8 | 0x03, 'type': int, 'unit': None, 'range': None, 'default': None,
                              'value': None}
        self.enable_out0 = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.enable_out1 = {'id': self.sys_id << 8 | 0x05, 'type': int, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.enable_out2 = {'id': self.sys_id << 8 | 0x06, 'type': int, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.enable_out3 = {'id': self.sys_id << 8 | 0x07, 'type': int, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.ADCI0 = {'id': self.sys_id << 8 | 0x08, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.ADCI1 = {'id': self.sys_id << 8 | 0x09, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.ADCI2 = {'id': self.sys_id << 8 | 0x0a, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.ADCI3 = {'id': self.sys_id << 8 | 0x0b, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.ADCV0 = {'id': self.sys_id << 8 | 0x0c, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.ADCV1 = {'id': self.sys_id << 8 | 0x0d, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.ADCV2 = {'id': self.sys_id << 8 | 0x0e, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.ADCV3 = {'id': self.sys_id << 8 | 0x0f, 'type': float, 'unit': None, 'range': None, 'default': None,
                      'value': None}
        self.DEV_POWER0 = {'id': self.sys_id << 8 | 0x10, 'type': int, 'unit': None, 'range': None, 'default': None,
                           'value': None}
        self.DEV_POWER1 = {'id': self.sys_id << 8 | 0x11, 'type': int, 'unit': None, 'range': None, 'default': None,
                           'value': None}
        self.DEV_POWER2 = {'id': self.sys_id << 8 | 0x12, 'type': int, 'unit': None, 'range': None, 'default': None,
                           'value': None}
        self.DEV_POWER3 = {'id': self.sys_id << 8 | 0x13, 'type': int, 'unit': None, 'range': None, 'default': None,
                           'value': None}
        self.DEV_TYPE0 = {'id': self.sys_id << 8 | 0x14, 'type': int, 'unit': None, 'range': None, 'default': None,
                          'value': None}
        self.DEV_TYPE1 = {'id': self.sys_id << 8 | 0x15, 'type': int, 'unit': None, 'range': None, 'default': None,
                          'value': None}
        self.DEV_TYPE2 = {'id': self.sys_id << 8 | 0x16, 'type': int, 'unit': None, 'range': None, 'default': None,
                          'value': None}
        self.DEV_TYPE3 = {'id': self.sys_id << 8 | 0x17, 'type': int, 'unit': None, 'range': None, 'default': None,
                          'value': None}
        self.UIN = {'id': self.sys_id << 8 | 0x18, 'type': float, 'unit': None, 'range': None, 'default': None,
                    'value': None}
        self.IIN = {'id': self.sys_id << 8 | 0x19, 'type': float, 'unit': None, 'range': None, 'default': None,
                    'value': None}
        self.UFE = {'id': self.sys_id << 8 | 0x1a, 'type': float, 'unit': None, 'range': None, 'default': None,
                    'value': None}
        self.AIN0 = {'id': self.sys_id << 8 | 0x1b, 'type': float, 'unit': None, 'range': None, 'default': None,
                     'value': None}
        self.AIN1 = {'id': self.sys_id << 8 | 0x1c, 'type': float, 'unit': None, 'range': None, 'default': None,
                     'value': None}
        self.AIN2 = {'id': self.sys_id << 8 | 0x1d, 'type': float, 'unit': None, 'range': None, 'default': None,
                     'value': None}
        self.AIN3 = {'id': self.sys_id << 8 | 0x1e, 'type': float, 'unit': None, 'range': None, 'default': None,
                     'value': None}
        self.AUTO_CONFIG = {'id': self.sys_id << 8 | 0x1f, 'type': int, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.WRITE_CTRL = {'id': self.sys_id << 8 | 0x20, 'type': int, 'unit': None, 'range': None, 'default': None,
                           'value': None}
        self.LOAD_CH0 = {'id': self.sys_id << 8 | 0x21, 'type': float, 'unit': None, 'range': None, 'default': None,
                         'value': None}
        self.LOAD_CH1 = {'id': self.sys_id << 8 | 0x22, 'type': float, 'unit': None, 'range': None, 'default': None,
                         'value': None}
        self.LOAD_CH2 = {'id': self.sys_id << 8 | 0x23, 'type': float, 'unit': None, 'range': None, 'default': None,
                         'value': None}
        self.LOAD_CH3 = {'id': self.sys_id << 8 | 0x24, 'type': float, 'unit': None, 'range': None, 'default': None,
                         'value': None}
        self.enable_calibration = {'id': self.sys_id << 8 | 0x25, 'type': int, 'unit': None, 'range': None,
                                   'default': None, 'value': None}
        self.DEFAULT_STATE = {'id': self.sys_id << 8 | 0x26, 'type': int, 'unit': None, 'range': None, 'default': None,
                              'value': None}
        self.GPIO_STATE = {'id': self.sys_id << 8 | 0x27, 'type': int, 'unit': None, 'range': None, 'default': None,
                              'value': None}
        self.GPIO_DIRECTION = {'id': self.sys_id << 8 | 0x28, 'type': int, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.FB_MODE = {'id': self.sys_id << 8 | 0x29, 'type': int, 'unit': None, 'range': None, 'default': None,
                              'value': None}
        self.Pin_avg = {'id': self.sys_id << 8 | 0x2a, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}

        self.i2c_list_ch0 = {'id': self.sys_id << 8 | 0x00, 'type': bytes}
        self.i2c_list_ch1 = {'id': self.sys_id << 8 | 0x01, 'type': bytes}
        self.i2c_list_ch2 = {'id': self.sys_id << 8 | 0x02, 'type': bytes}
        self.i2c_list_ch3 = {'id': self.sys_id << 8 | 0x03, 'type': bytes}
        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    ## Resets firmware of the driver
    def ResetFW(self):
        self.get_register('reset_FW')

    ## Gets the frontend power supply state, 0 = false, 1 = true
    def GetFEpower(self):
        return self.get_register('FE_power')

    ## Sets the frontend power supply state, 0 = false, 1 = true
    def SetFEpower(self, state=0):
        return self.set_register('FE_power', state)

    ## Gets the frontend supply voltage, default is 12.0 V
    def GetFEvoltage(self):
        return self.get_register('FE_voltage')

    ## Sets the frontend supply voltage, default is 12.0 V
    def SetFEvoltage(self, voltage=12.0):
        return self.set_register('FE_voltage', voltage)

    ## Gets the output stage PWM frequency. Supported frequencies: 400,500,600,1000,1200
    def GetPWMfrequency(self):
        freq = self.get_register('PWM_frequency')
        if (freq == 0):
            return 400
        if (freq == 1):
            return 500
        if (freq == 2):
            return 600
        if (freq == 3):
            return 1000
        if (freq == 4):
            return 1200
        else:
            return 0

    ## Sets the output stage PWM frequency. Supported frequencies: 400,500,600,1000,1200
    def SetPWMfrequency(self, frequency=1000):
        freq = -1
        if frequency == 400:
            freq = 0
        if frequency == 500:
            freq = 1
        if frequency == 600:
            freq = 2
        if frequency == 1000:
            freq = 3
        if frequency == 1200:
            freq = 4

        if freq != -1:
            return self.set_register('PWM_frequency', freq)
        else:
            raise Exception("Frequency value not supported (supported frequencies: 400,500,600,1000,1200)")

    ## Gets enable output stage flag for specific channel, 0 = disabled, 1 = enabled
    def GetOutputState(self, channel):
        return self.get_register('enable_out' + str(channel))

    ## Sets enable output stage flag for specific channel, 0 = disabled, 1 = enabled
    def SetOutputState(self, channel, state=0):
        return self.set_register('enable_out' + str(channel), state)

    ## Reads current [A] on specific channel
    def GetADCcurrent(self, channel=0):
        return self.get_register('ADCI' + str(channel))

    ## Reads voltage [V] on specific channel
    def GetADCvoltage(self, channel=0):
        return self.get_register('ADCV' + str(channel))

    ## Gets 3v3 for device on specific channel
    def GetDevicePower(self, channel):
        return self.get_register('DEV_POWER' + str(channel))

    ## Sets 3v3 for device on specific channel
    def SetDevicePower(self, channel, state=0):
        return self.set_register('DEV_POWER' + str(channel), state)

    ## Gets device type connected to specific channel
    def GetDeviceType(self, channel) -> DeviceModel:
        reg = self.get_register('DEV_TYPE' + str(channel))
        return DeviceModel(reg)

    ## Gets input voltage
    def GetUIN(self):
        return self.get_register('UIN')

    ## Gets input current
    def GetIIN(self):
        return self.get_register('IIN')

    ## Gets FE voltage
    def GetUFE(self):
        return self.get_register('UFE')

    ## Gets analog input voltage on specific channel
    def GetAnalogInput(self, channel=0):
        return self.get_register('AIN' + str(channel))

    ## Gets load resistance on specific channel
    def GetResistance(self, channel=0):
        return self.get_register('LOAD_CH' + str(channel))

    ## Gets parameter value stored in driver's board eeprom, 0 = off, 1 = internal, 2 = ext. trigger
    def GetAutoConfig(self):
        return self.get_register('AUTO_CONFIG')

    ## Sets autoconfig type, 0 = off, 1 = internal, 2 = ext. trigger
    def SetAutoConfig(self, value):
        return self.set_register('AUTO_CONFIG', value)

    ## Gets WC state
    def GetWcState(self):
        return self.get_register('WRITE_CTRL')

    ## Sets state of WC output signal
    def SetWcState(self, value):
        return self.set_register('WRITE_CTRL', value)

    ## Enables/disables calibration coefficients for measurements in this system, 0 = disabled, 1 = enabled
    def EnableCalCoefficients(self, enable=1):
        return self.set_register('enable_calibration', enable)

    ## Sets driver state, 1 = init state, 2 = project independent default
    def SetDefaultState(self, state):
        return self.set_register('DEFAULT_STATE', state)

    ## Gets logical level on GPIO pins (bitwise), 0 = LOW, 1 = HIGH
    def GetGPIOstate(self):
        return self.get_register('GPIO_STATE')

    ## Sets logical level on GPIO pins (bitwise), 0 = LOW, 1 = HIGH
    def SetGPIOstate(self, state=0):
        return self.set_register('GPIO_STATE', state)

    ## Gets direction of GPIO pins (bitwise), 0 = INPUT, 1 = OUTPUT
    def GetGPIOdirection(self):
        return self.get_register('GPIO_DIRECTION')

    ## Sets direction of GPIO pins (bitwise), 0 = INPUT, 1 = OUTPUT
    def SetGPIOdirection(self, direction=0):
        return self.set_register('GPIO_DIRECTION', direction)

    ## Gets feedback mode bitwise per channel, 0 = current, 1 = voltage
    def GetFeedbackMode(self):
        return self.get_register('FB_MODE')

    ## Sets feedback mode bitwise per channel, 0 = current, 1 = voltage
    def SetFeedbackMode(self, state=0):
        return self.set_register('FB_MODE', state)

    ## Gets average input power (integration time = 1 second)
    def GetAverageInputPower(self):
        return self.get_register('Pin_avg')

    ## Gets 16 bytes representing specific I2C address for specific channel
    def GetI2CList(self, channel):
        if channel == 0:
            return self._board.get_vector(self.i2c_list_ch0, 0, 16)[0]
        if channel == 1:
            return self._board.get_vector(self.i2c_list_ch1, 0, 16)[0]
        if channel == 2:
            return self._board.get_vector(self.i2c_list_ch2, 0, 16)[0]
        if channel == 3:
            return self._board.get_vector(self.i2c_list_ch3, 0, 16)[0]


class LensCompensation(System):
    """
/*
 * \page LensCompensation Lens Compensation
 *
 * Lens compensation system ID : <b>0xC8</b>
 *
 * ### Register Map:
 *
 *  | Address | Name                         | Default Value | Description                      | Type   |  Access
 *  | --------|------------------------------|---------------|----------------------------------|------- | --------
 *  0xC[8-F]00 | diopter                     | 0.0           | diopter                          | float  | read only
 *  0xC[8-F]01 | current                     | 0.0           | output current                   | float  | read only
 *  0xC[8-F]02 | filtercoefficent_a          | 0.0           | filtercoefficent_a               | float  | read only
 *  0xC[8-F]03 | filtercoefficent_b          | 0.0           | filtercoefficent_b               | float  | read only
 *  0xC[8-F]04 | xv_creepcompensation_act    | 0.0           | xv_creepcompensation_act         | float  | read only
 *  0xC[8-F]05 | xv_creepcompensation_old    | 0.0           | xv_creepcompensation_old         | float  | read only
 *  0xC[8-F]06 | yv_creepcompensation_act    | 0.0           | yv_creepcompensation_act         | float  | read only
 *  0xC[8-F]07 | yv_creepcompensation_old    | 0.0           | yv_creepcompensation_old         | float  | read only
 *  0xC[8-F]08 | Gain_Variable               | 1             | Gain_Variable                    | float  | read only
 *  0xC[8-F]09 | creepcompensation           | 0.0           | creepcompensation                | float  | read only
 *  0xC[8-F]0A | part_config                 | 0             | part_config                      | float  | read write
 *  0xC[8-F]0B | driftValue	                 | 0.0	         | driftValue	                    | float	 | read only
 *  0xC[8-F]0C | minLimitForYellowFlag	     | 0.0	         | min Limit For Yellow Flag	    | float	 | read only
 *  0xC[8-F]0D | maxLimitForYellowFlag	     | 0.0	         | max Limit For Yellow Flag	    | float	 | read only
 *  0xC[8-F]0E | minLimitForRedFlag	         | 0.0	         | min Limit For Red Flag	        | float	 | read only
 *  0xC[8-F]0F | maxLimitForRedFlag	         | 0.0	         | max Limit For Red Flag	        | float	 | read only
 *  0xC[8-F]10 | minLimitForScrollFlag	     | 0.0	         | min Limit For Scroll Flag	    | float	 | read only
 *  0xC[8-F]11 | maxLimitForScrollFlag	     | 0.0	         | max Limit For Scroll Flag	    | float	 | read only
 *  0xC[8-F]12 | minGuaranteedTemperature	 | 0.0	         | min guaranteed Temperature	    | float	 | read write
 *  0xC[8-F]13 | maxGuaranteedTemperature	 | 0.0	         | max guaranteed Temperature	    | float	 | read write
*/
    """

    @staticmethod
    def help():
        print(LensCompensation.__doc__)

    _is_a_system = True

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0xC8 | channel
        self.diopter = {'id': self.sys_id << 8 | 0x00, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.current = {'id': self.sys_id << 8 | 0x01, 'type': float, 'unit': None, 'range': None, 'default': None,
                        'value': None}
        self.filtercoefficent_a = {'id': self.sys_id << 8 | 0x02, 'type': float, 'unit': None, 'range': None,
                                   'default': None, 'value': None}
        self.filtercoefficent_b = {'id': self.sys_id << 8 | 0x03, 'type': float, 'unit': None, 'range': None,
                                   'default': None, 'value': None}
        self.xv_creepcompensation_act = {'id': self.sys_id << 8 | 0x04, 'type': float, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.xv_creepcompensation_old = {'id': self.sys_id << 8 | 0x05, 'type': float, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.yv_creepcompensation_act = {'id': self.sys_id << 8 | 0x06, 'type': float, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.yv_creepcompensation_old = {'id': self.sys_id << 8 | 0x07, 'type': float, 'unit': None, 'range': None,
                                         'default': None, 'value': None}
        self.Gain_Variable = {'id': self.sys_id << 8 | 0x08, 'type': float, 'unit': None, 'range': None, 'default':
            None, 'value': None}
        self.creepcompensation = {'id': self.sys_id << 8 | 0x09, 'type': float, 'unit': None, 'range': None,
                                  'default': None, 'value': None}
        self.part_config = {'id': self.sys_id << 8 | 0x0A, 'type': int, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.drift_value = {'id': self.sys_id << 8 | 0x0B, 'type': float, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.min_lim_yellow = {'id': self.sys_id << 8 | 0x0C, 'type': float, 'unit': None, 'range': None,
                               'default': None,
                               'value': None}
        self.max_lim_yellow = {'id': self.sys_id << 8 | 0x0D, 'type': float, 'unit': None, 'range': None,
                               'default': None,
                               'value': None}
        self.min_lim_red = {'id': self.sys_id << 8 | 0x0E, 'type': float, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.max_lim_red = {'id': self.sys_id << 8 | 0x0F, 'type': float, 'unit': None, 'range': None, 'default': None,
                            'value': None}
        self.min_lim_scroll = {'id': self.sys_id << 8 | 0x10, 'type': float, 'unit': None, 'range': None,
                               'default': None,
                               'value': None}
        self.max_lim_scroll = {'id': self.sys_id << 8 | 0x11, 'type': float, 'unit': None, 'range': None,
                               'default': None,
                               'value': None}
        self.min_gua_temperature = {'id': self.sys_id << 8 | 0x12, 'type': float, 'unit': None, 'range': None,
                                    'default': None,
                                    'value': None}
        self.max_gua_temperature = {'id': self.sys_id << 8 | 0x13, 'type': float, 'unit': None, 'range': None,
                                    'default': None,
                                    'value': None}

        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    ## Gets actual current
    def GetCurrent(self):
        return self.get_register('current')

    ## Gets actual diopter
    def GetDiopter(self):
        return self.get_register('diopter')

    def GetFilterCoefficent_a(self):
        return self.get_register('filtercoefficent_a')

    def GetFilterCoefficent_b(self):
        return self.get_register('filtercoefficent_b')

    def GetXv_creepCompensation_act(self):
        return self.get_register('xv_creepcompensation_act')

    def GetXv_creepCompensation_old(self):
        return self.get_register('xv_creepcompensation_old')

    def GetYv_creepCompensation_act(self):
        return self.get_register('yv_creepcompensation_act')

    def GetYv_creepCompensation_old(self):
        return self.get_register('yv_creepcompensation_old')

    def GetGain_Variable(self):
        return self.get_register('Gain_Variable')

    def SetGain_Variable(self, value):
        return self.set_register('Gain_Variable', value)

    def GetCreepCompensation(self):
        return self.get_register('creepcompensation')

    def GetPart_config(self):
        return self.get_register('part_config')

    def SetPart_config(self, value):
        return self.set_register('part_config', value)

    def GetDrift_value(self):
        return self.get_register('drift_value')

    def GetMinYellowFlag_value(self):
        return self.get_register('min_lim_yellow')

    def GetMaxYellowFlag_value(self):
        return self.get_register('max_lim_yellow')

    def GetMinRedFlag_value(self):
        return self.get_register('min_lim_red')

    def GetMaxRedFlag_value(self):
        return self.get_register('max_lim_red')

    def GetMinScrollFlag_value(self):
        return self.get_register('min_lim_scroll')

    def GetMaxScrollFlag_value(self):
        return self.get_register('max_lim_scroll')

    def GetMaxDiopter(self):
        return self.GetMaxScrollFlag_value()

    def GetMinDiopter(self):
        return self.GetMinScrollFlag_value()


## Parent class => \link optoKummenberg.registers.InputStage.StaticInput StaticInput\endlink <br>
class ICCStaticInput(StaticInput):
    r"""
        Input Channel Systems - USB/UART
        System IDs: 0x50 through 0x57

        +----------------+------+-------------+----------+-------------+---------+---------------------------------------+
        | Register Name  | Id   | Type        | Unit     | Range       | Default | Comment                               |
        +================+======+=============+==========+=============+=========+=======================================+
        | current        | 0x00 | float 32-bit| A        | -0.7 to 0.7 | 0.0     | Static input in amperes.              |
        +----------------+------+-------------+----------+-------------+---------+---------------------------------------+
        | active_input   | 0x03 | float 32-bit| None     |             | 0.0     | Determined by active control system.  |
        +----------------+------+-------------+----------+-------------+---------+---------------------------------------+
        | fp             | 0x04 | float 32-bit| DPT      |             | 0.0     | Static input in DPT.                  |
        +----------------+------+-------------+----------+-------------+---------+---------------------------------------+
    """

    @staticmethod
    def help():
        print(ICCStaticInput.__doc__)

    def __init__(self, channel: int = 0, board=None):
        StaticInput.__init__(self, channel, board)

        self.active_type = {'id': self.sys_id << 8 | 0x03,
                            'type': float,
                            'unit': 'Integer',
                            'range': None,
                            'default': 0,
                            'value': 0}
        self.focal_power = {'id': self.sys_id << 8 | 0x04,
                   'type': float,
                   'unit': 'Diopters',
                   'range': [-50, 50],
                   'default': 0.0,
                   'value': 0.0}
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    ## Sets focal power on this channel [dpt]
    def SetFocalPower(self, value):
        return self.set_register('focal_power', value)

    ## Gets focal power on this channel [dpt]
    def GetFocalPower(self):
        return self.get_register('focal_power')


class ICCDeviceTemperatureManager(System):
    r"""
        Device Functionality - Device Temperature Readout
        System ID: 0x22

        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
        | Register Name       | Id   | Type        | Unit | Range | Default | Comment                                  |
        +=====================+======+=============+======+=======+=========+==========================================+
        |device_temperature   | 0x00 |uint 32-bit  |°C    |       |         |                                          |
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
        |device_temp_threshold| 0x01 |uint 32-bit  |°C    |       |         |                                          |
        +---------------------+------+-------------+------+-------+---------+------------------------------------------+
    """

    @staticmethod
    def help():
        print(ICCDeviceTemperatureManager.__doc__)

    _is_a_system = True

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x22
        self.channel = channel

        self.device_temperature = {'id': self.sys_id << 8 | 0x00, 'type': float, 'unit': '°C', 'range': None,
                                   'default': None, 'value': None}
        self.device_temp_threshold = {'id': self.sys_id << 8 | 0x01, 'type': float, 'unit': '°C', 'range': None,
                                      'default': None, 'value': None}

        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    ## Gets temperature of the device connected to this channel
    def GetDeviceTemperature(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('device_temperature')

    ## Gets temperature threshold of the device connected to this channel. If this threshold is reached the output of
    # the driver is disabled to cool down. Temperature has to fall by 10 degrees so that the output is enabled again.
    def GetDeviceTemperatureThreshold(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('device_temp_threshold')

    ## Sets temperature threshold of the device connected to this channel. If this threshold is reached the output of
    # the driver is disabled to cool down. Temperature has to fall by 10 degrees so that the output is enabled again.
    def SetDeviceTemperatureThreshold(self, threshold=0):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.set_register('device_temp_threshold', threshold)


class FocalPowerMode(ControlStage):
    r"""
Control Mode Channel - OF PID Control (with/without Temperature Compensation)
System ID: 0xB8 through 0xBf

+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Register Name      | Id   | Type        | Unit | Range | Default | Comment                                          |
+====================+======+=============+======+=======+=========+==================================================+
|adaptive_pid_enabled| 0x00 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| kp                 | 0x01 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| ki                 | 0x02 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| kd                 | 0x03 |uint 32-bit  |bool  | T/F   | 1       |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| min_output         | 0x03 |float 32-bit |None  |       |         | If PID output reaches this, it is clamped to this|
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| max_output         | 0x04 |float 32-bit |None  |       |         | If PID output reaches this, it is clamped to this|
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| min_integral       | 0x05 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| max_integral       | 0x06 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| ap                 | 0x07 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| bp                 | 0x08 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| ai                 | 0x09 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| bi                 | 0x0a |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| ad                 | 0x0b |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| bd                 | 0x0c |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
    """

    # TODO: update these registers
    @staticmethod
    def help():
        print(FocalPowerMode.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0xB8 | channel

        ControlStage.__init__(self, channel, board)
        self.name = self.__class__.__name__


class ICCSignalGenerator(SignalGenerator):
    r"""
Input Channel Systems - Signal Generator Channel
System ID for channel 0: 0x60

 *
 *  Signal Generator is a system for generating input signals of particular \ref WaveformShape "shapes".
 *  It is an input stage system, meaning that it is a system used as the very first stage of
 *  \ref signalflow.
 *
 *  To set it up, all the appropriate registers (seen in the table below) have to be configured first.
 *  The shape of the signal, its frequency, amplitude, offset and phase can be adjusted.
 *  For the square and pulse waveforms, the signal's duty cycle can be configured.
 *
 *  The unit type of the value being output by the
 *  SignalGenerator, must match to the control mode selected by the \ref SignalFlowManager "Signal Flow Manager".
 *
 *  By default, the Signal Generator will continuously output the waveform corresponding to the configuration.
 *  If only a single period is desired (or N periods for some finite positive integer N),
 *  the number of desired periods to execute has to be set to the "cycles" register before running the system.
 *  A negative value in this register corresponds to infinite looping.
 *
 *  Finally, to get the configured SignalFlow generator to run, the following steps have to take place:
 *   -# The Signal Generator system has to be set as active Input Stage system for the corresponding channel. This is done through the \ref SignalFlowManager "Signal Flow Manager" system.
 *   -# The "Run" register of the corresponding Signal Generator system has to be set to true (any non-zero value).
 *
 *   ### Register Map:
 *
 *  | Address    | Name                     | Default Value | Description                                                                                                               | Type                  | Access
 *  | -----------|--------------------------|---------------|---------------------------------------------------------------------------------------------------------------------------|-----------------------|-------------------
 *  | 0x6[0-7]00 | Unit type                | 0             |                                                                                                                           | \ref ChannelValueType | read write
 *  | 0x6[0-7]01 | Run                      | false         | Turn Signal Generator on/off                                                                                              | boolean               | read write
 *  | 0x6[0-7]02 | Shape                    | 0             |                                                                                                                           | \ref WaveformShape    | read write
 *  | 0x6[0-7]03 | Frequency                | 0.0           | Frequency in Hz of generated signal                                                                                       | float                 | read write
 *  | 0x6[0-7]04 | Amplitude                | 0.0           | Amplitude of generated signal                                                                                             | float                 | read write
 *  | 0x6[0-7]05 | Offset                   | 0.0           | Offset of generated signal                                                                                                | float                 | read write
 *  | 0x6[0-7]06 | Phase                    | 0.0           | Phase in rad of generated signal                                                                                          | float                 | read write
 *  | 0x6[0-7]07 | Cycles                   | -1            | Number of cycles to be generated. Run flag is turned off after completion. Negative value corresponds to infinite looping | int32                 | read write
 *  | 0x6[0-7]08 | Duty cycle               | 0.5           | Duty cycle of square and pulse shapes                                                                                     | 0 to 1 float <BR> Resolution is frequency/10000 | read write
 *  | 0x6[0-7]09 | External trigger         | 0             | Vector Pattern Unit can be synchronised with external signal (0=disabled, 1=rising/falling edge, 2=rising edge trigger)   | uint32                | read write
 *  | 0x6[0-7]0a | Output                   | N/A           | Output of signal generator                                                                                                | float                 | read only
 *  | 0x6[0-7]0b | Stair count              | 5             | Count + direction of stairs for staircase shape<BR> (ignored for other shape types)                                       | -100 to 100 int32     | read write
 *  | 0x6[0-7]0c | External trigger GPIOx   | false         | Turns GPIOx pin to trigger input source (GPIOx default is trigger output) and disables global external trigger SYNCx pin  | boolean               | read write
 *

registers table 1:

+---------------+-------+
| Waveform Unit | Value |
+===============+=======+
| Current       | 0     |
+---------------+-------+


registers table 2:

+---------------+-------+
| Wavform Shape | Value |
+===============+=======+
| Sinusoidal    | 0     |
+---------------+-------+
| Triangular    | 1     |
+---------------+-------+
| Rectangular   | 2     |
+---------------+-------+
| Sawtooth      | 3     |
+---------------+-------+
| Pulse         | 4     |
+---------------+-------+

    """

    @staticmethod
    def help():
        print(ICCSignalGenerator.__doc__)

    _is_a_system = False

    def __init__(self, channel: int = 0, board=None,):
        SignalGenerator.__init__(self, channel, board)
        self.stair_count = {'id': self.sys_id << 8 | 0x0b,
                       'type': int,
                       'unit': None,
                       'range': [-100, 100],
                       'default': 5,
                       'value': None}
        self.ext_trigger_gpio = {'id': self.sys_id << 8 | 0x0c,
                            'type': bool,
                            'unit': None,
                            'range': None,
                            'default': 0, #false
                            'value': None}

    ## Sets stair count of the generatred signal, only available when shape is set to stair.
    def SetStairCount(self, value):
        return self.set_register('stair_count', value)

    ## Gets stair count of the generatred signal, only available when shape is set to stair.
    def GetStairCount(self):
        return self.get_register('stair_count')

    ## Turns GPIOx pin to trigger input source (GPIOx default is trigger output) and disables global external trigger
    # SYNCx pin. 0 = off, 1 = on
    def SetExtTriggerGPIO(self, value):
        return self.set_register('ext_trigger_gpio', value)

    ## Gets the state of GPIOx pin to trigger input source (GPIOx default is trigger output) and disables global
    # external trigger SYNCx pin. 0 = off, 1 = on
    def GetExtTriggerGPIO(self):
        return self.get_register('ext_trigger_gpio')


## Parent class => \link optoKummenberg.registers.InputStage.FeedbackSystem FeedbackSystem\endlink <br>
class InertialMeasurementUnit(System, FeedbackSystem):
    """
Device Functionality - Inertial Measurement Unit
System ID: 0x37

 * Inertial Measurement Unit system ID: <b>0x37</b>
 *
 * The inertial measurement unit system provides information about the actual
 * acceleration in X,Y,Z direction of actuator and angular rate around these axis.
 * It also includes the parameter registers for setup of the IMU.
 *
 * ### Register Map:
 *
 *  | Address | Name        		| Default Value | Description                                    		|  Type  | Access     |
 *  |---------|---------------------|---------------|-------------------------------------------------------|--------|------------|
 *  | 0x3700  | RUN_ACCEL        	| false         | Enable/Disable accelerometer readout callback  		| boolean| read write |
 *  | 0x3701  | ACCEL_X   			| N/A           | Accelerometer value in X direction [m/s/s]	 		| float  | read only  |
 *  | 0x3702  | ACCEL_Y   			| N/A           | Accelerometer value in Y direction [m/s/s]	 		| float  | read only  |
 *  | 0x3703  | ACCEL_Z   			| N/A           | Accelerometer value in Z direction [m/s/s]	 		| float  | read only  |
 *  | 0x3704  | RUN_GYRO     		| false         | Enable/Disable Gyroscope readout callback      		| boolean| read write |
 *  | 0x3705  | GYRO_X     			| N/A           | Gyroscope value in X direction [deg/s]       	 		| float  | read only  |
 *  | 0x3706  | GYRO_Y     			| N/A           | Gyroscope value in Y direction [deg/s]       			| float  | read only  |
 *  | 0x3707  | GYRO_Z 				| N/A           | Gyroscope value in Z direction [deg/s]		 		| float  | read only  |
 *  | 0x3708  | CALLBACK_PRESCALER  | 20            | System timer callback prescaler 				 		| uint16 | read write |
 *  | 0x3709  | ACCEL_RESOLUTION 	| 0             | Resolution of accelerometer [0=2g, 1=4g, 2=8g, 3=16g] | uint8_t| read write |
 *  | 0x370A  | GYRO_RESOLUTION     | 0           	| Resolution of gyroscope [0=250, 1=500, 2=1000, 3=2000]| uint8_t| read write |
 *  | 0x370B  | DLPF 				| 0  			| Digital low pass filter for gyro. and accelerometer   | uint8_t| read write |
 *  | 0x370C  | INIT 				| N/A           | Writes configuration from registers into IMU  		| uint8  | write  	  |
 *  | 0x370D  | INIT_DONE			| false         | If init was successful, then ==true  					| uint8  | read only  |
 *  |---------|---------------------|---------------|-------------------------------------------------------|--------|------------|
 *
 * ### Vector Map:
 *
 * | Address | Name             | Default  | Description               		| Format and value | Access     |
 * |---------|------------------|----------|--------------------------------|------------------|------------|
 * | 0x3700  | ACCEL_VALUES    	|   N/A    | {X,Y,Z}, 3 * float (12 bytes) 	| float            | read only 	|
 * | 0x3701  | GYRO_VALUES    	|   N/A    | {X,Y,Z}, 3 * float (12 bytes) 	| float            | read only 	|
 *
 */
"""

    @staticmethod
    def help():
        print(InertialMeasurementUnit.__doc__)

    _is_a_system = True

    def __init__(self, board=None):
        self.sys_id = 0x37

        # Registers
        self.accel_run          = {'id': self.sys_id << 8 | 0x00, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.accel_x            = {'id': self.sys_id << 8 | 0x01, 'type': float, 'unit': None,
                                    'range': [-16000, 16000], 'default': None, 'value': None}
        self.accel_y            = {'id': self.sys_id << 8 | 0x02, 'type': float, 'unit': None,
                                    'range': [-16000, 16000], 'default': None, 'value': None}
        self.accel_z            = {'id': self.sys_id << 8 | 0x03, 'type': float, 'unit': None,
                                    'range': [-16000, 16000], 'default': None, 'value': None}
        self.gyro_run           = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.gyro_x             = {'id': self.sys_id << 8 | 0x05, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.gyro_y             = {'id': self.sys_id << 8 | 0x06, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.gyro_z             = {'id': self.sys_id << 8 | 0x07, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.gyro_x_offset      = {'id': self.sys_id << 8 | 0x08, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.gyro_y_offset      = {'id': self.sys_id << 8 | 0x09, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.gyro_z_offset      = {'id': self.sys_id << 8 | 0x0A, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.callback_prescaler = {'id': self.sys_id << 8 | 0x0B, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.accel_resolution   = {'id': self.sys_id << 8 | 0x0C, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.gyro_resolution    = {'id': self.sys_id << 8 | 0x0D, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.dlpf               = {'id': self.sys_id << 8 | 0x0E, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.init_imu           = {'id': self.sys_id << 8 | 0x0F, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.init_done          = {'id': self.sys_id << 8 | 0x10, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}

        # Vectors
        self.accel_vec = {'id': self.sys_id << 8 | 0x00, 'type': float}
        self.gyro_vec = {'id': self.sys_id << 8 | 0x01, 'type': float}


        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    # getters
    def get_value(self, channel):
        return 0

    def get_value_id(self, channel):
        return 0

    def is_init_done(self):
        return self.get_init_done()

    def get_accel_x(self):
        return self.get_register('accel_x')

    def get_accel_y(self):
        return self.get_register('accel_y')

    def get_accel_z(self):
        return self.get_register('accel_z')

    def get_gyro_x(self):
        return self.get_register('gyro_x')

    def get_gyro_y(self):
        return self.get_register('gyro_y')

    def get_gyro_z(self):
        return self.get_register('gyro_z')

    def get_gyro_x_offset(self):
        return self.get_register('gyro_x_offset')

    def get_gyro_y_offset(self):
        return self.get_register('gyro_y_offset')

    def get_gyro_z_offset(self):
        return self.get_register('gyro_z_offset')

    def get_accel_resolution(self):
        return self.get_register('accel_resolution')

    def get_gyro_resolution(self):
        return self.get_register('gyro_resolution')

    def get_accel_run(self):
        return self.get_register('accel_run')

    def get_gyro_run(self):
        return self.get_register('gyro_run')

    def get_dlpf(self):
        return self.get_register('dlpf')

    def get_init_done(self):
        return self.get_register('init_done')

    # setters
    def set_gyro_x_offset(self, offset):
        return self.set_register('gyro_x_offset', offset)

    def set_gyro_y_offset(self, offset):
        return self.set_register('gyro_y_offset', offset)

    def set_gyro_z_offset(self, offset):
        return self.set_register('gyro_z_offset', offset)

    def set_callback_prescaler(self, prescaler=20):
        return self.set_register('callback_prescaler', prescaler)

    def set_accel_resolution(self, resolution=0):
        return self.set_register('accel_resolution', resolution)

    def set_gyro_resolution(self, resolution=0):
        return self.set_register('gyro_resolution', resolution)

    def set_dlpf(self, value=0):
        return self.set_register('dlpf', value)

    def is_init_done(self):
        return self.get_register('init_done')

    # actions

    def init(self):
        self.set_register('init_imu', 1)
        time.sleep(0.3)
        return self.get_init_done()

    def start_accel_readout(self):
        self.set_register('accel_run', 1)

    def stop_accel_readout(self):
        self.set_register('accel_run', 0)

    def start_gyro_readout(self):
        self.set_register('gyro_run', 1)

    def stop_gyro_readout(self):
        self.set_register('gyro_run', 0)

    # vector getters

    def get_accel(self):
        return self._board.get_vector(self.accel_vec, 0, 3)

    def get_gyro(self):
        return self._board.get_vector(self.gyro_vec, 0, 3)


## Parent class => \link optoKummenberg.registers.InputStage.FeedbackSystem FeedbackSystem\endlink <br>
class SarynControl(System, FeedbackSystem):
    """
Device Functionality - Saryn Control
System ID: 0x38


 * Saryn Control system ID: <b>0x38</b>
 *
 * Control system for Saryn project,
 * this system provides optical stabilisation based on gyro data (from InertialMeasurementSystem).
 * Whole control compose from 3 stages:
 * - Optical Stabilisation 	- PID for X and Y movement
 * 							- setpoint=0, feedback=gyro, output=axis_controller
 * - Axis controller 	- 3x(PID+Feedforward polynome) for X, Y, Z axis
 * 						- setpoint=optical_stabilization, feedback=transformed_hall_voltage, output=channel_controller
 * - Channel controller - 3x(PID+Feedforward polynome) for hall channels 0, 1, 2
 * 						- setpoint=axis_controller, feedback=hall_voltage, output=current_for_given_channel
 *
 *
 * \note: By feedforward polynome we mean feedforward_output = setpoint^0*poly[0] + setpoint^1*poly[1] + ... + setpoint^(n-1)*poly[n-1]
 * 			where n = @polynom_order = 4
 * 			controller_output = feedforward_output + pid_output
 *
 * ### Register Map:
 *
 *   *  | Address | Name        		| Default Value | Description                                    		|  Type  | Access     |
 *  |---------|---------------------|---------------|-------------------------------------------------------|--------|------------|
 *  | 0x3800  | RUN_CONTROLLER      | false         | Enable/Disable all control loops  		            | boolean| read write |
 *  | 0x3801  | RUN_OS      		| false         | Enable/Disable optical stabilisation  		        | boolean| read write |
 *  | 0x3802  | UPDATE_FREQUENCY   	| 2000          | Controllers update frequency [Hz]	 					| uint8_t| read write |
 *  | 0x3803  | SETPOINT_HALL_CH0  	| 0             | Required value for channel 0 [V]	 					| float  | read only  |
 *  | 0x3804  | SETPOINT_HALL_CH1   | 0             | Required value for channel 1 [V]	 					| float  | read only  |
 *  | 0x3805  | SETPOINT_HALL_CH2   | 0             | Required value for channel 2 [V]      				| boolean| read only  |
 *  | 0x3806  | SETPOINT_TILT_X     | 0             | Required value for X axis [deg]       	 			| float  | read write |
 *  | 0x3807  | SETPOINT_TILT_Y     | 0             | Required value for Y axis [deg]       				| float  | read write |
 *  | 0x3808  | SETPOINT_SHIFT_Z	| 0             | Required value for Z axis [mm]	 		            | float  | read write |
 *  | 0x3809  | FB_HALL_CH0  		| N/A           | Feedback value from hall sensor for channel 0 [V]		| uint16 | read write |
 *  | 0x380A  | FB_HALL_CH1 		| N/A           | Feedback value from hall sensor for channel 1 [V] 	| uint8_t| read write |
 *  | 0x380B  | FB_HALL_CH2     	| N/A         	| Feedback value from hall sensor for channel 2 [V]		| uint8_t| read write |
 *  | 0x380C  | FB_HALL_X			| N/A			| Transformed FB value from hall for X axis [deg]   	| uint8_t| read only  |
 *  | 0x380D  | FB_HALL_Y			| N/A			| Transformed FB value from hall for Y axis [deg]   	| uint8_t| read only  |
 *  | 0x380E  | FB_HALL_Z			| N/A			| Transformed FB value from hall for Z axis [dpt or mm] | float	 | read only  |
 *  | 0x380F  | OUT_CURRENT_CH0		| 0 			| Output of the controller for channel 0 [A]   			| float	 | read only  |
 *  | 0x3810  | OUT_CURRENT_CH1		| 0  			| Output of the controller for channel 0 [A]   			| float  | read only  |
 *  | 0x3811  | OUT_CURRENT_CH2		| 0  			| Output of the controller for channel 0 [A]   			| float  | read only  |
 *  | 0x3812  | OUT_MAX_CURRENT		| 0.1 			| Maximal output current for individual channel [A]   	| float  | write 	  |
 *  | 0x3813  | AXIS_IN_X_MAX		| 0  			| Upper limit for input of X axis controller [deg]		| float  | write 	  |
 *  | 0x3814  | AXIS_IN_X_MIN		| 0  			| Lower limit for input of X axis controller [deg]		| float  | write 	  |
 *  | 0x3815  | AXIS_IN_Y_MAX		| 0  			| Upper limit for input of Y axis controller [deg]		| float  | write 	  |
 *  | 0x3816  | AXIS_IN_Y_MIN		| 0  			| Lower limit for input of Y axis controller [deg]		| float  | write 	  |
 *  | 0x3817  | AXIS_IN_Z_MAX		| 0  			| Upper limit for input of Z axis controller [dpt/mm]	| float  | write 	  |
 *  | 0x3818  | AXIS_IN_Z_MIN		| 0  			| Lower limit for input of Z axis controller [dpt/mm]	| float  | write 	  |
 *  | 0x3819  | HALL_IN_CH0_MIN		| 0  			| Lower limit for input of Channel 0 controller [V]   	| float  | write 	  |
 *  | 0x381A  | HALL_IN_CH0_MAX		| 0  			| Upper limit for input of Channel 0 controller [V] 	| float  | write 	  |
 *  | 0x381B  | HALL_IN_CH1_MIN		| 0  			| Lower limit for input of Channel 1 controller [V]		| float  | write 	  |
 *  | 0x381C  | HALL_IN_CH1_MAX		| 0  			| Upper limit for input of Channel 1 controller [V]   	| float  | write 	  |
 *  | 0x381D  | HALL_IN_CH2_MIN		| 0  			| Lower limit for input of Channel 2 controller [V]   	| float  | write   	  |
 *  | 0x381E  | HALL_IN_CH2_MAX		| 0  			| Upper limit for input of Channel 2 controller [V]   	| float  | write 	  |
 *  | 0x381F  | MOVE_RATE_X         | 0             | Gyro X feedback value (SG if XY_SG_DEBUG reg.enabled) | float  | read only  |
 *  | 0x3820  | MOVE_RATE_Y         | 0             | Gyro Y feedback value (SG if XY_SG_DEBUG reg.enabled) | float  | read only  |
 *  | 0x3821  | FB_AXIS_X           | 0             | X feedback value of the axis controller               | float  | read only  |
 *  | 0x3822  | FB_AXIS_Y           | 0             | Y feedback value of the axis controller               | float  | read only  |
 *  | 0x3823  | INIT 				| false         | Writes configuration from registers into IMU  		| uint8  | write  	  |
 *  | 0x3824  | XY_SG_DEBUG			| false         | Connects signal generator instead of gyro (for debug) | uint8  | write  	  |
 *  | 0x3825  | RUN_OPEN_LOOP       | false         | Sets ch#1 cur.polarity according to magnet orientation| boolean| read write |
 *  |---------|---------------------|---------------|-------------------------------------------------------|--------|------------|
 *
 * ### Vector Map:
 *
 * | Address | Name           		  	| Default  		| Description                                         				| Format and value 			| Access     |
 * |---------|--------------------------|---------------|-------------------------------------------------------------------|---------------------------|------------|
 * | 0x3800  | HALL_TO_CURRENT_POLY_X 	| [0, 1, 0, 0 ] | {a0, a1, a2, a3}, feedforward polynome, outX=pidX.out+refX*polyX 	| @polynom_order(=4) *float | read write |
 * | 0x3801  | HALL_TO_CURRENT_POLY_Y 	| [0, 1, 0, 0 ] | {a0, a1, a2, a3}, feedforward polynome, outY=pidY.out+refY*polyY	| @polynom_order(=4) *float | read write |
 * | 0x3802  | HALL_TO_CURRENT_POLY_Z 	| [0, 1, 0, 0 ] | {a0, a1, a2, a3}, feedforward polynome, outZ=pidZ.out+refZ*polyZ 	| @polynom_order(=4) *float | read write |
 * | 0x3803  | HALL_TO_CURRENT_POLY_CH0	| [0, 0, 0, 0 ] | {a0, a1, a2, a3}, feedforward polynome, out0=pid0.out+ref0*poly0 	| @polynom_order(=4) *float | read write |
 * | 0x3804  | HALL_TO_CURRENT_POLY_CH1	| [0, 0, 0, 0 ] | {a0, a1, a2, a3}, feedforward polynome, out1=pid1.out+ref1*poly1 	| @polynom_order(=4) *float | read write |
 * | 0x3805  | HALL_TO_CURRENT_POLY_CH2	| [0, 0, 0, 0 ] | {a0, a1, a2, a3}, feedforward polynome, out2=pid2.out+ref2*poly2 	| @polynom_order(=4) *float | read write |
 * | 0x3806  | HALL_PID_COEF_CH0		| [0, 0, 0 ] 	| {Kp, Ki, Kd}, PID coefficients for channel 0 controller 			| 3*float					| write 	 |
 * | 0x3807  | HALL_PID_COEF_CH1		| [0, 0, 0 ] 	| {Kp, Ki, Kd}, PID coefficients for channel 1 controller 			| 3*float					| write 	 |
 * | 0x3808  | HALL_PID_COEF_CH2		| [0, 0, 0 ] 	| {Kp, Ki, Kd}, PID coefficients for channel 2 controller 			| 3*float					| write 	 |
 * | 0x3809  | HALL_PID_COEF_X			| [0, 0, 0 ] 	| {Kp, Ki, Kd}, PID coefficients for X axis controller 				| 3*float					| write 	 |
 * | 0x380A  | HALL_PID_COEF_Y			| [0, 0, 0 ] 	| {Kp, Ki, Kd}, PID coefficients for Y axis controller 				| 3*float					| write 	 |
 * | 0x380B  | HALL_PID_COEF_Z			| [0, 0, 0 ] 	| {Kp, Ki, Kd}, PID coefficients for Z axis controller 				| 3*float					| write 	 |
 * | 0x380C  | OS_PID_CEF_X				| [0, 0, 0 ] 	| {Kp, Ki, Kd}, PID coefficients for optical stabilisation in X	dir	| 3*float					| write 	 |
 * | 0x380D  | OS_PID_CEF_Y				| [0, 0, 0 ] 	| {Kp, Ki, Kd}, PID coefficients for optical stabilisation in X	dir | 3*float					| write 	 |
 * | 0x380E  | TF_HALL_TO_AXIS_X		| [0, 0, 0, 0 ] | {a0, a1, a2, a3}, conversion from hall voltage to X axis 			| @polynom_order(=4) *float | write 	 |
 * | 0x380F  | TF_HALL_TO_AXIS_Y		| [0, 0, 0, 0 ] | {a0, a1, a2, a3}, conversion from hall voltage to Y axis 			| @polynom_order(=4) *float | write 	 |
 * | 0x3810  | TF_HALL_TO_AXIS_Z		| [0, 0, 0, 0 ] | {a0, a1, a2, a3}, conversion from hall voltage to Z axis 			| @polynom_order(=4) *float | write 	 |
 * | 0x3811  | TF_HALL_TO_AXIS_MATRIX	| [0, .., 0] (1)| Hall to Axis transformation matrix coefficients, size depends on CCM project (1)| @size *float | write 	 |
 * | 0x3812  | TF_AXIS_TO_CHANNEL_MATRIX| [0, .., 0] (2)| Axis to Channel transformation matrix coefficients, size depends on CCM project (2)| @size *float | write  |
 * | 0x3813  | GYRO_ORIENTATION_MATRIX  | [-1, .., 1] (3)| Matrix represents the setup of sensor acceleration Ax, Ay, Az values versus X, Y axes| 6*int32 | read write|
 *
 *
 * \note	Transformation matrix coefficients are represented as rows following each other:
 * 			<br/>(1) Frey = 13*3; Saiph = 10*2 coefficients
 * 			<br/>(2) Frey =  4*3; Saiph =  3*2 coefficients
 *
 * Gyro orientation matrix represents the setup of sensor acceleration Ax, Ay, Az values versus X, Y axes of the module. Default matrix connects negative Ax data with X and Az data with Y axis as shown in table:
 *
 * |Axis\Accel| Ax | Ay | Az |
 * |:---:|:---:|:---:|:---:|
 * | X   | -1  |  0  |  0  |
 * | Y   |  0  |  0  |  1  |
 *
 * \note	Matrix values can have only integer values, every row should have 2 matrix elements = 0 and one having absolute value = 1.
 *			<br/>(3) Default vector values are [-1, 0, 0, 0, 0, 1]

"""

    @staticmethod
    def help():
        print(SarynControl.__doc__)

    _is_a_system = True

    def __init__(self, board=None):
        self.sys_id = 0x38

        # Registers
        self.run_controller         = {'id': self.sys_id << 8 | 0x00, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.run_os                 = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.update_frequency       = {'id': self.sys_id << 8 | 0x02, 'type': int, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.setpoint_hall_ch0      = {'id': self.sys_id << 8 | 0x03, 'type': float, 'unit': None,
                                   'range': None, 'default': None, 'value': None}
        self.setpoint_hall_ch1      = {'id': self.sys_id << 8 | 0x04, 'type': float, 'unit': None,
                                   'range': None, 'default': None, 'value': None}
        self.setpoint_hall_ch2      = {'id': self.sys_id << 8 | 0x05, 'type': float, 'unit': None,
                                   'range': None, 'default': None, 'value': None}
        self.setpoint_tilt_x        = {'id': self.sys_id << 8 | 0x06, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.setpoint_tilt_y        = {'id': self.sys_id << 8 | 0x07, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.setpoint_shift_z       = {'id': self.sys_id << 8 | 0x08, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.hall_voltage_ch0       = {'id': self.sys_id << 8 | 0x09, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.hall_voltage_ch1       = {'id': self.sys_id << 8 | 0x0A, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.hall_voltage_ch2       = {'id': self.sys_id << 8 | 0x0B, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.hall_voltage_x         = {'id': self.sys_id << 8 | 0x0C, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.hall_voltage_y         = {'id': self.sys_id << 8 | 0x0D, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.hall_voltage_z         = {'id': self.sys_id << 8 | 0x0E, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.output_current_ch0     = {'id': self.sys_id << 8 | 0x0F, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.output_current_ch1     = {'id': self.sys_id << 8 | 0x10, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}
        self.output_current_ch2     = {'id': self.sys_id << 8 | 0x11, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}

        self.output_max_current     = {'id': self.sys_id << 8 | 0x12, 'type': float, 'unit': None,
                                    'range': None, 'default': None, 'value': None}

        self.axis_in_x_max = {'id': self.sys_id << 8 | 0x13, 'type': float, 'unit': None,
                               'range': None, 'default': None, 'value': None}
        self.axis_in_x_min = {'id': self.sys_id << 8 | 0x14, 'type': float, 'unit': None,
                               'range': None, 'default': None, 'value': None}
        self.axis_in_y_max = {'id': self.sys_id << 8 | 0x15, 'type': float, 'unit': None,
                               'range': None, 'default': None, 'value': None}
        self.axis_in_y_min = {'id': self.sys_id << 8 | 0x16, 'type': float, 'unit': None,
                               'range': None, 'default': None, 'value': None}
        self.axis_in_z_max = {'id': self.sys_id << 8 | 0x17, 'type': float, 'unit': None,
                               'range': None, 'default': None, 'value': None}
        self.axis_in_z_min = {'id': self.sys_id << 8 | 0x18, 'type': float, 'unit': None,
                               'range': None, 'default': None, 'value': None}

        self.hall_in_ch0_min = {'id': self.sys_id << 8 | 0x19, 'type': float, 'unit': None,
                               'range': None, 'default': None, 'value': None}
        self.hall_in_ch0_max = {'id': self.sys_id << 8 | 0x1A, 'type': float, 'unit': None,
                               'range': None, 'default': None, 'value': None}
        self.hall_in_ch1_min = {'id': self.sys_id << 8 | 0x1B, 'type': float, 'unit': None,
                             'range': None, 'default': None, 'value': None}
        self.hall_in_ch1_max = {'id': self.sys_id << 8 | 0x1C, 'type': float, 'unit': None,
                             'range': None, 'default': None, 'value': None}
        self.hall_in_ch2_min = {'id': self.sys_id << 8 | 0x1D, 'type': float, 'unit': None,
                             'range': None, 'default': None, 'value': None}
        self.hall_in_ch2_max = {'id': self.sys_id << 8 | 0x1E, 'type': float, 'unit': None,
                             'range': None, 'default': None, 'value': None}

        self.move_rate_x = {'id': self.sys_id << 8 | 0x1F, 'type': float, 'unit': None,
                             'range': None, 'default': None, 'value': None}
        self.move_rate_y = {'id': self.sys_id << 8 | 0x20, 'type': float, 'unit': None,
                             'range': None, 'default': None, 'value': None}

        self.fb_axis_x = {'id': self.sys_id << 8 | 0x21, 'type': float, 'unit': None,
                             'range': None, 'default': None, 'value': None}
        self.fb_axis_y = {'id': self.sys_id << 8 | 0x22, 'type': float, 'unit': None,
                             'range': None, 'default': None, 'value': None}

        self.init_sys = {'id': self.sys_id << 8 | 0x23, 'type': int, 'unit': None,
                              'range': None, 'default': None, 'value': None}

        self.xy_sg_debug = {'id': self.sys_id << 8 | 0x24, 'type': int, 'unit': None,
                              'range': None, 'default': None, 'value': None}

        self.run_open_loop = {'id': self.sys_id << 8 | 0x25, 'type': int, 'unit': None,
                              'range': None, 'default': None, 'value': None}

        # Vectors
        self.vec_polly_hall_to_current_x = {'id': self.sys_id << 8 | 0x00, 'type': float}
        self.vec_polly_hall_to_current_y = {'id': self.sys_id << 8 | 0x01, 'type': float}
        self.vec_polly_hall_to_current_z = {'id': self.sys_id << 8 | 0x02, 'type': float}
        self.vec_polly_hall_to_current_ch0 = {'id': self.sys_id << 8 | 0x03, 'type': float}
        self.vec_polly_hall_to_current_ch1 = {'id': self.sys_id << 8 | 0x04, 'type': float}
        self.vec_polly_hall_to_current_ch2 = {'id': self.sys_id << 8 | 0x05, 'type': float}
        self.vec_pid_coef_ch0 = {'id': self.sys_id << 8 | 0x06, 'type': float}
        self.vec_pid_coef_ch1 = {'id': self.sys_id << 8 | 0x07, 'type': float}
        self.vec_pid_coef_ch2 = {'id': self.sys_id << 8 | 0x08, 'type': float}
        self.vec_pid_coef_x = {'id': self.sys_id << 8 | 0x09, 'type': float}
        self.vec_pid_coef_y = {'id': self.sys_id << 8 | 0x0A, 'type': float}
        self.vec_pid_coef_z = {'id': self.sys_id << 8 | 0x0B, 'type': float}
        self.vec_os_pid_coef_x = {'id': self.sys_id << 8 | 0x0C, 'type': float}
        self.vec_os_pid_coef_y = {'id': self.sys_id << 8 | 0x0D, 'type': float}
        self.vec_tf_hall_to_axis_x = {'id': self.sys_id << 8 | 0x0E, 'type': float}
        self.vec_tf_hall_to_axis_y = {'id': self.sys_id << 8 | 0x0F, 'type': float}
        self.vec_tf_hall_to_axis_z = {'id': self.sys_id << 8 | 0x10, 'type': float}
        self.vec_tf_hall_to_axis_matrix = {'id': self.sys_id << 8 | 0x11, 'type': float}
        self.vec_tf_axis_to_hall_matrix = {'id': self.sys_id << 8 | 0x12, 'type': float}
        self.vec_gyro_orientation_matrix = {'id': self.sys_id << 8 | 0x13, 'type': int}

        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    def get_value(self, channel):
        return 0

    def get_value_id(self, channel):
        return 0

    def is_init_done(self):
        return 1
    # getters
    def get_hall_voltage_x(self):
        return self.get_register('hall_voltage_x')

    def get_hall_voltage_y(self):
        return self.get_register('hall_voltage_y')

    def get_hall_voltage_z(self):
        return self.get_register('hall_voltage_z')

    def get_x(self):
        return self.get_register('setpoint_tilt_x')

    def get_y(self):
        return self.get_register('setpoint_tilt_y')

    def get_z(self):
        return self.get_register('setpoint_shift_z')

    def get_move_rate_x(self):
        return self.get_register('move_rate_x')

    def get_move_rate_y(self):
        return self.get_register('move_rate_y')

    # setters
    def set_x(self, value=0):
        return self.set_register('setpoint_tilt_x', value)

    def set_y(self, value=0):
        return self.set_register('setpoint_tilt_y', value)

    def set_z(self, value=0):
        return self.set_register('setpoint_shift_z', value)

    def set_update_freq(self, value=2000):
        return self.set_register('update_frequency', value)

    def set_max_output_current(self, value=0.1):
        return self.set_register('output_max_current', value)

    def enable_open_loop(self, enable=0):
        return self.set_register('run_open_loop', enable)

    # input limits for the controller ()
    def set_axis_in_limit_x(self, min_voltage, max_voltage):
        self.set_register('axis_in_x_min', min_voltage)
        return self.set_register('axis_in_x_max', max_voltage)

    def set_axis_in_limit_y(self, min_voltage, max_voltage):
        self.set_register('axis_in_y_min', min_voltage)
        return self.set_register('axis_in_y_max', max_voltage)

    def set_axis_in_limit_z(self, min_voltage, max_voltage):
        self.set_register('axis_in_z_min', min_voltage)
        return self.set_register('axis_in_z_max', max_voltage)

    def set_hall_in_limit_ch0(self, min_voltage, max_voltage):
        self.set_register('hall_in_ch0_min', min_voltage)
        return self.set_register('hall_in_ch0_max', max_voltage)

    def set_hall_in_limit_ch1(self, min_voltage, max_voltage):
        self.set_register('hall_in_ch1_min', min_voltage)
        return self.set_register('hall_in_ch1_max', max_voltage)

    def set_hall_in_limit_ch2(self, min_voltage, max_voltage):
        self.set_register('hall_in_ch2_min', min_voltage)
        return self.set_register('hall_in_ch2_max', max_voltage)

    # actions
    def init(self):
        return self.set_register('init_sys', 1)

    def start_controller(self):
        self.set_register('run_controller', 1)

    def stop_controller(self):
        self.set_register('run_controller', 0)

    def start_optical_stabilisation(self):
        self.set_register('run_os', 1)

    def stop_optical_stabilisation(self):
        self.set_register('run_os', 0)

    def enable_SG_debug(self):
        self.set_register('xy_sg_debug', 1)

    def disable_SG_debug(self):
        self.set_register('xy_sg_debug', 0)

    # vector setters
    def set_poly_hall_to_current_x(self, vector):
        return self._board.set_vector(self.vec_polly_hall_to_current_x, 0, vector)

    def set_poly_hall_to_current_y(self, vector):
        return self._board.set_vector(self.vec_polly_hall_to_current_y, 0, vector)

    def set_poly_hall_to_current_z(self, vector):
        return self._board.set_vector(self.vec_polly_hall_to_current_z, 0, vector)

    def set_poly_hall_to_current_ch0(self, vector):
        return self._board.set_vector(self.vec_polly_hall_to_current_ch0, 0, vector)

    def set_poly_hall_to_current_ch1(self, vector):
        return self._board.set_vector(self.vec_polly_hall_to_current_ch1, 0, vector)

    def set_poly_hall_to_current_ch2(self, vector):
        return self._board.set_vector(self.vec_polly_hall_to_current_ch2, 0, vector)

    # pid
    def set_pid_coef_ch0(self, kp, ki, kd):
        return self._board.set_vector(self.vec_pid_coef_ch0, 0, [kp, ki, kd])

    def set_pid_coef_ch1(self, kp, ki, kd):
        return self._board.set_vector(self.vec_pid_coef_ch1, 0, [kp, ki, kd])

    def set_pid_coef_ch2(self, kp, ki, kd):
        return self._board.set_vector(self.vec_pid_coef_ch2, 0, [kp, ki, kd])

    def set_pid_coef_x(self, kp, ki, kd):
        return self._board.set_vector(self.vec_pid_coef_x, 0, [kp, ki, kd])

    def set_pid_coef_y(self, kp, ki, kd):
        return self._board.set_vector(self.vec_pid_coef_y, 0, [kp, ki, kd])

    def set_pid_coef_z(self, kp, ki, kd):
        return self._board.set_vector(self.vec_pid_coef_z, 0, [kp, ki, kd])

    def set_pid_coef_os_x(self, kp, ki, kd):
        return self._board.set_vector(self.vec_os_pid_coef_x, 0, [kp, ki, kd])

    def set_pid_coef_os_y(self, kp, ki, kd):
        return self._board.set_vector(self.vec_os_pid_coef_y, 0, [kp, ki, kd])

    # tranformation for feedback, from hall sensor to axis
    def set_poly_tf_feedback_hall_to_axis_x(self, poly):
        return self._board.set_vector(self.vec_tf_hall_to_axis_x, 0, poly)

    def set_poly_tf_feedback_hall_to_axis_y(self, poly):
        return self._board.set_vector(self.vec_tf_hall_to_axis_y, 0, poly)

    def set_poly_tf_feedback_hall_to_axis_z(self, poly):
        return self._board.set_vector(self.vec_tf_hall_to_axis_z, 0, poly)

    def set_matrix_tf_hall_to_axis(self, vector):
        for i in range(0, len(vector), CHUNK_SIZE):
            aux = vector[i:i + CHUNK_SIZE]
            self._board.set_vector(self.vec_tf_hall_to_axis_matrix, i, aux)

    def set_matrix_tf_axis_to_hall(self, vector):
        for i in range(0, len(vector), CHUNK_SIZE):
            aux = vector[i:i + CHUNK_SIZE]
            self._board.set_vector(self.vec_tf_axis_to_hall_matrix, i, aux)

    def set_gyro_orientation_matrix(self, vector):
        for i in range(0, len(vector), CHUNK_SIZE):
            aux = vector[i:i + CHUNK_SIZE]
            self._board.set_vector(self.vec_gyro_orientation_matrix, i, aux)

    def get_gyro_orientation_matrix(self):
        byte_size = 6 * 4 # 6 values of int32
        return self._board.get_vector(self.vec_gyro_orientation_matrix, 0, byte_size)


class SmartStepManager(System):
    r"""
    Smart step manager is a system in charge of managing lens devices with has the smart step feature applicable.
    system ID: 0x3A

Register Map:
+---------------------+----------------+--------------+----------+--------------+---------------+--------------------+
| Register Name       | Id             | Type         | Unit     | Range        | Default       | Comment            |
+=====================+================+==============+==========+==============+===============+====================+
| mngDeviceMsk        | 0x00           | uint  32-bit | n/a      | <0,15>       |               | read/write         |
+---------------------+----------------+--------------+----------+--------------+---------------+--------------------+
    """

    @staticmethod
    def help():
        print(SmartStepManager.__doc__)

    def __init__(self, board=None):
        self.sys_id = 0x3A
        self._readonly = False
        self.DEVICE_NBR = 4

        """
        self.mngDeviceMsk = {'id': self.sys_id << 8 | 0x00,
                        'type': int,
                        'unit': None,
                        'range': [0,15],
                        'default': None,
                        'value': None}
        """

        for dev_index in range(self.DEVICE_NBR):
            self.__dict__['mngDeviceActive_' + str('{0:02d}'.format(dev_index))] = {
                        'name': 'mngDeviceActive_' + str(dev_index),
                        'id': self.sys_id << 8 | dev_index,
                        'type': int,
                        'unit': None,
                        'range': [0,1],
                        'default': None,
                        'value': None}

        for dev_index in range(self.DEVICE_NBR):
            self.__dict__['mngFilterMsk_' + str('{0:02d}'.format(dev_index))] = {
                        'name': 'mngFilterMsk_' + str(dev_index),
                        'id': self.sys_id << 8 | 0x04 + dev_index,
                        'type': int,
                        'unit': None,
                        'range': [0,15],
                        'default': None,
                        'value': None}

        for dev_index in range(self.DEVICE_NBR):
            self.__dict__['tempSeriesIdx_' + str('{0:02d}'.format(dev_index))] = {
                        'name': 'tempSeriesIdx_' + str(dev_index),
                        'id': self.sys_id << 8 | 0x08 + dev_index,
                        'type': int,
                        'unit': None,
                        'range': [0,10],
                        'default': None,
                        'value': None}

        for dev_index in range(self.DEVICE_NBR):
            self.__dict__['tempSeriesValue_' + str('{0:02d}'.format(dev_index))] = {
                        'name': 'tempSeriesValue_' + str(dev_index),
                        'id': self.sys_id << 8 | 0x0C + dev_index,
                        'type': int,
                        'unit': None,
                        'range': [-4000,12000],
                        'default': None,
                        'value': None}

        for dev_index in range(self.DEVICE_NBR):
            self.__dict__['seriesFilterIdx_' + str('{0:02d}'.format(dev_index))] = {
                        'name': 'seriesFilterIdx_' + str(dev_index),
                        'id': self.sys_id << 8 | 0x10 + dev_index,
                        'type': int,
                        'unit': None,
                        'range': [0,3],
                        'default': None,
                        'value': None}

        for dev_index in range(self.DEVICE_NBR):
            self.__dict__['inCoeffDataVector_' + str('{0:02d}'.format(dev_index))] = {
                        'name': 'inCoeffDataVector_' + str(dev_index),
                        'id': self.sys_id << 8 | 0x00 + dev_index,
                        'type': float}

        for dev_index in range(self.DEVICE_NBR):
            self.__dict__['outCoeffDataVector_' + str('{0:02d}'.format(dev_index))] = {
                        'name': 'outCoeffDataVector_' + str(dev_index),
                        'id': self.sys_id << 8 | 0x04 + dev_index,
                        'type': float}

        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    def GetManagedDeviceMask(self, device):
        return self.get_register('mngDeviceActive_' + str('{0:02d}'.format(device)))

    def SetManagedDeviceMask(self, device, state):
        return self.set_register('mngDeviceActive_' + str('{0:02d}'.format(device)), state)

    def SelectTempSeriesIdx(self, device, value):
        return self.set_register('tempSeriesIdx_' + str('{0:02d}'.format(device)), value)

    def GetActualTempSeriesIdx(self, device):
        return self.get_register('tempSeriesIdx_' + str('{0:02d}'.format(device)))

    def SelectSeriesFilterIdx(self, device, value):
        return self.set_register('seriesFilterIdx_' + str('{0:02d}'.format(device)), value)

    def GetActualTempSeriesValue(self, device):
        return self.get_register('tempSeriesValue_' + str('{0:02d}'.format(device)))

    def GetInputCoeffs(self, device, index, count):
        vec = []
        # end_index = index + count
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            aux = self._board.get_vector(self.__dict__['inCoeffDataVector_' + str('{0:02d}'.format(device))], i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)
        if remainder:
            aux = self._board.get_vector(self.__dict__['inCoeffDataVector_' + str('{0:02d}'.format(device))], iters * CHUNK_SIZE, remainder)
            vec.extend(aux)
        return vec

    def GetOutputCoeffs(self, device, index, count):
        vec = []
        # end_index = index + count
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            aux = self._board.get_vector(self.__dict__['outCoeffDataVector_' + str('{0:02d}'.format(device))], i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)
        if remainder:
            aux = self._board.get_vector(self.__dict__['outCoeffDataVector_' + str('{0:02d}'.format(device))], iters * CHUNK_SIZE, remainder)
            vec.extend(aux)
        return vec


class XPRControl(System):
    r"""
    Smart step manager is a system in charge of managing lens devices with has the smart step feature applicable.
    system ID: 0x2E

Register Map:
+---------------------+----------------+--------------+----------+--------------+---------------+--------------------+
| Register Name       | Id             | Type         | Unit     | Range        | Default       | Comment            |
+=====================+================+==============+==========+==============+===============+====================+
| mngDeviceMsk        | 0x00           | uint  32-bit | n/a      | <0,15>       |               | read only          |
+---------------------+----------------+--------------+----------+--------------+---------------+--------------------+
| mngFilterMsk        | 0x04-07        | uint  32-bit | n/a      | <0,15>       |               | read only          |
+---------------------+----------------+--------------+----------+--------------+---------------+--------------------+
| tempSeriesIdx       | 0x08-0B        | uint  32-bit | n/a      | <0,10>       |               | read/write         |
+---------------------+----------------+--------------+----------+--------------+---------------+--------------------+
| tempSeriesValue     | 0x0C-0F        | int   32-bit | 100thC   | <-4000,12000>|               | read only          |
+---------------------+----------------+--------------+----------+--------------+---------------+--------------------+
| seriesFilterIdx     | 0x10-13        | int   32-bit | n/a      | <0,3>        |               | read/write         |
+---------------------+----------------+--------------+----------+--------------+---------------+--------------------+

Vector Map:
+-----------------------+-----------+-----------------------+-------------------------------------------+
| Vector Name           | Id        | Type                  | Comment                                   |
+=======================+===========+=======================+===========================================+
| inCoeffDataVector     | 0x00-0x03 | float 32-bit          | input coeffs from selected temp series    |
+-----------------------+-----------+-----------------------+-------------------------------------------+
| outCoeffDataVector    | 0x04-0x07 | float 32-bit          | output coeffs from selected temp series   |
+-----------------------+-----------+-----------------------+-------------------------------------------+

    """

    @staticmethod
    def help():
        print(XPRControl.__doc__)

    def __init__(self, board=None):
        self.sys_id = 0x2E
        self._readonly = False
        self.DEVICE_NBR = 1

        self.frame_rate = {'id': self.sys_id << 8 | 0x00,
                          'type': int,
                          'unit': None,
                          'range':None,
                          'default': 50,
                          'value': 50}
        self.waveform_shape = {'id': self.sys_id << 8 | 0x01,
                         'type': int,
                         'unit': None,
                         'range': {0: 'Manhattan', 1: 'Diamond'},
                         'default': 0,
                         'value': 0}
        self.load = {'id': self.sys_id << 8 | 0x02,
                        'type': int,
                        'unit': None,
                        'range': {0: 'Idle', 1:'Run'},
                        'default': 0,
                        'value': 0}
        self.dev_model = {'id': self.sys_id << 8 | 0x03,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': 0,
                        'value': 0}

        self.vpu_length = {'id': self.sys_id << 8 | 0x04,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': 0,
                        'value': 0}
        self.vpu_sampling = {'id': self.sys_id << 8 | 0x05,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': 0,
                        'value': 0}

        self.active_channel = {'id': self.sys_id << 8 | 0x06,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': 0,
                        'value': 0}

        self.supported_rates_count = {'id': self.sys_id << 8 | 0x07,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': 0,
                        'value': 0}

        self.reference_0 = {'id': self.sys_id << 8, 'type': float}
        self.reference_1 = {'id': self.sys_id << 8 | 0x01, 'type': float}
        self.supported_framerates = {'id': self.sys_id << 8 | 0x02, 'type': float}

        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    # def GetManagedDeviceMask(self):
    #     return self.get_register('mngDeviceMsk')

    def GetFrameRate(self):
        return self.get_register('frame_rate')

    def SetFrameRate(self, value):
        return self.set_register('frame_rate', value)

    def GetWaveformShape(self):
        return self.get_register('waveform_shape')

    def SetWaveformShape(self, value):
        return self.set_register('waveform_shape', value)

    def GetStatus(self):
        return self.get_register('load')

    def SetLoad(self, value):
        return self.set_register('load', value)

    def SetActiveChannel(self, value):
        return self.set_register('active_channel', value)

    def GetActiveChannel(self):
        return self.get_register('active_channel')

    def GetActiveDevice(self):
        return self.get_register('dev_model')

    def GetVPUlength(self):
        return self.get_register('vpu_length')

    def GetVPUsampling(self):
        return self.get_register('vpu_sampling')

    def GetFrameRateCount(self):
        return self.get_register('supported_rates_count')

    def GetReference(self, channel, index, count):
        vec = []
        # end_index = index + count
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            if channel == 0:
                aux = self._board.get_vector(self.reference_0, i * CHUNK_SIZE, CHUNK_SIZE)
            else:
                aux = self._board.get_vector(self.reference_1, i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)
        if remainder:
            if channel == 0:
                aux = self._board.get_vector(self.reference_0, iters * CHUNK_SIZE, remainder)
            else:
                aux = self._board.get_vector(self.reference_1, iters * CHUNK_SIZE, remainder)
            vec.extend(aux)
        return vec

    def GetSupportedFramerates(self):
        vec = []
        # end_index = index + count
        count = 16
        index = 0
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            aux = self._board.get_vector(self.supported_framerates, i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)

        return vec


def systems():
    all_systems = inspect.getmembers(sys.modules[__name__], inspect.isclass)
    all_systems = list(zip(*all_systems))[1]
    sys_dict = {}
    for system in all_systems:
        if hasattr(system, '_is_a_system'):
            try:
                # init instance of each channel in system to get attributes
                for i in range(XPR4_CHANNEL_CNT):
                    sys_obj = system(channel=i)
                    sys_id = sys_obj.sys_id
                    reg_dict = dict(sys_obj.register_list)
                    sys_dict.update({sys_id: {'name': sys_obj.name, 'registers': reg_dict}})
            except TypeError:
                # system does not have multiple channels
                sys_obj = system()
                sys_id = sys_obj.sys_id
                reg_dict = dict(sys_obj.register_list)
                sys_dict.update({sys_id: {'name': sys_obj.name, 'registers': reg_dict}})
            except AttributeError:
                # abstract system, do not add to list. this shouldn't happen
                pass
    return sys_dict
