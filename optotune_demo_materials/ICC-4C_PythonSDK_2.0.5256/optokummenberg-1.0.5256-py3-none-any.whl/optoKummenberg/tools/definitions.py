from enum import IntEnum

# Kummenberg Internal Definitions
MAX_PAYLOAD_SIZE = 50
SAMPLING_FREQ = 10000
ENDIAN = ">"
CHANNEL_CNT = 4
MAX_CHANNEL_CNT = 8
SIGNAL_FLOW_STAGE_CNT = 5
CMD_TIMEOUT = 1
CHUNK_SIZE = 8
ESCAPE_BYTE = 0x7D
FRAME_BOUNDARY = 0x7E
ESCAPE_MASK = 1 << 5

SimpleResponses = {
    'PROCESSED_WITHOUT_ERROR' : b'OK\r\n',
    'OUT_OF_RANGE_UPPER'      : b'OU\r\n',
    'OUT_OF_RANGE_LOWER'      : b'OL\r\n',
    'UNRECOGNIZED_MESSAGE'    : b'NO\r\n',
    'ERROR'                   : b'ERROR\r\n'
}


class CommandID:
    GENERIC_COMMAND = 0x00
    GET_FIRMWARE_ID = 0X01
    GET_STATUS      = 0X02
    START_SELF_TEST = 0X03
    LOAD_CONFIG     = 0X04
    STORE_CONFIG    = 0X05
    SET_COMM_MODE   = 0X06
    SET_VALUE       = 0X10
    GET_VALUE       = 0X11
    SET_MULTIPLE    = 0X12
    GET_MULTIPLE    = 0X13
    SET_VECTOR      = 0X14
    GET_VECTOR      = 0X15
#    CRC_ENABLED     = True


commandID = {
            'GENERIC_COMMAND' : 0X00,
            'GET_FIRMWARE_ID' : 0X01,
            'GET_STATUS'      : 0X02,
            'START_SELF_TEST' : 0X03,
            'LOAD_CONFIG'     : 0X04,
            'STORE_CONFIG'    : 0X05,
            'SET_COMM_MODE'   : 0X06,
            'SET_VALUE'       : 0X10,
            'GET_VALUE'       : 0X11,
            'SET_MULTIPLE'    : 0X12,
            'GET_MULTIPLE'    : 0X13,
            'SET_VECTOR'      : 0X14,
            'GET_VECTOR'      : 0X15
            }
commandName = dict((value, key) for key, value in commandID.items())


class UnitType(IntEnum):
    CURRENT   = 0
    OF        = 1
    XY     = 2
    FP     = 3
    UNITLESS = 4
    UNDEFINED = 5


class Units:
    CURRENT   = 0
    OF        = 1
    XY     = 2
    FP     = 3
    UNITLESS = 4
    UNDEFINED = 5


class WaveformShape(IntEnum):
    SINUSOIDAL = 0
    TRIANGULAR = 1
    RECTANGULAR = 2
    SAWTOOTH = 3
    PULSE = 4
    STAIRCASE = 5
    STAIRCASE_TRIANGLE = 6
    STAIRCASE_CUT_TRIANGLE = 7
    FAST_AUTOFOCUS = 8


class Waveforms:
    SINUSOIDAL  = 0
    TRIANGULAR  = 1
    RECTANGULAR = 2
    SAWTOOTH    = 3
    PULSE       = 4
    STAIRCASE   = 5
    STAIRCASE_TRIANGLE = 6
    STAIRCASE_CUT_TRIANGLE = 7
    FAST_AUTOFOCUS = 8


# definition of generic filter stage components
class GenericFilterFlag:
    ENABLE_FILTER_01 = 0x01
    ENABLE_FILTER_02 = 0x02
    ENABLE_FILTER_03 = 0x04
    ENABLE_FILTER_04 = 0x08


# definitions of signal flow paths
class EnSignalFlowPath(IntEnum):
    MAIN_FLOW  = 0
    FEED_FORWARD  = 1
    FEED_BACK = 2
    PATH_NBR = 3


# definitions of signal flow paths
class EnChannel(IntEnum):
    CHANNEL_0  = 0
    CHANNEL_1  = 1
    CHANNEL_2 = 2
    CHANNEL_3 = 3
    CHANNEL_ALL_MIMO = 0
    CHANNEL_NBR = 4


# definitions of signal flow paths
class EnStage(IntEnum):
    INPUT  = 0
    INPUT_COND  = 1
    CONTROL = 2
    OUTPUT_COND = 3
    OUTPUT = 4
    STAGE_NBR =5

# definitions of logger trigger modes
class LoggerTriggerMode (IntEnum):
    LOGGER_NON_TRIGGERED = 0
    LOGGER_TRIGGER_EQUAL = 1
    LOGGER_TRIGGER_RISING = 2
    LOGGER_TRIGGER_FALLING = 3

# definitions of logger trigger formats
class LoggerTriggerFormat (IntEnum):
    LOGGER_TRIGGER_UINT32 = 0
    LOGGER_TRIGGER_INT32 = 1
    LOGGER_TRIGGER_FLOAT = 2

# definitions of logger trigger run states
class LoggerRunState (IntEnum):
    LOGGER_STOPPED 		= 0
    LOGGER_RUN 			= 1
    LOGGER_WAITING		= 2
    LOGGER_FINISHED		= 3

# definitions of device models
class DeviceModel(IntEnum) :
    DISCONNECTED = 0
    XPR20 = 1
    XPR20_2CH = 2
    EL1030TC = 3
    XPR46 = 4
    EL1640TC_5D = 5
    EL1230TC_NLP = 6
    EL1030C = 7
    XPR33 = 8
    XPR33_2CH = 9
    DEVICE_URSA = 10,
    DEVICE_ZAURAK = 11,
    XPR42 = 12,
    SARYN_F1 = 13,
    EL0930TC_NLP = 14,
    EL0310 = 15,
    XPRAUTO = 16,
    EL0310FPC = 17,
    EL1030HP = 18,
    EL0830TC_NLP = 19,
    EL1030TC_NLP = 20,
    EL1640GTC = 21,
    EL0720TC_NLP = 22,
    EL1230GTC_NLP = 23,
    EL42SMA = 24,
    MR_15_30 = 25,
    MR_15_30_2CH = 26,
    MR_10_30 = 27,
    EL1640TC_20D = 28,
    XPR18 = 29,
    XPR18_2CH = 30,
    XPR26 = 31,
    XPR26_2CH = 32,
    WASSAT = 33,
    WASSAT_2CH = 34,
    FMR = 35,
    FMR_2CH = 36,
    UNKNOWN = 255


class ExternalTrigger(IntEnum):
    DISABLED = 0
    RISING_FALLING_EDGE = 1
    RISING_EDGE = 2
