from abc import ABC, abstractmethod
from typing import List

from optoKummenberg import EnSignalFlowPath

from optoKummenberg.registers.SignalFlowManager import SignalFlowManager

from .ClassAbstracts import InputStage
from .generic_registers import get_registers
from ..tools.definitions import UnitType, WaveformShape
from ..tools.systems_registers_tools import is_valid_channel


class SPI(InputStage):
    r"""
Input Channel Systems - SPI
System ID: 0x48 through 0x4f

+----------------+------+-------------+----------+--------+---------+---------------------------------------+
| Register Name  | Id   | Type        | Unit     | Range  | Default | Comment                               |
+================+======+=============+==========+========+=========+=======================================+
| input          | 0x01 | uint 32-bit | None     | 0 to 5 | 0       | For both channel. See registers table |
+----------------+------+-------------+----------+--------+---------+---------------------------------------+

    """

    @staticmethod
    def help():
        print(SPI.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x48 | channel
        self._readonly = False

        self.input = {'id': self.sys_id << 8 | 0x01,
                      'type': int,
                      'unit': None,
                      'range': [0, 5],
                      'default': 0,
                      'value': 0}
        InputStage.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    def SelectInput(self, value):
        return self.set_register('input', value)


class StaticInput(InputStage):
    r"""
Input Channel Systems - USB/UART
System IDs: 0x50 through 0x57

+----------------+------+-------------+----------+-------------+---------+---------------------------------------+
| Register Name  | Id   | Type        | Unit     | Range       | Default | Comment                               |
+================+======+=============+==========+=============+=========+=======================================+
| current        | 0x00 | float 32-bit| A        | -0.7 to 0.7 | 0.0     |                                       |
+----------------+------+-------------+----------+-------------+---------+---------------------------------------+

    """

    @staticmethod
    def help():
        print(StaticInput.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x50 | channel
        self._readonly = False

        self.current = {'id': self.sys_id << 8 | 0x00,
                        'type': float,
                        'unit': 'A',
                        'range': [-2, 2],
                        'default': 0.0,
                        'value': 0.0}

        self.value = {'id': self.sys_id << 8 | 0x05,
                      'type': float,
                      'unit': 'Unitless',
                      'range': [-1000, 1000],
                      'default': 0.0,
                      'value': 0.0}

        InputStage.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    ## Sets current on this channel [A]
    def SetCurrent(self, value):
        return self.set_register('current', value)

    ## Gets current on this channel [A]
    def GetCurrent(self):
        return self.get_register('current')

    ## Sets unitless value on this channel
    def SetValue(self, value):
        return self.set_register('value', value)

    ## Gets unitless value on this channel
    def GetValue(self):
        return self.get_register('value')


class Analog(InputStage):
    r"""
        Input Channel Systems - Analog Input
        System ID: 0x58 through 0x5f

        +-------------------+------+-------------+--------------------+-------------+---------+------------------------+
        | Register Name     | Id   | Type        | Unit               | Range       | Default | Comment                |
        +===================+======+=============+====================+=============+=========+========================+
        | ADC raw value     |0x01  | uint 32-bit | Volt               |0            | 0       | Converted ADC raw value|
        +-------------------+------+-------------+--------------------+-------------+---------+------------------------+
        | Active input type |0x01  | uint 32-bit | UnitType           |0            | 0       | Read only              |
        +-------------------+------+-------------+--------------------+-------------+---------+------------------------+
        | Minimum Current   |0x02  | float 32-bit| Volt               |             | 0       |                        |
        +-------------------+------+-------------+--------------------+-------------+---------+------------------------+
        | Maximum Current   |0x03  | float 32-bit| Volt               |             | 0       |                        |
        +-------------------+------+-------------+--------------------+-------------+---------+------------------------+
        | Minimum Diopter   |0x04  | float 32-bit| Dpt                |             | 0       |                        |
        +-------------------+------+-------------+--------------------+-------------+---------+------------------------+
        | Maximum Diopter   |0x05  | float 32-bit| Dpt                |             | 0       |                        |
        +-------------------+------+-------------+--------------------+-------------+---------+------------------------+
        | Cal coef enable   |0x06  | uint 32-bit | None               |             | 0       | Enable calibrated input|
        +-------------------+------+-------------+--------------------+-------------+---------+------------------------+
        | Analog input type |0x07  | uint 32-bit | A | Dpt            |             | 0       | LUT Unit type          |
        +-------------------+------+-------------+--------------------+-------------+---------+------------------------+
        | Extrapolation type|0x08  | uint 32-bit | None               |             | 0       | constant=0 or linear=1 |
        +-------------------+------+-------------+--------------------+-------------+---------+------------------------+

        registers table 1:

        +--------------------------------+---------------+-------------------------+-----------------------------------+
        | Analogue Input Unit            | Default       | Description             | Format and value                  |
        +================================+===============+=========================+===================================+
        | voltages -> LUT table values   | 0             | 1.voltage               | max 10 * float                    |
        +--------------------------------+---------------+-------------------------+-----------------------------------+
        | current/dpt -> LUT table values| 0             | 2.value(current/FP)     | max 10 & same as voltages * float |
        +--------------------------------+---------------+-------------------------+-----------------------------------+
        | Analog input cal.coefficients  | {0,1,0,0,0,0} | 5th grade polynomial    | 	6 * float (24 bytes)           |
        +--------------------------------+---------------+-------------------------+-----------------------------------+
    """

    @staticmethod
    def help():
        print(Analog.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x58 | channel
        self._unitranges = {'A': [-1, 1]}
        self._readonly = False

        self.adc_value = {'id': self.sys_id << 8 | 0x00,
                     'type': float,
                     'unit': None,
                     'range': None,
                     'default': 0,
                     'value': 0}
        self.unit = {'id': self.sys_id << 8 | 0x01,
                     'type': int,
                     'unit': ['A'],
                     'range': {0: 'Current'},
                     'default': 0,
                     'value': 0}
        self.minimum = {'id': self.sys_id << 8 | 0x02,
                        'type': float,
                        'unit': 'Volt',
                        'range': None,
                        'default': 0.0,
                        'value': 0.0}
        self.maximum = {'id': self.sys_id << 8 | 0x03,
                        'type': float,
                        'unit': 'Volt',
                        'range': None,
                        'default': 0.0,
                        'value': 0.0}
        self.mapping_minimum = {'id': self.sys_id << 8 | 0x04,
                                'type': float,
                                'unit': 'A',
                                'range': [-1, 1],
                                'default': 0,
                                'value': 0}
        self.mapping_maximum = {'id': self.sys_id << 8 | 0x05,
                                'type': float,
                                'unit': ['A', None, 'Degrees'],
                                'range': None,
                                'default': 0,
                                'value': 0}
        self.calCoefEnable = {'id': self.sys_id << 8 | 0x06,
                              'type': int,
                              'unit': [None],
                              'range': None,
                              'default': 0,
                              'value': 0}
        self.LUTinputType = {'id': self.sys_id << 8 | 0x07,
                             'type': int,
                             'unit': [None],
                             'range': None,
                             'default': 0,
                             'value': 0}
        self.LUTextrapolationType = {'id': self.sys_id << 8 | 0x08,
                                     'type': int,
                                     'unit': [None],
                                     'range': None,
                                     'default': 0,
                                     'value': 0}
        self.norm_value = {'id': self.sys_id << 8 | 0x09,
                     'type': float,
                     'unit': None,
                     'range': None,
                     'default': 0,
                     'value': 0}
        self.LUT_size = {'id': self.sys_id << 8 | 0x0A,
                         'type': int,
                         'unit': None,
                         'range': None,
                         'default': 0,
                         'value': 0}

        self.LUT_voltage = {'id': self.sys_id << 8, 'type': float}
        self.LUT_value = {'id': self.sys_id << 8 | 0x01, 'type': float}

        InputStage.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    ## Gets size of lookup table
    def GetLUTsize(self):
        return self.get_register('LUT_size')

    ## Sets voltages into lookup table (vector based)
    def SetLUTvoltages(self, voltage):
        return self._board.set_vector(self.LUT_voltage, 0, voltage)

    ## Gets voltage values stored in lookup table (vector based)
    def GetLUTvoltages(self):
        lut_size = self.get_register('LUT_size')
        return self._board.get_vector(self.LUT_voltage, 0, lut_size)

    ## Sets values (current of focal power) into lookup table (vector based)
    def SetLUTvalues(self, value):
        return self._board.set_vector(self.LUT_value, 0, value)

    ## Gets values stored in lookup table (vector based)
    def GetLUTvalues(self):
        lut_size = self.get_register('LUT_size')
        return self._board.get_vector(self.LUT_value, 0, lut_size)

    ## Enables/disables calibrated input, 0 = disabled, 1 = enabled
    def SetCalCoefEnable(self, value):
        return self.set_register('calCoefEnable', value)

    ## Sets unit type of the values stored in lookup table, 0 = current, 1 = focal power
    def SetLUTtype(self, value):
        return self.set_register('LUTinputType', value)

    ## Gets unit type of the values stored in lookup table, 0 = current, 1 = focal power
    def GetLUTtype(self):
        return self.get_register('LUTinputType')

    ## Sets extrapolation type,  0 = constant, 1 = linear
    def SetExtrapolationType(self, value):
        return self.set_register('LUTextrapolationType', value)

    ## Gets unit type determined by active control stage system
    def GetActiveUnitType(self):
        return self.get_register('unit')

    def GetMinimum(self):
        return self.get_register('minimum')

    def SetMinimum(self, value):
        return self.set_register('minimum', value)

    def GetMaximum(self):
        return self.get_register('maximum')

    def SetMaximum(self, value):
        return self.set_register('maximum', value)

    def GetMappingMinimum(self):
        return self.get_register('mapping_minimum')

    def SetMappingMinimum(self, value):
        return self.set_register('mapping_minimum', value)

    def GetMappingMaximum(self):
        return self.get_register('mapping_maximum')

    def SetMappingMaximum(self, value):
        return self.set_register('mapping_maximum', value)


class SignalGenerator(InputStage):
    r"""
    Input Channel Systems - Signal Generator Channel
    System ID for channel 0: 0x60

    Signal Generator is a system for generating input signals of particular \ref WaveformShape "shapes".
    It is an input stage system, meaning that it is a system used as the very first stage of \ref signalflow.

    To set it up, all the appropriate registers (seen in the table below) have to be configured first.
    The shape of the signal, its frequency, amplitude, offset and phase can be adjusted.
    For the square and pulse waveforms, the signal's duty cycle can be configured.

    The unit type of the value being output by the
    SignalGenerator, must match to the control mode selected by the \ref SignalFlowManager "Signal Flow Manager".

    By default, the Signal Generator will continuously output the waveform corresponding to the configuration.
    If only a single period is desired (or N periods for some finite positive integer N),
    the number of desired periods to execute has to be set to the "cycles" register before running the system.
    A negative value in this register corresponds to infinite looping.

    Finally, to get the configured SignalFlow generator to run, the following steps have to take place:
      -# The Signal Generator system has to be set as active Input Stage system for the corresponding channel. This is done through the \ref SignalFlowManager "Signal Flow Manager" system.
      -# The "Run" register of the corresponding Signal Generator system has to be set to true (any non-zero value).

    ### Register Map:

    | Address    | Name                      | Default Value | Description                                                                                                               | Type                  | Access
    | -----------|---------------------------|---------------|---------------------------------------------------------------------------------------------------------------------------|-----------------------|-------------------
    | 0x6[0-7]00 | Unit type                 | 0             |                                                                                                                           | \ref ChannelValueType | read write
    | 0x6[0-7]01 | Run                       | false         | Turn Signal Generator on/off                                                                                              | boolean               | read write
    | 0x6[0-7]02 | Shape                     | 0             |                                                                                                                           | \ref WaveformShape    | read write
    | 0x6[0-7]03 | Frequency                 | 0.0           | Frequency in Hz of generated signal                                                                                       | float                 | read write
    | 0x6[0-7]04 | Amplitude                 | 0.0           | Amplitude of generated signal                                                                                             | float                 | read write
    | 0x6[0-7]05 | Offset                    | 0.0           | Offset of generated signal                                                                                                | float                 | read write
    | 0x6[0-7]06 | Phase                     | 0.0 [rad]     | Phase of generated signal in radians                                                                                      | float                 | read write
    | 0x6[0-7]07 | Cycles                    | -1            | Number of cycles to be generated. Run flag is turned off after completion. Negative value corresponds to infinite looping | int32                 | read write
    | 0x6[0-7]08 | Duty cycle                | 0.5           | Duty cycle of square and pulse shapes                                                                                     | 0 to 1 float <BR> Resolution is frequency/10000 | read write
    | 0x6[0-7]09 | External trigger          | 0             | Signal generator unit can be synchronised with external signal (0=disabled, 1=rising/falling edge, 2=rising edge trigger) | uint32                | read write
    | 0x6[0-7]0a | Output                    | N/A           | Output of signal generator                                                                                                | float                 | read only
    | 0x6[0-7]0b | Stair count               | 5             | Count + direction of stairs for Staircase and FastAutoFocus shape<br/>(for FastAutoFocus it defines number of output trigger pulses, for other shapes it has no effect) | int32 (-100 to 100)   | read write
    | 0x6[0-7]0c | External trigger GPIOx    | false         | Turns GPIOx pin to trigger input source (GPIOx default is trigger output) and disables global external trigger SYNCx pin  | boolean               | read write
    | 0x6[0-7]0d | Output trigger time shift (*)| 0.0 [ms]   | Allows fine adjustment of output trigger timing versus generated output signal<br/>(can be only positive, limit of shift value = period/stair count; the trigger pulse duration will be cut above this limit) | float | read write
    | 0x6[0-7]0e | Output trigger duty cycle (*)| 0.5        | Duty cycle of the trigger pulse with respect to period of generated signal<br/>(for real duration it has to be multiplied with period; for staircase shape with period/stair count)| float (0.0 to 1.0) | read write
    | 0x6[0-7]0f | Settling delay (*)           | 0.0 [ms]   | For FastAutoFocus shape it allows to add extra time with constant value before and after the ramp to minimise ringing effect <br/>(max. value is limited to 25% of period)| float | read write

    \note
    (*) Output trigger time shift is available only for Staircase and FastAutoFocus shapes which are dedicated for usage with a camera.
     	Range of allowed values depends on frequency and stair count therefore these registers have to be set in advance.

    registers table 1:

    +---------------+-------+
    | Waveform Unit | Value |
    +===============+=======+
    | Current       | 0     |
    +---------------+-------+
    | OF            | 1     |
    +---------------+-------+
    | XY            | 2     |
    +---------------+-------+
    | FP            | 3     |
    +---------------+-------+
    | Unitless      | 4     |
    +---------------+-------+

    registers table 2:

    +----------------------+-------+
    | Waveform Shape       | Value |
    +======================+=======+
    | Sinusoidal           | 0     |
    +----------------------+-------+
    | Triangular           | 1     |
    +----------------------+-------+
    | Rectangular          | 2     |
    +----------------------+-------+
    | Sawtooth             | 3     |
    +----------------------+-------+
    | Pulse                | 4     |
    +----------------------+-------+
    | Staircase            | 5     |
    +----------------------+-------+
    | StaircaseTriangle    | 6     |
    +----------------------+-------+
    | StaircaseCutTriangle | 7     |
    +----------------------+-------+
    | FastAutoFocus        | 8     |
    +----------------------+-------+

    Note: FastAutoFocus is a sawtooth shaped wave prepared especially for camera triggering. It is connected with adjustable output trigger signal.
    """

    # TODO: range may depend on selected input units.
    @staticmethod
    def help():
        print(SignalGenerator.__doc__)

    def __init__(self, channel: int = 0, board=None, sys_id_base=0x60):
        self.name = self.__class__.__name__

        self.sys_id = sys_id_base | channel

        self.unit = {'id': self.sys_id << 8 | 0x00,
                     'type': int,
                     'unit': None,
                     'range': {0: 'Current', 1: 'OF', 2: 'XY', 3: 'FP', 4: 'NoUnit'},
                     'default': 0,
                     'value': 0}
        self.run = {'id': self.sys_id << 8 | 0x01,
                    'type': int,
                    'unit': bool,
                    'range': [0, 1],
                    'default': 0,
                    'value': 0}
        self.shape = {'id': self.sys_id << 8 | 0x02,
                      'type': int,
                      'unit': None,
                      'range': {0: 'Sinusoidal', 1: 'Triangular', 2: 'Rectangular', 3: 'Sawtooth', 4: 'Pulse',
                                5: 'Staircase', 6: 'StaircaseTriangle', 7: 'StaircaseCutTriangle', 8: 'FastAutoFocus'},
                      'default': 0,
                      'value': 0}
        self.frequency = {'id': self.sys_id << 8 | 0x03,
                          'type': float,
                          'unit': 'Hz',
                          'range': None,
                          'default': 0.0,
                          'value': 0.0}
        self.amplitude = {'id': self.sys_id << 8 | 0x04,
                          'type': float,
                          'unit': None,
                          'range': None,
                          'default': 0.0,
                          'value': 0.0}
        self.offset = {'id': self.sys_id << 8 | 0x05,
                       'type': float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.phase = {'id': self.sys_id << 8 | 0x06,
                      'type': float,
                      'unit': 'Rad',
                      'range': None,
                      'default': 0.0,
                      'value': 0.0}
        self.cycles = {'id': self.sys_id << 8 | 0x07,
                       'type': int,
                       'unit': None,
                       'range': None,
                       'default': -1,
                       'value': -1}
        self.duty_cycle = {'id': self.sys_id << 8 | 0x08,
                           'type': float,
                           'unit': None,
                           'range': [0, 1.0],
                           'default': 0.5,
                           'value': 0.5}
        self.external_trigger = {'id': self.sys_id << 8 | 0x09,
                                 'type': int,
                                 'unit': None,
                                 'range': None,
                                 'default': False,
                                 'value': False}
        self.output = {'id': self.sys_id << 8 | 0x0a,
                       'type': float,
                       'unit': None,
                       'range': None,
                       'default': None,
                       'value': None}
        self.stair_count = {'id': self.sys_id << 8 | 0x0b,
                       'type': int,
                       'unit': None,
                       'range': [-100, 100],
                       'default': 5,
                       'value': None}
        self.ext_trigger_gpio = {'id': self.sys_id << 8 | 0x0c,
                            'type': bool,
                            'unit': None,
                            'range': None,
                            'default': 0, #false
                            'value': None}
        self.out_trigger_shift = {'id': self.sys_id << 8 | 0x0d,
                                  'type': float,
                                  'unit': None,
                                  'range': None,
                                  'default': 0.0,
                                  'value': 0.0}
        self.out_trigger_duty = {'id': self.sys_id << 8 | 0x0e,
                                 'type': float,
                                 'unit': None,
                                 'range': [0, 1.0],
                                 'default': 0.5,
                                 'value': 0.5}
        self.settling_delay = {'id': self.sys_id << 8 | 0x0f,
                                 'type': float,
                                 'unit': None,
                                 'range': None,
                                 'default': 0.0,
                                 'value': 0.0}

        self.inst_phase = {'id': self.sys_id << 8 | 0x10,
                       'type': float,
                       'unit': None,
                       'range': [0, 1.0],
                       'default': None,
                       'value': None}

        InputStage.__init__(self, channel, board)
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    ## Sets the unit type of the values set to the signal generator.
    def SetUnit(self, value: UnitType or int):
        return self.set_register('unit', value)

    ## Gets the unit type of the values set to the signal generator.
    def GetUnit(self) -> UnitType:
        return UnitType(self.get_register('unit'))

    ## Starts the signal generator.
    def Run(self):
        return self.set_register('run', 1)

    ## Stops the signal generator.
    def Stop(self):
        return self.set_register('run', 0)

    ## Gets the running status of the signal generator. 1 = running, 0 = stopped
    def GetRunningStatus(self):
        return self.get_register('run')

    ## Sets the shape of the generated signal.
    def SetShape(self, value: WaveformShape or int):
        return self.set_register('shape', value)

    ## Gets the shape of the generated signal.
    def GetShape(self) -> WaveformShape:
        return WaveformShape(self.get_register('shape'))

    ## Sets the frequency of the generated signal. [Hz]
    def SetFrequency(self, value):
        return self.set_register('frequency', value)

    ## Gets the frequency of the generated signal. [Hz]
    def GetFrequency(self):
        return self.get_register('frequency')

    ## Sets the amplitude of the generated signal. Unit is specified by SetUnit method.
    def SetAmplitude(self, value):
        return self.set_register('amplitude', value)

    ## Gets the amplitude of the generated signal. Unit is specified by SetUnit method.
    def GetAmplitude(self):
        return self.get_register('amplitude')

    ## Sets the offset of the generated signal. Unit is specified by SetUnit method.
    def SetOffset(self, value):
        return self.set_register('offset', value)

    ## Gets the offset of the generated signal. Unit is specified by SetUnit method.
    def GetOffset(self):
        return self.get_register('offset')

    ## Sets the phase delay of the generated signal. [rad]
    def SetPhase(self, value):
        return self.set_register('phase', value)

    ## Gets the phase delay of the generated signal. [rad]
    def GetPhase(self):
        return self.get_register('phase')

    ## Sets the number of cycles the generated signal. Setting -1 runs the signal generator in the loop until stopped.
    def SetCycles(self, value):
        return self.set_register('cycles', value)

    ## Gets the number of cycles the generated signal. Value -1 represents running the signal generator in the loop.
    def GetCycles(self):
        return self.get_register('cycles')

    ## Sets duty cycle of the generated signal. Default is 0.5 (range 0-1)
    def SetDutyCycle(self, value):
        return self.set_register('duty_cycle', value)

    ## Gets duty cycle of the generated signal. Default is 0.5 (range 0-1)
    def GetDutyCycle(self):
        return self.get_register('duty_cycle')

    ## Sets the external trigger mode. Signal generator can be synchronised with external signal
    # (0=disabled, 1=rising/falling edge, 2=rising edge trigger)
    def SetExternalTrigger(self, value):
        return self.set_register('external_trigger', value)

    ## Gets output of the signal generator
    def GetOutput(self):
        return self.get_register('output')

    ## Sets stair count of the generatred signal, only available when shape is set to stair.
    def SetStairCount(self, value):
        return self.set_register('stair_count', value)

    ## Gets stair count of the generatred signal, only available when shape is set to stair.
    def GetStairCount(self):
        return self.get_register('stair_count')

    ## Turns GPIOx pin to trigger input source (GPIOx default is trigger output) and disables global external trigger
    # SYNCx pin. 0 = off, 1 = on
    def SetExtTriggerGPIO(self, value):
        return self.set_register('ext_trigger_gpio', value)

    ## Gets the state of GPIOx pin to trigger input source (GPIOx default is trigger output) and disables global
    # external trigger SYNCx pin. 0 = off, 1 = on
    def GetExtTriggerGPIO(self):
        return self.get_register('ext_trigger_gpio')

    ## Allows fine adjustment of output trigger timing versus generated output signal (value in ms)
    # (limit of shift value = period)
    def SetOutTriggerTimeShift(self, value):
        return self.set_register('out_trigger_shift', value)

    ## Gets output trigger timing shift value (in ms)
    def GetOutTriggerTimeShift(self):
        return self.get_register('out_trigger_shift')

    ## Sets duty cycle of the trigger pulse with respect to period of generated signal
    # (for real duration it has to be multiplied with period; for staircase shape with period/stair count)
    def SetOutTriggerDutyCycle(self, value):
        return self.set_register('out_trigger_duty', value)

    ## Gets duty cycle of the trigger pulse with respect to period of generated signal
    def GetOutTriggerDutyCycle(self):
        return self.get_register('out_trigger_duty')

    ## Sets settling delay (in ms) which for FastAutoFocus shape allows to add extra time with constant value before
    # and after the ramp to minimise ringing effect (max. value is limited to 25% of period)
    def SetSettlingDelay(self, value):
        return self.set_register('settling_delay', value)

    ## Gets settling delay value
    def GetSettlingDelay(self):
        return self.get_register('settling_delay')



class VectorPatternUnit(InputStage):
    r"""
Input Channel Systems - Vector Pattern Unit
System ID: 0x68 through 0x6f

 *
 * The Vector Pattern Unit system is an input stage system that can used to propagate
 * arbitrary vector values set by the user as input to the \ref signalflow.
 * The values must be saved in the \ref VectorPatternMemory  "Vector Pattern Memory".
 * The Vector Pattern system has to be activated through the \ref SignalFlowManager.
 * Unit type has to match to the configured control mode.
 *
 * ### Register Map:
 *
 * | Address    | Name                   | Default Value    | Description                                                                                                               | Type                  | Access
 * | -----------|------------------------|------------------|---------------------------------------------------------------------------------------------------------------------------|-----------------------| ----------
 * | 0x6[8-F]00 | Unit type              | 0                |                                                                                                                           | \ref ChannelValueType | read write
 * | 0x6[8-F]01 | Run                    | false            | Turn Vector Pattern Unit on/off                                                                                           | boolean               | read write
 * | 0x6[8-F]02 | Start                  | 0                | Index of first desired point in \ref VectorPatternMemory "Vector Pattern Memory" <br/> (start of transition triggered by rising edge of external signal if External trigger configured) | uint32                | read write
 * | 0x6[8-F]03 | End                    | 0                | Index after last desired point in \ref VectorPatternMemory  "Vector Pattern Memory"  <br/> (end of transition triggered by rising edge of external signal if External trigger configured) | uint32                | read write
 * | 0x6[8-F]04 | Sample rate            | 20000            | Sample rate at which the Vector Pattern unit samples the vector in the \ref VectorPatternMemory  "Vector Pattern Memory"  | float                 | read write
 * | 0x6[8-F]05 | Minimum sampling rate  | \f$ \frac{20000}{2^{32}-1} \f$ | In Hz                                                                                                       | float                 | read only
 * | 0x6[8-F]06 | Maximum sampling rate  | 20000            | In Hz                                                                                                                     | float                 | read only
 * | 0x6[8-F]07 | Cycles                 | -1               | Number of cycles to be generated. Run flag is turned off after completion. Negative value corresponds to infinite looping | int32                 | read write
 * | 0x6[8-F]08 | External trigger       | 0                | Vector Pattern Unit can be synchronised with external signal (0=disabled, 1=rising/falling edge, 2=rising edge)           | uint32                | read write
 * | 0x6[8-F]09 | Output                 | N/A              | Output of the vector pattern unit                                                                                         | float                 | read only
 * | 0x6[8-F]0A | Start2                 | 0                | Index of first desired point in \ref VectorPatternMemory "Vector Pattern Memory" <br/> (start of second part of transition triggered by falling edge of external signal) | uint32                | read write
 * | 0x6[8-F]0B | End2                   | 0                | Index after last desired point in \ref VectorPatternMemory "Vector Pattern Memory" <br/> (end of second part of transition triggered by falling edge of external signal) | uint32                | read write
 * | 0x6[8-F]0C | External trigger GPIOx | false            | Turns GPIOx pin to trigger input source (GPIOx default is trigger output) and disables global external trigger SYNCx pin  | boolean               | read write
 * | 0x6[8-F]0D | Actual index           | 0                | Returns index of actual sample                                                                                            | uint32                | read only
 * | 0x6[8-F]0E | Trigger divider        | 1                | Divider for trigger signal                                                                                                | uint32                | read write
 * | 0x6[8-F]0F | Trigger offset         | 0                | Offset for trigger signal (value must be less than divider value, important to set divider first)                         | uint32                | read write
 *
 * \note
 * Full register address varies according to the channel.
 *
 * For example:
 *
 * Start register of channel two has address 0x6902
 *
 * End register of channel one has address 0x6803
 *

    """

    @staticmethod
    def help():
        print(VectorPatternUnit.__doc__)

    def __init__(self, channel: int = 0, board=None, sys_id_base=0x68):
        self.sys_id = sys_id_base | channel

        self.unit = {'id': self.sys_id << 8 | 0x00,
                     'type': int,
                     'unit': None,
                     'range': {0: 'Current', 5: 'NoUnit'},
                     'default': 1,
                     'value': 1}
        self.run = {'id': self.sys_id << 8 | 0x01,
                    'type': bool,
                    'unit': None,
                    'range': [True, False],
                    'default': False,
                    'value': False}
        self.start = {'id': self.sys_id << 8 | 0x02,
                      'type': int,
                      'unit': None,
                      'range': None,
                      'default': 0,
                      'value': 0}
        self.end = {'id': self.sys_id << 8 | 0x03,
                    'type': int,
                    'unit': None,
                    'range': None,
                    'default': 0,
                    'value': 0}
        self.frequency_speed = {'id': self.sys_id << 8 | 0x04,
                                'type': float,
                                'unit': 'Hz',
                                'range': None,
                                'default': 10000,
                                'value': 10000}
        self.min_speed = {'id': self.sys_id << 8 | 0x05,
                          'type': float,
                          'unit': 'Hz',
                          'range': None,
                          'default': 0,
                          'value': 0.0}
        self.max_speed = {'id': self.sys_id << 8 | 0x06,
                          'type': float,
                          'unit': 'Hz',
                          'range': None,
                          'default': 0,
                          'value': 0.0}
        self.cycles = {'id': self.sys_id << 8 | 0x07,
                       'type': int,
                       'unit': 'Hz',
                       'range': None,
                       'default': -1,
                       'value': -1}
        self.external_trigger = {'id': self.sys_id << 8 | 0x08,
                                 'type': int,
                                 'unit': None,
                                 'range': None,
                                 'default': False,
                                 'value': False}
        self.output = {'id': self.sys_id << 8 | 0x09,
                       'type': float,
                       'unit': None,
                       'range': None,
                       'default': None,
                       'value': None}
        self.start2 = {'id': self.sys_id << 8 | 0x0a,
                       'type': int,
                       'unit': None,
                       'range': None,
                       'default': 0,
                       'value': 0}
        self.end2 = {'id': self.sys_id << 8 | 0x0b,
                     'type': int,
                     'unit': None,
                     'range': None,
                     'default': 0,
                     'value': 0}
        self.ext_trigger_gpio = {'id': self.sys_id << 8 | 0x0c,
                                 'type': int,
                                 'unit': None,
                                 'range': None,
                                 'default': 0,
                                 'value': 0}
        self.index = {'id': self.sys_id << 8 | 0x0d,
                      'type': int,
                      'unit': None,
                      'range': None,
                      'default': 0,
                      'value': 0}

        self.trigger_divider = {'id': self.sys_id << 8 | 0x0e,
                      'type': int,
                      'unit': None,
                      'range': None,
                      'default': 0,
                      'value': 0}

        self.trigger_offset = {'id': self.sys_id << 8 | 0x0f,
                      'type': int,
                      'unit': None,
                      'range': None,
                      'default': 0,
                      'value': 0}

        InputStage.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    ## Sets the unit type of the values set to the vector pattern system.
    def SetUnit(self, value: UnitType or int):
        return self.set_register('unit', value)

    ## Gets the unit type of the values set to the vector pattern system.
    def GetUnit(self) -> UnitType:
        return UnitType(self.get_register('unit'))

    ## Starts vector pattern system
    def Run(self):
        return self.set_register('run', 1)

    ## Stops vector pattern system
    def Stop(self):
        return self.set_register('run', 0)

    ## Gets the running status of vector pattern system
    def GetRunningStatus(self):
        return self.get_register('run')

    ## Sets the index of first desired point in Vector Pattern Memory (start of transition triggered by rising edge of
    # external signal if External trigger configured)
    def SetStart(self, value):
        return self.set_register('start', value)

    ## Gets the index of first desired point in Vector Pattern Memory (start of transition triggered by rising edge of
    # external signal if External trigger configured)
    def GetStart(self):
        return self.get_register('start')

    ## Sets the Index after last desired point in Vector Pattern Memory (end of transition triggered by rising edge of
    # external signal if External trigger configured)
    def SetEnd(self, value):
        return self.set_register('end', value)

    ## Gets the Index after last desired point in Vector Pattern Memory (end of transition triggered by rising edge of
    # external signal if External trigger configured)
    def GetEnd(self):
        return self.get_register('end')

    ## Sets the sample rate at which the Vector Pattern unit samples the vector in the Vector Pattern Memory
    def SetFreqSampleSpeed(self, value):
        return self.set_register('frequency_speed', value)

    ## Gets the sample rate at which the Vector Pattern unit samples the vector in the Vector Pattern Memory
    def GetFreqSampleSpeed(self):
        return self.get_register('frequency_speed')

    ## Gets the minimum supported sample rate
    def GetMinFreqSampleSpeed(self):
        return self.get_register('min_speed')

    ## Gets the maximum supported sample rate
    def GetMaxFreqSampleSpeed(self):
        return self.get_register('max_speed')

    ## Sets the number of cycles to be generated. Run flag is turned off after completion. Negative value corresponds
    # to infinite looping
    def SetCycles(self, value):
        return self.set_register('cycles', value)

    ## Gets the number of cycles to be generated. Run flag is turned off after completion. Negative value corresponds
    # to infinite looping
    def GetCycles(self):
        return self.get_register('cycles')

    ## Sets external trigger mode. Vector Pattern Unit can be synchronised with external signal
    # (0=disabled, 1=rising/falling edge, 2=rising edge trigger)
    def SetExternalTrigger(self, value):
        if type(value) == bool:
            value = int(value)
        return self.set_register('external_trigger', value)

    ## Get output of the vector pattern unit
    def GetOutput(self):
        return self.get_register('output')

    ## Sets the index of first desired point in Vector Pattern Memory (start of second part of transition triggered by
    # falling edge of external signal)
    def SetStart2(self, value):
        return self.set_register('start2', value)

    ## Gets the index of first desired point in Vector Pattern Memory (start of second part of transition triggered by
    # falling edge of external signal)
    def GetStart2(self):
        return self.get_register('start2')

    ## Sets the index after last desired point in Vector Pattern Memory (end of second part of transition triggered by
    # falling edge of external signal)
    def SetEnd2(self, value):
        return self.set_register('end2', value)

    ## Gets the index after last desired point in Vector Pattern Memory (end of second part of transition triggered by
    # falling edge of external signal)
    def GetEnd2(self):
        return self.get_register('end2')

    ## Turns GPIOx pin to trigger input source (GPIOx default is trigger output) and disables global external trigger
    # SYNCx pin. 0 = off, 1 = on
    def SetExtTriggerGPIO(self, value):
        return self.set_register('ext_trigger_gpio', value)

    ## Gets the state of the GPIOx pin to trigger input source (GPIOx default is trigger output) and disables global
    # external trigger SYNCx pin. 0 = off, 1 = on
    def GetExtTriggerGPIO(self):
        return self.get_register('ext_trigger_gpio')

    ## Gets actual index
    def GetIndex(self):
        return self.get_register('index')

    ## Sets the divider for external trigger signal (downsampling)
    # 1 = no division; 2 = divide by 2 ...
    def SetTriggerDivider(self, value):
        return self.set_register('trigger_divider', value)

    ## Gets the divider value for external trigger signal (downsampling)
    # 1 = no division; 2 = divide by 2 ...
    def GetTriggerDivider(self):
        return self.get_register('trigger_divider')

    ## Sets the offset of external trigger signal for synchronisation adjustment
    # Offset can be in range 0 - (divider - 1) => important to set divider value first
    def SetTriggerOffset(self, value):
        return self.set_register('trigger_offset', value)

    ## Gets the offset of external trigger signal for synchronisation adjustment
    # Offset can be in range 0 - (divider - 1)
    def GetTriggerOffset(self):
        return self.get_register('trigger_offset')


class QuadrantVectorPatternUnit(InputStage):
    r"""

 * Quadrant vector pattern system ID base: 0x80
 *
 * | Address | Name                    | Default | Description                                                                              | Format and value |
 * | ------- | ----------------------- | ------- | ---------------------------------------------------------------------------------------- | ---------------- |
 * | 0       | unit type               | 0       | see ChannelValue                                                                         | uint32           |
 * | 1       | run                     | false   | turn system on and off                                                                   | boolean          |
 * | 2       | quadrant vector 1 start | 0       | index in Vector Pattern Memory of first point of vector to move to quadrant position 1   | uint32           |
 * | 3       | quadrant vector 1 end   | 0       | index in Vector Pattern Memory after last point of vector to move to quadrant position 1 | uint32           |
 * | 4       | quadrant vector 2 start | 0       | index in Vector Pattern Memory of first point of vector to move to quadrant position 2   | uint32           |
 * | 5       | quadrant vector 2 end   | 0       | index in Vector Pattern Memory after last point of vector to move to quadrant position 2 | uint32           |
 * | 6       | quadrant vector 3 start | 0       | index in Vector Pattern Memory of first point of vector to move to quadrant position 3   | uint32           |
 * | 7       | quadrant vector 3 end   | 0       | index in Vector Pattern Memory after last point of vector to move to quadrant position 3 | uint32           |
 * | 8       | quadrant vector 4 start | 0       | index in Vector Pattern Memory of first point of vector to move to quadrant position 4   | uint32           |
 * | 9       | quadrant vector 4 end   | 0       | index in Vector Pattern Memory after last point of vector to move to quadrant position 4 | uint32           |
 */

    """

    @staticmethod
    def help():
        print(QuadrantVectorPatternUnit.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x80 | channel

        self.unit = {'id': self.sys_id << 8 | 0x00,
                     'type': int,
                     'unit': None,
                     'range': {0: 'Current', 1: 'OF', 2: 'XY'},
                     'default': 1,
                     'value': 1}
        self.run = {'id': self.sys_id << 8 | 0x01,
                    'type': bool,
                    'unit': None,
                    'range': [True, False],
                    'default': False,
                    'value': False}
        self.startQ1 = {'id': self.sys_id << 8 | 0x02,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': 0,
                        'value': 0}
        self.endQ1 = {'id': self.sys_id << 8 | 0x03,
                      'type': int,
                      'unit': None,
                      'range': None,
                      'default': 0,
                      'value': 0}
        self.startQ2 = {'id': self.sys_id << 8 | 0x04,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': 0,
                        'value': 0}
        self.endQ2 = {'id': self.sys_id << 8 | 0x05,
                      'type': int,
                      'unit': None,
                      'range': None,
                      'default': 0,
                      'value': 0}
        self.startQ3 = {'id': self.sys_id << 8 | 0x06,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': 0,
                        'value': 0}
        self.endQ3 = {'id': self.sys_id << 8 | 0x07,
                      'type': int,
                      'unit': None,
                      'range': None,
                      'default': 0,
                      'value': 0}
        self.startQ4 = {'id': self.sys_id << 8 | 0x08,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': 0,
                        'value': 0}
        self.endQ4 = {'id': self.sys_id << 8 | 0x09,
                      'type': int,
                      'unit': None,
                      'range': None,
                      'default': 0,
                      'value': 0}

        InputStage.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    def SetUnit(self, value):
        return self.set_register('unit', value)

    def GetUnit(self):
        return self.get_register('unit')

    def Run(self):
        return self.set_register('run', 1)

    def Stop(self):
        return self.set_register('run', 0)

    def GetRunningStatus(self):
        return self.get_register('run')

    def SetStartQ1(self, value):
        return self.set_register('startQ1', value)

    def GetStartQ1(self):
        return self.get_register('startQ1')

    def SetEndQ1(self, value):
        return self.set_register('endQ1', value)

    def GetEndQ1(self):
        return self.get_register('endQ1')

    def SetStartQ2(self, value):
        return self.set_register('startQ2', value)

    def GetStartQ2(self):
        return self.get_register('startQ2')

    def SetEndQ2(self, value):
        return self.set_register('endQ2', value)

    def GetEndQ2(self):
        return self.get_register('endQ2')

    def SetStartQ3(self, value):
        return self.set_register('startQ3', value)

    def GetStartQ3(self):
        return self.get_register('startQ3')

    def SetEndQ3(self, value):
        return self.set_register('endQ3', value)

    def GetEndQ3(self):
        return self.get_register('endQ3')

    def SetStartQ4(self, value):
        return self.set_register('startQ4', value)

    def GetStartQ4(self):
        return self.get_register('startQ4')

    def SetEndQ4(self, value):
        return self.set_register('endQ4', value)

    def GetEndQ4(self):
        return self.get_register('endQ4')


class RasterScan(InputStage):
    r"""
Input Channel Systems - Raster Scan
System ID: 0x70 through 0x77

+------------------+------+-------------+---------+--------------+---------+--------------------------------+
| Register Name    | Id   | Type        | Unit    | Range        | Default | Comment                        |
+==================+======+=============+=========+==============+=========+================================+
| run              | 0x01 | uint 32-bit | bool    | True / False | 0       |                                |
+------------------+------+-------------+---------+--------------+---------+--------------------------------+
|number_of_lines   | 0x02 | uint 32-bit | None    |              |         |                                |
+------------------+------+-------------+---------+--------------+---------+--------------------------------+
|slow_axis_range   | 0x03 | float 32-bit| Degrees |              |         |                                |
+------------------+------+-------------+---------+--------------+---------+--------------------------------+
|fast_axis_range   | 0x04 | float 32-bit| Degrees |              |         |                                |
+------------------+------+-------------+---------+--------------+---------+--------------------------------+
|orientation       | 0x05 | uint 32-bit | None    | [0, 1]       | 0       | 0 – horizontal, 1 – vertical   |
+------------------+------+-------------+---------+--------------+---------+--------------------------------+
|frequency         | 0x06 | float 32-bit| Hz      |              |         |                                |
+------------------+------+-------------+---------+--------------+---------+--------------------------------+

    """

    # TODO: Not implemented yet in firmware
    @staticmethod
    def help():
        print(RasterScan.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x70 | channel
        self._readonly = False

        self.unit = {'id': self.sys_id << 8 | 0x00,
                     'type': int,
                     'unit': None,
                     'range': {0: 'Current', 1: 'OF', 2: 'XY'},
                     'default': 1,
                     'value': 1}
        self.run = {'id': self.sys_id << 8 | 0x01,
                    'type': bool,
                    'unit': None,
                    'range': [True, False],
                    'default': 0,
                    'value': 0.0}
        self.number_of_lines = {'id': self.sys_id << 8 | 0x02,
                                'type': int,
                                'unit': None,
                                'range': [0, 2],
                                'default': 0,
                                'value': 0.0}
        self.slow_axis_range = {'id': self.sys_id << 8 | 0x03,
                                'type': float,
                                'unit': 'Degree',
                                'range': [0, 2],
                                'default': 0,
                                'value': 0.0}
        self.fast_axis_range = {'id': self.sys_id << 8 | 0x04,
                                'type': float,
                                'unit': 'Degree',
                                'range': [0, 2],
                                'default': 0,
                                'value': 0.0}
        self.orientation = {'id': self.sys_id << 8 | 0x05,
                            'type': bool,
                            'unit': None,
                            'range': {0: 'Horizontal', 1: 'Vertical'},
                            'default': 0,
                            'value': 0.0}
        self.frequency = {'id': self.sys_id << 8 | 0x06,
                          'type': float,
                          'unit': 'Hz',
                          'range': None,
                          'default': 0,
                          'value': 0.0}
        InputStage.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')


class FlowerPattern(InputStage):
    r"""
Input Channel Systems - Flower Pattern
System ID: 0x78 through 0x7f

+----------------+------+-------------+--------------------+-------------+---------+------------------------+
| Register Name  | Id   | Type        | Unit               | Range       | Default | Comment                |
+================+======+=============+====================+=============+=========+========================+


    """

    # TODO: Not implemented yet in firmware
    @staticmethod
    def help():
        print(FlowerPattern.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x70 | channel
        self._readonly = False

        self.PLACEHOLDER = {'id': self.sys_id << 8 | 0x00,
                            'type': float,
                            'unit': 'Hz',
                            'range': None,
                            'default': 0,
                            'value': 0}
        self.unit = {'id': self.sys_id << 8 | 0x00,
                     'type': int,
                     'unit': None,
                     'range': {0: 'Current', 1: 'OF', 2: 'XY'},
                     'default': 1,
                     'value': 1}
        InputStage.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')


class FeedbackSystem(ABC):

    def __init__(self):
        self.n_sensors = 1  # define the number channels

    @abstractmethod
    def init(self):  # in case feedback system needs to be initialized
        pass

    @abstractmethod
    def is_init_done(self):
        pass

    @abstractmethod
    def get_value(self, channel):  # get sensor value
        pass

    @abstractmethod
    def get_value_id(self, channel):  # get id of the sensor value register which may be used for the logger
        pass


class ENCInput(InputStage, FeedbackSystem):

    @staticmethod
    def help():
        print(StaticInput.__doc__)

    def __init__(self, board=None):
        self.sys_id = 0x34
        self._readonly = False

        self.counter = {'id': self.sys_id << 8 | 0x00,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': 0,
                        'value': 0}

        self.maxerror = {'id': self.sys_id << 8 | 0x01,
                         'type': int,
                         'unit': None,
                         'range': None,
                         'default': 0,
                         'value': 0}

        self.autoreset_z = {'id': self.sys_id << 8 | 0x02,
                            'type': int,
                            'unit': None,
                            'range': None,
                            'default': 0,
                            'value': 0}
        self.value = {'id': self.sys_id << 8 | 0x03,
                      'type': float,
                      'unit': None,
                      'range': None,
                      'default': 0.0,
                      'value': 0.0}
        self.zcount = {'id': self.sys_id << 8 | 0x04,
                       'type': int,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.lasterror = {'id': self.sys_id << 8 | 0x05,
                          'type': int,
                          'unit': None,
                          'range': None,
                          'default': 0.0,
                          'value': 0.0}

        self.n_sensors = 1

        InputStage.__init__(self, board=board)
        self.name = self.__class__.__name__

    def SetCounter(self, value):
        return self.set_register('counter', value)

    def GetCounter(self):
        return self.get_register('counter')

    def SetMaxerror(self, value):
        return self.set_register('maxerror', value)

    def GetMaxerror(self):
        return self.get_register('maxerror')

    def SetAutoResetZ(self, value):
        return self.set_register('autoreset_z', value)

    def GetAutoResetZ(self):
        return self.get_register('autoreset_z')

    def GetZCount(self):
        return self.get_register('zcount')

    def SetZCount(self, value):
        return self.set_register('zcount', value)

    def SetValue(self, value):
        return self.set_register('value', value)

    def GetValue(self):
        return self.get_register('value')

    def get_value(self, channel):
        return self.get_register('value')

    def get_value_id(self, channel):
        if channel == 0:
            return self.value['id']

    def init(self):
        self.SetCounter(0)
        return self.is_init_done()

    def is_init_done(self):
        return True


class PreciSenInput(InputStage, FeedbackSystem):

    @staticmethod
    def help():
        print(StaticInput.__doc__)

    def __init__(self, board=None):
        self.sys_id = 0x36
        self._readonly = False

        self.timestamp = {'id': self.sys_id << 8 | 0x00,
                          'type': int,
                          'unit': None,
                          'range': None,
                          'default': 0,
                          'value': 0}

        self.preciX = {'id': self.sys_id << 8 | 0x01,
                       'type': float,
                       'unit': None,
                       'range': None,
                       'default': 0,
                       'value': 0}

        self.preciY = {'id': self.sys_id << 8 | 0x02,
                       'type': float,
                       'unit': None,
                       'range': None,
                       'default': 0,
                       'value': 0}
        self.preciZ = {'id': self.sys_id << 8 | 0x03,
                       'type': float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.preciCRC = {'id': self.sys_id << 8 | 0x04,
                         'type': int,
                         'unit': None,
                         'range': None,
                         'default': 0.0,
                         'value': 0.0}

        self.n_sensors = 2

        InputStage.__init__(self, board=board)
        self.name = self.__class__.__name__

    def GetX(self):
        return self.get_register('preciX')

    def GetY(self):
        return self.get_register('preciY')

    def GetZ(self):
        return self.get_register('preciZ')

    def GetCRC(self):
        return self.get_register('preciCRC')

    def get_value(self, channel):
        if channel == 0:
            return self.get_register('preciX')
        elif channel == 1:
            return self.get_register('preciY')
        elif channel == 2:
            return self.get_register('preciZ')

    def get_value_id(self, channel):
        if channel == 0:
            return self.preciX['id']
        elif channel == 1:
            return self.preciY['id']
        elif channel == 2:
            return self.preciZ['id']

    def init(self):
        return self.is_init_done()

    def is_init_done(self):
        return True


class AnalogFeedback(FeedbackSystem):

    def __init__(self, analog_systems: List[Analog]):
        FeedbackSystem.__init__(self)
        self._readonly = False
        self.analog_systems = analog_systems
        self.n_sensors = 4

    def get_value(self, channel):
        return self.analog_systems[channel].get_register('norm_value')

    def get_value_id(self, channel):
        return self.analog_systems[channel].norm_value['id']

    def init(self):
        return self.is_init_done()

    def is_init_done(self):
        return True

class SignalFlowFeedback(FeedbackSystem):

    def __init__(self, sfm: SignalFlowManager):
        FeedbackSystem.__init__(self)
        self._readonly = False
        self.n_sensors = 4
        self.sfm = sfm

    def get_value(self, channel):

        return self.sfm.GetStageOutput(EnSignalFlowPath.FEED_BACK, 0, channel)

    def get_value_id(self, channel):
        return self.sfm.GetStageOutputRegisterID(EnSignalFlowPath.FEED_BACK, 0, channel)

    def init(self):
        return self.is_init_done()

    def is_init_done(self):
        return True

