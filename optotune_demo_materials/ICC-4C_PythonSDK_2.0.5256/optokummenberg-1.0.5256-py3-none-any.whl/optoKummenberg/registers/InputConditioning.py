from .ClassAbstracts import System
from ..tools.systems_registers_tools import is_valid_channel
from ..tools.definitions import CHUNK_SIZE


class InputConditioning(System):
    r"""
Input Conditioning Channel - Offset and Scaling
System ID: 0x98 through 0x9f

+----------------+------+-------------+--------------------+-------------+---------+------------------------+
| Register Name  | Id   | Type        | Unit               | Range       | Default | Comment                |
+================+======+=============+====================+=============+=========+========================+
| gain           | 0x00 | float 32-bit|                    |             | 1.0     |                        |
+----------------+------+-------------+--------------------+-------------+---------+------------------------+
| offset         | 0x01 | float 32-bit|                    |             | 0.0     |                        |
+----------------+------+-------------+--------------------+-------------+---------+------------------------+

    """

    @staticmethod
    def help():
        print(InputConditioning.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x98 | channel
        self._readonly = False

        self.gain = {'id': self.sys_id << 8 | 0x00,
                     'type': float,
                     'unit': None,
                     'range': None,
                     'default': 1,
                     'value': 1}

        self.offset = {'id': self.sys_id << 8 | 0x01,
                       'type': float,
                       'unit': None,
                       'range': None,
                       'default': 0,
                       'value': 0}

        self.transition_rate = {'id': self.sys_id << 8 | 0x02,
                       'type': float,
                       'unit': None,
                       'range': None,
                       'default': 0,
                       'value': 0}

        self.limit_low = {'id': self.sys_id << 8 | 0x03,
                                  'type': float,
                                  'unit': None,
                                  'range': None,
                                  'default': 0,
                                  'value': 0}

        self.limit_high = {'id': self.sys_id << 8 | 0x04,
                                  'type': float,
                                  'unit': None,
                                  'range': None,
                                  'default': 0,
                                  'value': 0}

        self.limit_enable = {'id': self.sys_id << 8 | 0x05,
                                  'type': bool,
                                  'unit': None,
                                  'range': None,
                                  'default': 0,
                                  'value': 0}

        System.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    def SetGain(self, value):
        return self.set_register('gain', value)

    def SetOffset(self, value):
        return self.set_register('offset', value)

    def GetGain(self):
        return self.get_register('gain')

    def GetOffset(self):
        return self.get_register('offset')

    def SetTransitionRate(self, value):
        return self.set_register('transition_rate', value)

    def GetTransitionRate(self):
        return self.get_register('transition_rate')

    def SetLowLimit(self, value=0):
        self.set_register('limit_low', value)

    def GetLowLimit(self):
        return self.get_register('limit_low')

    def SetHighLimit(self, value=0):
        self.set_register('limit_high', value)

    def GetHighLimit(self):
        return self.get_register('limit_high')

    def EnableLimiting(self):
        self.set_register('limit_enable', 1)

    def DisableLimiting(self):
        self.set_register('limit_enable', 0)

    def GetLimitEnableState(self):
        return self.get_register('limit_enable')


class InputConditioningFilter(System):
    r"""
Output Conditioning Channel - Offset and Scaling
System ID: 0x9C through 0x9F

+---------------------+------+-------------+--------------------+-------------+---------+------------------------+
| Register Name       | Id   | Type        | Unit               | Range       | Default | Comment                |
+=====================+======+=============+====================+=============+=========+========================+
|                     |      |             |                    |             |         |                        |
+---------------------+------+-------------+--------------------+-------------+---------+------------------------+
    """

    @staticmethod
    def help():
        print(InputConditioningFilter.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x9C | channel
        self._readonly = False

        self.mskActiveFilters = {'id': self.sys_id << 8 | 0x00,
                     'type': int,
                     'unit': None,
                     'range': [0, 15],
                     'default': 1,
                     'value': 1}
        self.selectFilterInstance = {'id': self.sys_id << 8 | 0x01,
                       'type': int,
                       'unit': None,
                       'range': [0, 3],
                       'default': 0,
                       'value': 0}
        self.loadFilterCoeff = {'id': self.sys_id << 8 | 0x02,
                       'type':int,
                       'unit': None,
                       'range': [0, 1],
                       'default': 0,
                       'value': 0}
        self.getInCoeffNbr = {'id': self.sys_id << 8 | 0x03,
                       'type':int,
                       'unit': None,
                       'range': [0, 100],
                       'default': 0,
                       'value': 0}
        self.getOutCoeffNbr = {'id': self.sys_id << 8 | 0x04,
                       'type':int,
                       'unit': None,
                       'range': [0, 100],
                       'default': 0,
                       'value': 0}
        self.inputValue = {'id': self.sys_id << 8 | 0x10,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.outputValue = {'id': self.sys_id << 8 | 0x20,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.outputValueF0 = {'id': self.sys_id << 8 | 0x21,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.outputValueF1 = {'id': self.sys_id << 8 | 0x22,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.outputValueF2 = {'id': self.sys_id << 8 | 0x23,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.outputValueF3 = {'id': self.sys_id << 8 | 0x24,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}

        self.vectInputCoeff = {'id': self.sys_id << 8 | 0x00,
                               'type': float}

        self.vectOutputCoeff = {'id': self.sys_id << 8 | 0x01,
                               'type': float}

        System.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    def SetActiveFiltersMask(self, value):
        return self.set_register('mskActiveFilters', value)

    def GetActiveFiltersMask(self, value = 0):
        return self.get_register('mskActiveFilters')

    def SelectFilterInstance(self, value):
        return self.set_register('selectFilterInstance', value)

    def LoadFilterCoeff(self, value):
        return self.set_register('loadFilterCoeff', value)

    def GetFilterInputCoeffNum(self):
        return self.get_register('getInCoeffNbr')

    def GetFilterOutputCoeffNum(self):
        return self.get_register('getOutCoeffNbr')

    def GetFilterInput(self):
        return self.get_register('inputValue')

    def GetFilterOutput(self):
        return self.get_register('outputValue')

    def GetOutputValueID(self, instance_number):
        if instance_number == 0:
            return self.outputValueF0['id']
        elif instance_number == 1:
            return self.outputValueF1['id']
        elif instance_number == 2:
            return self.outputValueF2['id']
        elif instance_number == 3:
            return self.outputValueF3['id']

    def SetInputCoeffs(self, index, vector):
        iters = len(vector) // CHUNK_SIZE
        remainder = len(vector) % CHUNK_SIZE
        # split vector to data packets
        for i in range(iters):
            aux = vector[i * CHUNK_SIZE: (i+1) * CHUNK_SIZE]
            result = self._board.set_vector(self.vectInputCoeff, index + i * CHUNK_SIZE, aux)
        if remainder:
            aux = vector[iters * CHUNK_SIZE: len(vector)]
            result = self._board.set_vector(self.vectInputCoeff, index + iters * CHUNK_SIZE, aux)
        return result

    def SetOutputCoeffs(self, index, vector):
        iters = len(vector) // CHUNK_SIZE
        remainder = len(vector) % CHUNK_SIZE
        # split vector to data packets
        for i in range(iters):
            aux = vector[i * CHUNK_SIZE: (i+1) * CHUNK_SIZE]
            result = self._board.set_vector(self.vectOutputCoeff, index + i * CHUNK_SIZE, aux)
        if remainder:
            aux = vector[iters * CHUNK_SIZE: len(vector)]
            result = self._board.set_vector(self.vectOutputCoeff, index + iters * CHUNK_SIZE, aux)
        return result

    def GetInputCoeffs(self, index, count):
        vec = []
        # end_index = index + count
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            aux = self._board.get_vector(self.vectInputCoeff, i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)
        if remainder:
            aux = self._board.get_vector(self.vectInputCoeff, iters * CHUNK_SIZE, remainder)
            vec.extend(aux)
        return vec


    def GetOutputCoeffs(self, index, count):
        vec = []
        # end_index = index + count
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            aux = self._board.get_vector(self.vectOutputCoeff, i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)
        if remainder:
            aux = self._board.get_vector(self.vectOutputCoeff, iters * CHUNK_SIZE, remainder)
            vec.extend(aux)
        return vec
