from .ClassAbstracts import System
from ..tools.definitions import *
#from ..tools.definitions import CHUNK_SIZE, UnitType
from ..tools.systems_registers_tools import get_registers
from warnings import warn
import struct


class Logger(System):
    """
Device Functionality - Logger
System ID: 0x24

A system for logging the values of various readable registers.

Register Map:
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Register Name             | Id   | Type        | Unit | Range | Default | Comment                                   |
+===========================+======+=============+======+=======+=========+===========================================+
| logged_register_0         | 0x00 | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_1         | 0x01 | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_2         | 0x02 | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_3         | 0x03 | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_4         | 0x04 | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_5         | 0x05 | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_6         | 0x06 | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_7         | 0x07 | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_8         | 0x08 | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_9         | 0x09 | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_10        | 0x0A | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| logged_register_11        | 0x0B | uint 32-bit |None  |       |         | Address of register to log                |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| run                       | 0x10 | boolean     |None  |       | false   | Set true to start logging, will be set to |
|                           |      |             |      |       |         | false after the memory is filled          |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| sampling_frequency        | 0x11 | float 32-bit|Hz    |       | 20000   | Sampling rate in Hz which the logger logs |
|                           |      |                    |       |         | values.                                   |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Minimum sampling rate     | 0x12 | float 32-bit|Hz    |       | $ \frac{20000}{2^{32}-1} $ |                        |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Maximum sampling rate     | 0x13 | float 32-bit|Hz    |       | 20000   |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Trigger register address  | 0x14 | uint 16-bit|None   |       | 0xE802  | Address of register that is monitored
for
triggering the logger |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Logger trigger mode       | 0x15 | uint 32-bit |None  |       | 0       | Configures trigger mode: <br/> 0 -
Non-triggered mode, <br/> 1 - Equal mode, <br/> 2 - Rising edge mode, <br/> 3 - Falling edge mode /
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Logger trigger value      | 0x16 | float/uint32/int32 |None  |       | 0       | Threshold value for logger triggering. Type depends on logger trigger value format|
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Logger trigger format     | 0x17 | uint 32-bit |None  |       | 0       | Defines format of logger trigger value:  <br/> 0 - uint32, <br/> 1 - int32, <br/> 2 - float|
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+


Vector Map:
+------------------------+------+--------------------+-------------------------------------------+
| Register Name          | Id   | Type               | Comment                                   |
+========================+======+====================+===========================================+
| Register log 0         | 0x00 | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+-------------------------------------------+
| Register log 1         | 0x01 | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+-----------------------------+
| Register log 2         | 0x02 | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+----------------------------+
| Register log 3         | 0x03 | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+----------------------------+
| Register log 4         | 0x04 | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+----------------------------+
| Register log 5         | 0x05 | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+----------------------------+
| Register log 6         | 0x06 | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+----------------------------+
| Register log 7         | 0x07 | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+----------------------------+
| Register log 8         | 0x08 | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+----------------------------+
| Register log 9         | 0x09 | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+----------------------------+
| Register log 10        | 0x0A | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+----------------------------+
| Register log 11        | 0x0B | uint 32-bit [5000] | Logged values for corresponding register  |
+---------------------------+------+-----------------+------+-------+----------------------------+
    """

    def __init__(self, board=None):

        self.sys_id = 0x24
        self._readonly = False
        # todo: add range via sys_id standards
        self.logged_register_0 = {'id': self.sys_id << 8 | 0x00, 'type': int, 'unit': None, 'range': None, 'default': 0xe802}
        self.logged_register_1 = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None, 'range': None, 'default': 0xe902}
        self.logged_register_2 = {'id': self.sys_id << 8 | 0x02, 'type': int, 'unit': None, 'range': None, 'default': 0x2300}
        self.logged_register_3 = {'id': self.sys_id << 8 | 0x03, 'type': int, 'unit': None, 'range': None, 'default': 0x2301}
        self.logged_register_4 = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None, 'range': None, 'default': 0x2302}
        self.logged_register_5 = {'id': self.sys_id << 8 | 0x05, 'type': int, 'unit': None, 'range': None, 'default': 0x2303}
        self.logged_register_6 = {'id': self.sys_id << 8 | 0x06, 'type': int, 'unit': None, 'range': None, 'default': 0xe802}
        self.logged_register_7 = {'id': self.sys_id << 8 | 0x07, 'type': int, 'unit': None, 'range': None, 'default': 0xe902}
        self.logged_register_8 = {'id': self.sys_id << 8 | 0x08, 'type': int, 'unit': None, 'range': None, 'default': 0x2300}
        self.logged_register_9 = {'id': self.sys_id << 8 | 0x09, 'type': int, 'unit': None, 'range': None, 'default': 0x2301}
        self.logged_register_10 = {'id': self.sys_id << 8 | 0x0a, 'type': int, 'unit': None, 'range': None, 'default': 0x2302}
        self.logged_register_11 = {'id': self.sys_id << 8 | 0x0b, 'type': int, 'unit': None, 'range': None, 'default': 0x2303}

        self.run = {'id': self.sys_id << 8 | 0x10, 'type': int, 'unit': bool, 'range': [0, 1], 'default': False}
        self.sampling_frequency = {'id': self.sys_id << 8 | 0x11, 'type': float, 'unit': 'Hz', 'range': None, 'default': 20000}

        self.log_trigger_reg = {'id': self.sys_id << 8 | 0x14, 'type': int, 'unit': None, 'range': None, 'default': 0}
        self.log_trigger_mode = {'id': self.sys_id << 8 | 0x15, 'type': int, 'unit': None, 'range': None, 'default': 0}
        self.log_trigger_value = {'id': self.sys_id << 8 | 0x16, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.log_trigger_format = {'id': self.sys_id << 8 | 0x17, 'type': int, 'unit': None, 'range': None, 'default': 0}

        self.register_log_0 = {'id': self.sys_id << 8 | 0x00, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_1 = {'id': self.sys_id << 8 | 0x01, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_2 = {'id': self.sys_id << 8 | 0x02, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_3 = {'id': self.sys_id << 8 | 0x03, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_4 = {'id': self.sys_id << 8 | 0x04, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_5 = {'id': self.sys_id << 8 | 0x05, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_6 = {'id': self.sys_id << 8 | 0x06, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_7 = {'id': self.sys_id << 8 | 0x07, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_8 = {'id': self.sys_id << 8 | 0x08, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_9 = {'id': self.sys_id << 8 | 0x09, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_10 = {'id': self.sys_id << 8 | 0x0a, 'type': float, 'unit': None, 'range': None, 'default': 0}
        self.register_log_11 = {'id': self.sys_id << 8 | 0x0b, 'type': float, 'unit': None, 'range': None, 'default': 0}

        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    ## Gets the register number logged into specific log number
    def GetLoggedRegister(self, log_number):
        return self.get_register('logged_register_{}'.format(log_number))

    ## Sets the register number logged into specific log number. The value of this register will be periodically logged
    # into memory in form of the vector, this vector can be then obtained by GetLog method.
    def SetLoggedRegister(self, log_number, value):
        # set new logged register
        set_response = self.set_register('logged_register_{}'.format(log_number), value)
        # collect register dictionary from new register
        newsys_id = value >> 8
        new_sys_registers = self._board.systems[newsys_id]['registers']
        # set logged register to new value internally
        new_reg = [new_sys_registers[item] for item in new_sys_registers if new_sys_registers[item]['id'] == value][0]
        self.__dict__['register_log_{}'.format(log_number)].update(new_reg)
        # set register log output type internally
        self.__dict__['register_log_{}'.format(log_number)].update({'type': new_reg['type']})
        return set_response

    ## Starts the logger
    def RunLogger(self):
        return self.set_register('run', 1)

    ## Stops the logger
    def StopLogger(self):
        return self.set_register('run', 0)

    ## Gets logged values in specific log. These values represents periodically logged register specified by
    # SetLoggedRegister method
    def GetLog(self, log_number, index, count):
        vec = []
        # end_index = index + count
        if count < CHUNK_SIZE:
            return self._GetLogSegment(log_number, index, count)
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            aux = self._GetLogSegment(log_number, i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)
        if remainder:
            aux = self._GetLogSegment(log_number, index + count - remainder, remainder)
            vec.extend(aux)
        return vec

    def _GetLogSegment(self, log_number, index, count):
        register = self.__dict__['register_log_{}'.format(log_number)]
        return self._board.get_vector(register, index, count)

    ## Gets the sampling frequency of the logger.
    def GetSamplingFrequency(self):
        return self.get_register('sampling_frequency')

    ## Sets the sampling frequency of the logger.
    def SetSamplingFrequency(self, value):
        return self.set_register('sampling_frequency', value)

    ## When logging an integer value this conversion needs to be used on the values obtained by GetLog.
    def to_int(self, float_v):
        return [struct.unpack('>i', struct.pack(">f", v))[0] for v in float_v]

    def SetTriggerReg(self, value):
        return self.set_register('log_trigger_reg', value)

    def GetTriggerReg(self):
        return self.get_register('log_trigger_reg')

    def SetTriggerMode(self, value):
        return self.set_register('log_trigger_mode', value)

    def GetTriggerMode(self):
        return self.get_register('log_trigger_mode')

    def SetTriggerValue(self, value):
        return self.set_register('log_trigger_value', value)

    def GetTriggerValue(self):
        return self.get_register('log_trigger_value')

    def SetTriggerFormat(self, value):
        return self.set_register('log_trigger_format', value)

    def GetTriggerFormat(self):
        return self.get_register('log_trigger_format')


class Manager(System):
    r"""
The Signal Flow Channel Manager is managing the active systems in the signal flow chain.
System ID for channel X: 0x40

+---------------------+---------------+-------------+----------+--------------+---------------+--------------------+
| Register Name       | Id            | Type        | Unit     | Range        | Default       | Comment            |
+=====================+===============+=============+==========+==============+===============+====================+
| input               | 5xCHANNEL + 0 | uint 32-bit | SystemID | 0x48 to 0x7f |               |                    |
+---------------------+---------------+-------------+----------+--------------+---------------+--------------------+
| input_conditioning  | 5xCHANNEL + 1 | uint 32-bit | SystemID | 0x48 to 0x7f |               |                    |
+---------------------+---------------+-------------+----------+--------------+---------------+--------------------+
| control             | 5xCHANNEL + 2 | uint 32-bit | SystemID | 0x48 to 0x7f |               |                    |
+---------------------+---------------+-------------+----------+--------------+---------------+--------------------+
| output_conditioning | 5xCHANNEL + 3 | uint 32-bit | SystemID | 0x48 to 0x7f |               |                    |
+---------------------+---------------+-------------+----------+--------------+---------------+--------------------+
| output              | 5*CHANNEL + 4 | uint 32-bit | SystemID | 0x48 to 0x7f |               |                    |
+---------------------+---------------+-------------+----------+--------------+---------------+--------------------+

    """

    @staticmethod
    def help():
        print(Manager.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0x40
        self._readonly = False

        # TODO: I could calculate valid range here from channel using bit math.
        self.input = {'id': self.sys_id << 8 | channel * 5 + 0x00,
                      'type': int,
                      'unit': 'SystemID',
                      'range': [0x48, 0x7f],
                      'default': None,
                      'value': None}
        self.input_conditioning = {'name': 'input_conditioning',
                                   'id': self.sys_id << 8 | channel * 5 + 0x01,
                                   'type': int,
                                   'unit': 'SystemID',
                                   'range': [0x48, 0x7f],
                                   'default': None,
                                   'value': None}
        self.control = {'name': 'control',
                        'id': self.sys_id << 8 | channel * 5 + 0x02,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': None,
                        'value': None}
        self.output_conditioning = {'name': 'output_conditioning',
                                    'id': self.sys_id << 8 | channel * 5 + 0x03,
                                    'type': int,
                                    'unit': 'SystemID',
                                    'range': [0x48, 0x7f],
                                    'default': None,
                                    'value': None}
        self.output = {'name': 'output',
                       'id': self.sys_id << 8 | channel * 5 + 0x04,
                       'type': int,
                       'unit': 'SystemID',
                       'range': [0x48, 0xef],
                       'default': None,
                       'value': None}

        System.__init__(self, channel, board)
        self.name = self.__class__.__name__

    def CheckSignalFlow(self):
        # pull input, input_conditioning, control, output_conditioning, and output registers
        input_id = self.get_register('input')
        icond_id = self.get_register('input_conditioning')
        cntrl_id = self.get_register('control')
        ocond_id = self.get_register('output_conditioning')
        outpt_id = self.get_register('output')
        # get input units
        if input_id in range(0x50, 0x60):
            # static input has no units register
            input_units = 'Static'
        else:
            inpt_units_register = get_registers(self._board.systems[input_id]['name'])['unit']
            input_units = UnitType(self._board.get_value(inpt_units_register)[0]).name

        # find corresponding system for input and mode for control
        if (cntrl_id != 0x35): # ResonantAmplitudeControl system
            flow_states = {'SignalFlowManager': {'name': self.name,
                                             'channel': self._channel},
                       'InputStage': {'name': self._board.systems[input_id]['name'],
                                      'channel': input_id & 0x0F % 8,
                                      'unit': input_units},
                       'InputConditioning': {'name': self._board.systems[icond_id]['name'],
                                             'channel': icond_id & 0x0F % 8},
                       'ControlStage': {'name': self._board.systems[cntrl_id]['name'],
                                        'channel': cntrl_id & 0x0F % 8},
                       'OutputConditioning': {'name': self._board.systems[ocond_id]['name'],
                                              'channel': ocond_id & 0x0F % 8},
                       'OutputStage': {'name': self._board.systems[outpt_id]['name'],
                                       'channel': outpt_id & 0x0F % 8},
                       }
        else:
            flow_states = {'SignalFlowManager': {'name': self.name,
                                             'channel': self._channel},
                       'InputStage': {'name': self._board.systems[input_id]['name'],
                                      'channel': input_id & 0x0F % 8,
                                      'unit': input_units},
                       'InputConditioning': {'name': self._board.systems[icond_id]['name'],
                                             'channel': icond_id & 0x0F % 8},
                       'ControlStage': {'name': self._board.systems[cntrl_id]['name'],
                                        'channel': input_id & 0x0F % 8},
                       'OutputConditioning': {'name': self._board.systems[ocond_id]['name'],
                                              'channel': ocond_id & 0x0F % 8},
                       'OutputStage': {'name': self._board.systems[outpt_id]['name'],
                                       'channel': outpt_id & 0x0F % 8},
                       }

        # warning if unit mismatch 'except static input'
        if not flow_states['InputStage']['unit'].lower() in flow_states['ControlStage']['name'].lower() \
                and input_id not in range(0x50, 0x70):
            warn("Input Units: {} Do Not Match Control Mode: {}".format(flow_states['InputStage']['unit'],
                                                                        flow_states['ControlStage']['name']),
                 RuntimeWarning)
        # warning if channel mismatch
        used_channels = [flow_states[item]['channel'] for item in flow_states]
        if not all([item == used_channels[0] for item in used_channels]):
            warn("Not all stages are set to the same channel.", RuntimeWarning)
        return flow_states


class Status(System):
    r"""
Device Functionality - Firmware Status
System ID: 0x10

+---------------------+------+-------------+---------+---------------------------------------+
| Register Name       | Id   | Type        | Default | Comment                               |
+=====================+======+=============+=========+=======================================+
| firmware_id         | 0x00 | float 32-bit|         |                                       |
+---------------------+------+-------------+---------+---------------------------------------+
| firmware_branch     | 0x01 | float 32-bit|         |                                       |
+---------------------+------+-------------+---------+---------------------------------------+
| fw_type             | 0x02 | float 32-bit|         |                                       |
+---------------------+------+-------------+---------+---------------------------------------+
| fw_version_major    | 0x03 | float 32-bit|         |                                       |
+---------------------+------+-------------+---------+---------------------------------------+
| fw_version_minor    | 0x04 | float 32-bit|         |                                       |
+---------------------+------+-------------+---------+---------------------------------------+
| fw_version_build    | 0x05 | float 32-bit|         |                                       |
+---------------------+------+-------------+---------+---------------------------------------+
| fw_version_revision | 0x06 | float 32-bit|         |                                       |
+---------------------+------+-------------+---------+---------------------------------------+
| error_flag_register | 0x07 | float 32-bit| 0       | See: Status Register Values Below     |
+---------------------+------+-------------+---------+---------------------------------------+
| proxy_fpga_version  | 0x08 | float 32-bit|         |                                       |
+---------------------+------+-------------+---------+---------------------------------------+
| cpu_fpga_version    | 0x09 | float 32-bit|         |                                       |
+---------------------+------+-------------+---------+---------------------------------------+

Status Register Values:

====== =================================================================
Bit#   Message
====== =================================================================
0      Proxy not connected
1      Proxy temperature threshold is reached. See TemperatureManager
2      Mirror temperature threshold is reached See TemperatureManager
3      Mirror EEPROM not valid
4      Mirror not stable. See stability criterion in OpticalFeedback
5      Linear output limit is reached. See LinearOutput
6      Linear output average limit is reached. See LinearOutput
7      XY input is trimmed. See InputConditioning
8      Proxy was disconnected
9      Proxy temperature threshold was reached
10     Mirror temperature threshold was reached
11     Linear output limit was reached
12     Linear output average limit was reached
13     XY input was trimmed
14..31 Reserved
====== =================================================================
    Write:
    Writing to this register resets all history error flags 8, 9, 10, 11, 12, 13
    """

    @staticmethod
    def help():
        print(Status.__doc__)

    _is_a_system = False

    def __init__(self, board=None):

        self.sys_id = 0x10

        self.firmware_id = {'id': self.sys_id << 8 | 0x00,
                            'type': int,
                            'unit': None,
                            'range': None,
                            'default': None,
                            'value': None}
        self.fw_branch = {'id': self.sys_id << 8 | 0x01,
                          'type': int,
                          'unit': None,
                          'range': None,
                          'default': None,
                          'value': None}
        self.fw_type = {'id': self.sys_id << 8 | 0x02,
                        'type': int,
                        'unit': None,
                        'range': None,
                        'default': None,
                        'value': None}
        self.fw_version_major = {'id': self.sys_id << 8 | 0x03,
                                 'type': int,
                                 'unit': None,
                                 'range': None,
                                 'default': None,
                                 'value': None}
        self.fw_version_minor = {'id': self.sys_id << 8 | 0x04,
                                 'type': int,
                                 'unit': None,
                                 'range': None,
                                 'default': None,
                                 'value': None}
        self.fw_version_build = {'id': self.sys_id << 8 | 0x05,
                                 'type': int,
                                 'unit': None,
                                 'range': None,
                                 'default': None,
                                 'value': None}
        self.fw_version_revision = {'id': self.sys_id << 8 | 0x06,
                                    'type': int,
                                    'unit': None,
                                    'range': None,
                                    'default': None,
                                    'value': None}
        self.error_flag_register = {'id': self.sys_id << 8 | 0x07,
                                    'type': int,
                                    'unit': None,
                                    'range': None,
                                    'default': None,
                                    'value': None}
        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    def GetFirmwareID(self):
        return self.get_register('firmware_id')

    def GetFirmwareBranch(self):
        return self.get_register('fw_branch')

    def GetFirmwareType(self):
        return self.get_register('fw_type')

    def GetFirmwareVersionMajor(self):
        return self.get_register('fw_version_major')

    def GetFirmwareVersionMinor(self):
        return self.get_register('fw_version_minor')

    def GetFirmwareBuild(self):
        return self.get_register('fw_version_build')

    def GetFirmwareVersionRevision(self):
        return self.get_register('fw_version_revision')

    def GetErrorFlagRegister(self):
        response = self.get_register('error_flag_register')
        if response is not None:
            error_flag_register = self.parse_error_flags(response)
            return error_flag_register
        else:
            return response

    def GetErrorFlagRegisterString(self):
        errors_parsed = self.GetErrorFlagRegister()
        return ", ".join([key for (key, value) in errors_parsed.items() if value == True], )

    def parse_error_flags(self, error_flag_data: int):
        return error_flag_data

    def ResetErrorFlagRegister(self):
        return self.set_register('error_flag_register', 0)

    def GetFirmwareSN(self, index, count):
        register = {'id': self.sys_id << 8, 'type': str}
        return self._board.get_vector(register, index, count)

    def SetFirmwareSN(self, index, vector):
        register = {'id': self.sys_id << 8, 'type': str}
        return self._board.set_vector(register, index, vector)

    def GetGitHEADSHA1Vector(self, index, count):
        register = {'id': self.sys_id << 8 | 0x01, 'type': str}
        return self._board.get_vector(register, index, count)


class BoardEEPROM(System):
    r"""
Device Functionality - BoardEEPROM Read/Write
System ID: 0x20

+--------------------+------+-----------------------------------------------------------------------------------------+
| Register Name      | Id   | Comment                                                                                 |
+====================+======+=========================================================================================+
| lock               | 0x00 | write the key to unlock, anything else to lock.Key value: 0x3f4744f6 (float 0.778396)   |
+--------------------+------+-----------------------------------------------------------------------------------------+


    """

    @staticmethod
    def help():
        print(BoardEEPROM.__doc__)

    _is_a_system = False

    def __init__(self, board=None):
        self.sys_id = 0x20
        self.lock = {'id': self.sys_id << 8 | 0x00, 'type': float, 'unit': None, 'range': None, 'default': 0.0,
                     'value': 0.778396}
        self.register = {'id': self.sys_id << 8, 'type': bytes}
        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    def _SetEEPROMSegment(self, index, vector):
        resp = self._board.set_vector(self.register, index, vector)
        return resp

    def _GetEEPROMSegment(self, index, count):
        return self._board.get_vector(self.register, index, count)

    def GetEEPROM(self, index, count):
        vec = bytearray([])
        end_index = index + count
        chunk_size_in_bytes = CHUNK_SIZE * 4
        for i in range(index, index + count, chunk_size_in_bytes):
            if i + chunk_size_in_bytes > end_index:
                aux = self._GetEEPROMSegment(i, count % chunk_size_in_bytes)
            else:
                aux = self._GetEEPROMSegment(i, chunk_size_in_bytes)
            vec.extend(bytes(aux[0]))

        return vec

    def SetEEPROM(self, index, vector):
        if (len(vector) % 32 == 0):
            chunk_size_in_bytes = 32
        else:
            chunk_size_in_bytes = CHUNK_SIZE * 4
        for i in range(0, len(vector), chunk_size_in_bytes):
            aux = vector[i:i + chunk_size_in_bytes]
            self._SetEEPROMSegment(i + index, aux)
        return vector

    ## Enables/Disables board EEPROM writing
    def EEPROMLockEnable(self, enable=True):
        if enable:
            return self.set_register('lock', 0.0)
        else:
            return self.set_register('lock', self.lock['value'])

    ## Compares stored board EEPROM with vector provided as parameter
    def VerifyEEPROM(self, index, vector):
        stored_eeprom = self.GetEEPROM(index, len(vector))
        return stored_eeprom == vector, stored_eeprom


class MRE2DeviceEEPROM(System):
    r"""
Device Functionality - DeviceEEPROM Read/Write
System ID: 0x21

+--------------------+------+-----------------------------------------------------------------------------------------+
| Register Name      | Id   | Comment                                                                                 |
+====================+======+=========================================================================================+
| lock               | 0x00 | write the key to unlock, anything else to lock.Key value: 0x3edeb7aa (float 0.434995)   |
+--------------------+------+-----------------------------------------------------------------------------------------+
    """

    @staticmethod
    def help():
        print(DeviceEEPROM.__doc__)

    _is_a_system = False

    def __init__(self, board=None):
        self.sys_id = 0x21
        self.lock = {'id': self.sys_id << 8 | 0x0a, 'type': float, 'unit': None, 'range': None, 'default': 0.0,
                     'value': 0.434995}
        self.reparse = {'id': self.sys_id << 8 | 0x0b, 'type': float, 'unit': None, 'range': None, 'default': 0.0,
                        'value': 0}
        self.register = {'id': self.sys_id << 8, 'type': bytes}
        System.__init__(self, board=board, channel=None)
        self.name = self.__class__.__name__

    def _SetEEPROMSegment(self, index, vector):
        resp = self._board.set_vector(self.register, index, vector)
        return resp

    def _GetEEPROMSegment(self, index, count):
        return self._board.get_vector(self.register, index, count)

    def GetEEPROM(self, index, count):
        vec = bytearray([])
        end_index = index + count
        chunk_size_in_bytes = CHUNK_SIZE * 4
        for i in range(index, index + count, chunk_size_in_bytes):
            if i + chunk_size_in_bytes > end_index:
                aux = self._GetEEPROMSegment(i, count % chunk_size_in_bytes)
            else:
                aux = self._GetEEPROMSegment(i, chunk_size_in_bytes)
            try:
                vec.extend(bytes(aux[0]))
                #vec += aux[0]
            except (IndexError, TypeError):
                return vec

        return vec

    def SetEEPROM(self, index, vector):
        chunk_size_in_bytes = CHUNK_SIZE * 4
        for i in range(0, len(vector), chunk_size_in_bytes):
            aux = vector[i:i + chunk_size_in_bytes]
            self._SetEEPROMSegment(i + index, aux)
        return vector

    def EEPROMLockEnable(self, enable=True):
        if enable:
            return self.set_register('lock', 0.0)
        else:
            return self.set_register('lock', self.lock['value'])

    def VerifyEEPROM(self, index, vector):
        stored_eeprom = self.GetEEPROM(index, len(vector))
        return stored_eeprom == vector, stored_eeprom

    def ReparseEEPROM(self):
        return self.get_register('reparse')


class DeviceEEPROM(System):
    r"""
Device Functionality - DeviceEEPROM Read/Write
System ID: 0x21

 * | Address | Name                           | Default Value | Description                                                       | Type   | Access    |
 * |---------|--------------------------------|---------------|-------------------------------------------------------------------|--------|-----------|
 * | 0x2100  | Device EEPROM lock             | 1 (locked)    | Write the key (0x3edeb7aa) to unlock, anything else to lock.      | uint32 | read write|
 * | 0x2101  | Device EEPROM version          | N/A           |                                                                   | uint16 | read only |
 * | 0x2102  | Device EEPROM subversion       | N/A           |                                                                   | uint8  | read only |
 * | 0x2103  | Part configuration             | N/A           |                                                                   | uint8  | read only |
 * | 0x2104  | Part configuration version     | N/A           |                                                                   | uint8  | read only |
 * | 0x2105  | Maximum positive current       | N/A           |                                                                   | uint16 | read only |
 * | 0x2106  | Maximum negative current       | N/A           |                                                                   | uint16 | read only |
 * | 0x2107  | OQC result                     | N/A           | Encoding: 0x00 = None, 0x01 = Pass, 0x02 = Fail                   | uint8  | read only |
 * | 0x2108  | Production Time-stamp          | N/A           | Unix Time format (seconds since 1.1.1970)                         | uint32 | read only |
 * | 0x2109  | Force device EEPROM re-parsing | N/A           | Read register to trigger. Automatic parsing of device EEPROM happens only at system start up | uint32 | read only |
 * | 0x210A  | Device EEPROM size             | N/A           |                                                                   | uint16 | read only |
 *
 *
 *
 * Vector map (vectors have their own address space):
 * Address | Name                  | Default  | Description      | Format and value | Access    |
 * --------|-----------------------|----------|------------------|------------------|-----------|
 * 0x2100  |Firmware SN            |          | bytes up to 0x7f | bytes            | read write|
 * 0x2101  |Device serial number   |          | 8 bytes SN       | ascii string     | read only |
 *
    """

    @staticmethod
    def help():
        print(DeviceEEPROM.__doc__)

    _is_a_system = False

    def __init__(self, channel: int = 0, board=None):
        self.channel = channel
        self.sys_id = 0x21
        self.lock = {'id': self.sys_id << 8 | 0x00, 'type': float, 'unit': None, 'range': None, 'default': 0.0,
                     'value': 0.434995}
        self.eeprom_version = {'id': self.sys_id << 8 | 0x01, 'type': int, 'unit': None, 'range': None, 'default':
            0.0, 'value': 0}
        self.eeprom_subversion = {'id': self.sys_id << 8 | 0x02, 'type': int, 'unit': None, 'range': None, 'default':
            0.0, 'value': 0}
        self.part_config = {'id': self.sys_id << 8 | 0x03, 'type': int, 'unit': None, 'range': None,
                            'default': 0, 'value': 0}
        self.part_config_version = {'id': self.sys_id << 8 | 0x04, 'type': int, 'unit': None, 'range': None,
                                    'default': 0, 'value': 0}
        self.max_pos_current = {'id': self.sys_id << 8 | 0x05, 'type': float, 'unit': None, 'range': None,
                                'default': 0.0, 'value': 0}
        self.max_neg_current = {'id': self.sys_id << 8 | 0x06, 'type': float, 'unit': None, 'range': None,
                                'default': 0.0, 'value': 0}
        self.oqc_result = {'id': self.sys_id << 8 | 0x07, 'type': int, 'unit': None, 'range': None,
                           'default': 0, 'value': 0}
        self.prod_time = {'id': self.sys_id << 8 | 0x08, 'type': int, 'unit': None, 'range': None,
                          'default': 0, 'value': 0}
        self.reparse = {'id': self.sys_id << 8 | 0x09, 'type': int, 'unit': None, 'range': None, 'default': 0.0,
                        'value': 0}
        self.eeprom_size = {'id': self.sys_id << 8 | 0x0a, 'type': int, 'unit': None, 'range': None, 'default': 0.0,
                            'value': 0}
        self.eeprom = {'id': self.sys_id << 8, 'type': bytes}
        self.serial_number = {'id': self.sys_id << 8 | 0x01, 'type': bytes}

        System.__init__(self, board=board)

    def _SetEEPROMSegment(self, index, vector):
        resp = self._board.set_vector(self.eeprom, index, vector)
        return resp

    def _GetEEPROMSegment(self, index, count):
        return self._board.get_vector(self.eeprom, index, count)

    ## Enables/disables EEPROM writing
    def EEPROMLockEnable(self, enable=True):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        if enable:
            return self.set_register('lock', 0.0)
        else:
            return self.set_register('lock', self.lock['value'])

    ## Gets the EEPROM data of the device connected to this channel
    def GetEEPROM(self, index, count):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        vec = bytearray([])
        end_index = index + count
        chunk_size_in_bytes = CHUNK_SIZE * 2
        for i in range(index, index + count, chunk_size_in_bytes):
            if i + chunk_size_in_bytes > end_index:
                aux = self._GetEEPROMSegment(i, count % chunk_size_in_bytes)
            else:
                aux = self._GetEEPROMSegment(i, chunk_size_in_bytes)
            try:
                vec.extend(bytes(aux[0]))
            except IndexError:
                return vec

        return vec

    ## Sets the EEPROM data of the device connected to this channel
    def SetEEPROM(self, index, vector):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        chunk_size_in_bytes = CHUNK_SIZE * 2
        for i in range(0, len(vector), chunk_size_in_bytes):
            aux = vector[i:i + chunk_size_in_bytes]
            self._SetEEPROMSegment(i + index, aux)
        return vector

    ## Compares stored EEPROM with vector provided as parameter
    def VerifyEEPROM(self, index, vector):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        stored_eeprom = self.GetEEPROM(index, len(vector))
        return stored_eeprom == vector, stored_eeprom

    ## After writing new EEPROM, configuration needs to be reparsed by this method
    def ReparseEEPROM(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('reparse')

    ## Gets the serial number of the device connected to this channel
    def GetSerialNumber(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self._board.get_vector(self.serial_number, 0, 8)[0]

    ## Gets the EEPROM version of the device connected to this channel
    def GetEEPROMversion(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('eeprom_version')

    ## Gets the EEPROM subversion of the device connected to this channel
    def GetEEPROMsubversion(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('eeprom_subversion')

    ## Gets the part configuration of the device connected to this channel
    def GetPartConfig(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('part_config')

    ## Gets the part configuration version of the device connected to this channel
    def GetPartConfigVersion(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('part_config_version')

    ## Gets the maximum positive current value (as absolute value) of the device connected to this channel
    def GetMaxPosCurrent(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('max_pos_current')

    ## Gets the maximum negative current value (as absolute value) of the device connected to this channel
    def GetMaxNegCurrent(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('max_neg_current')

    ## Gets the OQC result of the device connected to this channel
    def GetOQCresult(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('oqc_result')

    ## Gets the production timestamp of the device connected to this channel
    def GetProdTime(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('prod_time')

    ## Gets the size of the EEPROM (in bytes) of the device connected to this channel
    def GetEEPROMSize(self):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self.get_register('eeprom_size')

    def SetSerialNumber(self, serial):
        self._board.Status.SetDeviceEEPROMactiveChannel(self.channel)
        return self._board.set_vector(self.serial_number, 0, serial)

    def SetMaxPosCurrent(self, posCurrent):
        return self.set_register('max_pos_current', posCurrent)

    def SetMaxNegCurrent(self, negCurrent):
        return self.set_register('max_neg_current', negCurrent)


class VectorPatternMemory(System):
    """
Device Functionality - Vector Pattern Memory
System ID: 0x26

+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
| Register Name             | Id   | Type        | Unit | Range | Default | Comment                                   |
+===========================+======+=============+======+=======+=========+===========================================+
| proxy_valid               | 0x00 |float 32-bit |None  |       |         |                                           |
+---------------------------+------+-------------+------+-------+---------+-------------------------------------------+
    """
    def __init__(self, board=None):
        System.__init__(self, board=board)
        self.name = self.__class__.__name__

        self.sys_id = 0x26
        self._readonly = False

        self.proxy_valid = {'id': self.sys_id << 8 | 0x00,
                            'type': int,
                            'unit': None,
                            'range': [0, 1],
                            'default': False,
                            'value': False}
        self.vector = {'id': self.sys_id << 8, 'type': float}


    def SetPattern(self, index, vector):
        for i in range(0, len(vector), CHUNK_SIZE):
            aux = vector[i:i + CHUNK_SIZE]
            self.SetPatternSegment(i + index, aux)

    def GetPattern(self, index, count):
        vec = []
        # end_index = index + count
        if count < CHUNK_SIZE:
            return self.GetPatternSegment(index, count)
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            aux = self.GetPatternSegment(index + i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)
        if remainder:
            aux = self.GetPatternSegment(index + count - remainder, remainder)
            vec.extend(aux)
        return vec

    def SetPatternSegment(self, index, vector):
        return self._board.set_vector(self.vector, index, vector)

    def GetPatternSegment(self, index: int, count: int):
        response = self._board.get_vector(self.vector, index, count)
        # return list(struct.unpack('>'+'f'*count, response))
        return response

    def GetProxyValidity(self):
        return self.get_register('proxy_valid')

    def SaveVectorMemory(self):
        return self.set_register('proxy_valid', 0)

    # def MakeChangesPersistent(self):
    #     self._board.set_value(self.pattern_segment, 0)


class SnapshotManager(System):
    """
Device Functionality - Snapshot Manager
System ID: 0x27
 *
 * A system that supports saving and loading firmware configurations.
 *
 * ### Register Map:
 *
 * | Address | Name              | Default Value | Description                                         | Type   | Access     |
 * | --------|------------------ |---------------|-----------------------------------------------------|--------|----------- |
 * | 0x2700  | Snapshot capacity | 2             | Number of available snapshot slots, read-only       | uint32 | read only  |
 * | 0x2701  | Default snapshot  | 0             | Snapshot to load on system startup                  | uint32 | read write |
 * | 0x2702  | Error system      | 0             | ID of system which caused the last snapshot error   | uint8  | read only  |
 * | 0x2703  | Error register    | 0             | ID of register which caused the last snapshot error | uint8  | read only  |
 * | 0x2704  | Error value       | 0             | ID of value which caused the last snapshot error    | uint32 | read only  |
    """

    def __init__(self, board=None):
        self.sys_id = 0x27
        self._readonly = False

        self.snapshot_capacity = {'id': self.sys_id << 8 | 0x00,
                                  'type': int,
                                  'unit': None,
                                  'range': None,
                                  'default': False,
                                  'value': False}
        self.default_snapshot = {'id': self.sys_id << 8 | 0x01,
                                 'type': int,
                                 'unit': None,
                                 'range': [0, 7],
                                 'default': False,
                                 'value': False}
        self.error_system =  {'id': self.sys_id << 8 | 0x02,
                                  'type': int,
                                  'unit': None,
                                  'range': None,
                                  'default': False,
                                  'value': False}
        self.error_register =  {'id': self.sys_id << 8 | 0x03,
                                  'type': int,
                                  'unit': None,
                                  'range': None,
                                  'default': False,
                                  'value': False}
        self.error_value =  {'id': self.sys_id << 8 | 0x04,
                                  'type': int,
                                  'unit': None,
                                  'range': None,
                                  'default': False,
                                  'value': False}


        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    ## Saves actual configuration of the driver into memory available slot. (all register values) Nubmer of available
    # slots can be obtained by GetSnapShotCapacity method. Index 0 is reserved for factory settings and cannot be
    # overwritten. This configuration can then be loaded by LoadSnapshot method. Snapshot can also be configured as
    # startup snapshot with SetDefaultSnapShot method, driver will then start up with this configuration.
    def SaveSnapshot(self, index):
        self._board.save_snapshot(index)

    ## Loads the saved snapshot (configuration) into driver. Snapshot with index 0 contains factory settings and can be
    # used to reset the driver to factory default configuration.
    def LoadSnapshot(self, index):
        self._board.load_snapshot(index)

    ## Gets number of available snapshots slots in memory.
    def GetSnapShotCapacity(self):
        return self.get_register('snapshot_capacity')

    ## Gets the index of the default (startup) snapshot.
    def GetDefaultSnapShot(self):
        return self.get_register('default_snapshot')

    ## Sets the index of the default (startup) snapshot. Driver will start with this configuration on the next power
    # startup.
    def SetDefaultSnapShot(self, value):
        return self.set_register('default_snapshot', value)

    ## Gets the ID of system which caused the last snapshot error. Used for debugging of the configuration.
    def GetErrorSystem(self):
        return self.get_register('error_system')

    ## Gets the ID of register which caused the last snapshot error. Used for debugging of the configuration.
    def GetErrorRegister(self):
        return self.get_register('error_register')

    ## Gets the value which caused the last snapshot error. Used for debugging of the configuration.
    def GetErrorValue(self):
        return self.get_register('error_value')


class ADCcontrol(System):
    r"""
The ADC control is controling external multichannel DAC device.
DAC control System ID: 0x38

+---------------------+---------------+-------------+----------+--------------+---------------+--------------------+
| Register Name       | Id            | Type        | Unit     | Range        | Default       | Comment            |
+=====================+================+=============+==========+==============+===============+====================+
| ADC value           | 0-4            | uint 32-bit | bit/Volt | 0 to 5.5     |               |                    |
+---------------------+----------------+-------------+----------+--------------+---------------+--------------------+

    """

    @staticmethod
    def help():
        print(ADCcontrol.__doc__)

    def __init__(self, board=None):
        self.sys_id = 0x38
        self._readonly = False
        self.ADC_CHANNEL_NBR = 4
        self.UNIT_BITS    = 0
        self.UNIT_VOLTAGE = 1
        # self.UNIT_CURRENT = 2
        # self.unit_txt = ['bit', 'V', 'mA']
        self.unit_txt = ['bit', 'V']

        self.adcUnits = {'id': self.sys_id << 8 | 0x07,
                        'type': int,
                        'unit': None,
                        'range': [0, 2],
                        'default': None,
                        'value': None}

        # define "list" of registers of certain number - name approach
        for reg_index in range(self.ADC_CHANNEL_NBR):
            self.__dict__['unitCoeff_' + str('{0:02d}'.format(reg_index))] = {
                        'name': 'unitCoeff_'+str(reg_index),
                        'id': self.sys_id << 8 | 0x08 + reg_index,
                        'type': float,
                        'unit': None,
                        'range': None,
                        'default': None,
                        'value': None}

        # define "list" of registers of certain number - name approach
        for reg_index in range(self.ADC_CHANNEL_NBR):
            self.__dict__['adc_value_' + str('{0:02d}'.format(reg_index))] = {
                        'name': 'adc_value_'+str(reg_index),
                        'id': self.sys_id << 8 | 0x10 + reg_index,
                        'type': float,
                        'unit': None,
                        'range': None,
                        'default': None,
                        'value': None}


        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    def GetADCvalue(self, adc_channel, units):
        response = []
        if adc_channel < self.ADC_CHANNEL_NBR:
            raw_data = self.get_register_id(self.adc_value_00['id'] + adc_channel)
            if units ==  self.UNIT_BITS:
                response.append(struct.unpack(ENDIAN + 'i', bytes(raw_data))[0])
            else:
                response.append(struct.unpack(ENDIAN+'f', bytes(raw_data))[0])
            return response[0]
        else:
            warn("ADC channel index out of limit", RuntimeWarning)


class DACcontrol(System):
    r"""
The DAC control is controling external multichannel DAC device.
DAC control System ID: 0x39

+---------------------+---------------+-------------+----------+--------------+---------------+--------------------+
| Register Name       | Id            | Type        | Unit     | Range        | Default       | Comment            |
+=====================+================+=============+==========+==============+===============+====================+
| Setpoint            | 0-4            | uint 32-bit | Volt     | 0 to 5.5     |               |                    |
+---------------------+----------------+-------------+----------+--------------+---------------+--------------------+
| Setpoint            | 8-12           | uint 32-bit | miliAmps | 0 to 80      |               |                    |
+---------------------+----------------+-------------+----------+--------------+---------------+--------------------+

    """

    @staticmethod
    def help():
        print(DACcontrol.__doc__)

    def __init__(self, board=None):
        self.sys_id = 0x39
        self._readonly = False
        self.DAC_CHANNEL_NBR = 4
        self.UNIT_BITS    = 0
        self.UNIT_VOLTAGE = 1
        self.UNIT_CURRENT = 2
        self.unit_txt = ['bit', 'V', 'mA']

        self.dacUnits = {'id': self.sys_id << 8 | 0x07,
                        'type': int,
                        'unit': None,
                        'range': [0, 2],
                        'default': None,
                        'value': None}

        # define "list" of registers of certain number - name approach
        for reg_index in range(self.DAC_CHANNEL_NBR):
            self.__dict__['unitCoeff_' + str('{0:01d}'.format(reg_index))] = {
                        'name': 'unitCoeff_'+str(reg_index),
                        'id': self.sys_id << 8 | 0x08 + reg_index,
                        'type': float,
                        'unit': None,
                        'range': None,
                        'default': None,
                        'value': None}

        # define "list" of registers of certain number - name approach
        for reg_index in range(self.DAC_CHANNEL_NBR):
            self.__dict__['setpoint_' + str('{0:01d}'.format(reg_index))] = {
                        'name': 'setpoint_'+str(reg_index),
                        'id': self.sys_id << 8 | 0x10 + reg_index,
                        'type': float,
                        'unit': None,
                        'range': None,
                        'default': None,
                        'value': None}


        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    def SetDACvalue(self, dac_channel, setpoint):
        if dac_channel < self.DAC_CHANNEL_NBR:
            # calculate register id from parameters
            return self.set_register('setpoint_' + str(dac_channel), setpoint)
        else:
            warn("DAC channel index out of limit", RuntimeWarning)

    def GetDACvalue(self, dac_channel):

        if dac_channel < self.DAC_CHANNEL_NBR:
            return self.get_register('setpoint_' + str(dac_channel))
        else:
            warn("DAC channel index out of limit", RuntimeWarning)

    def GetDACbits(self, dac_channel):
        response = []
        if dac_channel < self.DAC_CHANNEL_NBR:
            raw_data = self.get_register_id(self.setpoint_0['id'] + dac_channel)
            response.append(struct.unpack(ENDIAN+'i', bytes(raw_data))[0])
            return response[0]
        else:
            warn("DAC channel index out of limit", RuntimeWarning)

    def SetDACbits(self, dac_channel, setpoint):
        if dac_channel < self.DAC_CHANNEL_NBR:
            dac_address = self.setpoint_00['id'] + dac_channel
            return self.set_register_id(dac_address, setpoint, int)
        else:
            warn("DAC channel index out of limit", RuntimeWarning)




