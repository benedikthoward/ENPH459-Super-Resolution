from .ClassAbstracts import ControlStage
from ..tools.systems_registers_tools import is_valid_channel


class CurrentFeedThrough(ControlStage):
    r"""
Control Mode Channel - Offset and Scaling
System ID: 0xB0 through 0xB7

+---------------------+------+-------------+--------------------+-------------+---------+------------------------+
| Register Name       | Id   | Type        | Unit               | Range       | Default | Comment                |
+=====================+======+=============+====================+=============+=========+========================+
|feed_through_enabled | 0x00 |             | None               |             | 0       |                        |
+---------------------+------+-------------+--------------------+-------------+---------+------------------------+

    """

    @staticmethod
    def help():
        print(CurrentFeedThrough.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0xB0 | channel
        self._readonly = False

        self.feed_through_enabled = {'id': self.sys_id << 8 | 0x00,
                                     'type': bool,
                                     'unit': 'Hz',
                                     'range': [True, False],
                                     'default': 0,
                                     'value': 0}
        ControlStage.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')


class Stop(ControlStage):
    r"""
Control Mode Channel -
System ID: 0xB4

+---------------------+------+-------------+--------------------+-------------+---------+------------------------+
| Register Name       | Id   | Type        | Unit               | Range       | Default | Comment                |
+=====================+======+=============+====================+=============+=========+========================+
| |  |             |                |             |        |                        |
+---------------------+------+-------------+--------------------+-------------+---------+------------------------+

    """

    @staticmethod
    def help():
        print(Stop.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0xB4 | channel
        self._readonly = False

        ControlStage.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

# control mode
class OFPID(ControlStage):
    """
Control Mode Channel - OF PID Control (with/without Temperature Compensation)
System ID: 0xB8 through 0xBf

+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| Register Name      | Id   | Type        | Unit | Range | Default | Comment                                          |
+====================+======+=============+======+=======+=========+==================================================+
|adaptive_pid_enabled| 0x00 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| kp                 | 0x01 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| ki                 | 0x02 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| kd                 | 0x03 |uint 32-bit  |bool  | T/F   | 1       |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| min_output         | 0x03 |float 32-bit |None  |       |         | If PID output reaches this, it is clamped to this|
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| max_output         | 0x04 |float 32-bit |None  |       |         | If PID output reaches this, it is clamped to this|
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| min_integral       | 0x05 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| max_integral       | 0x06 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| ap                 | 0x07 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| bp                 | 0x08 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| ai                 | 0x09 |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| bi                 | 0x0a |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| ad                 | 0x0b |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
| bd                 | 0x0c |float 32-bit |None  |       |         |                                                  |
+--------------------+------+-------------+------+-------+---------+--------------------------------------------------+
    """

    # TODO: update these registers
    @staticmethod
    def help():
        print(OFPID.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0xB8 | channel
        self._readonly = False

        self.adaptive_pid_enabled = {'id': self.sys_id << 8 | 0x00,
                                     'type': bool,
                                     'unit': None,
                                     'range': [True, False],
                                     'default': 1,
                                     'value': 1}
        self.kp = {'id': self.sys_id << 8 | 0x01,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 20.0,
                   'value': 20.0}
        self.ki = {'id': self.sys_id << 8 | 0x02,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 0.03,
                   'value': 0.03}
        self.kd = {'id': self.sys_id << 8 | 0x03,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 800.0,
                   'value': 800.0}
        self.min_output = {'id': self.sys_id << 8 | 0x04,
                           'type': float,
                           'unit': None,
                           'range': None,
                           'default': -1.0,
                           'value': -1.0}
        self.max_output = {'id': self.sys_id << 8 | 0x05,
                           'type': float,
                           'unit': None,
                           'range': None,
                           'default': 1.0,
                           'value': 1.0}
        self.min_integral = {'id': self.sys_id << 8 | 0x06,
                             'type': float,
                             'unit': None,
                             'range': None,
                             'default': 0,
                             'value': 0}
        self.max_integral = {'id': self.sys_id << 8 | 0x07,
                             'type': float,
                             'unit': None,
                             'range': None,
                             'default': 0,
                             'value': 0}
        self.setpoint = {'id': self.sys_id << 8 | 0x08,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 0,
                   'value': 0}
        self.ap = {'id': self.sys_id << 8 | 0x09,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 40.0,
                   'value': 40.0}
        self.bp = {'id': self.sys_id << 8 | 0x0a,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 20.0,
                   'value': 20.0}
        self.cp = {'id': self.sys_id << 8 | 0x0b,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 20.0,
                   'value': 20.0}
        self.ai = {'id': self.sys_id << 8 | 0x0c,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 0.06,
                   'value': 0.06}
        self.bi = {'id': self.sys_id << 8 | 0x0d,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 0.03,
                   'value': 0.03}
        self.ci = {'id': self.sys_id << 8 | 0x0e,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 0.03,
                   'value': 0.03}
        self.ad = {'id': self.sys_id << 8 | 0x0f,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 8000.0,
                   'value': 8000.0}
        self.bd = {'id': self.sys_id << 8 | 0x10,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 8000.0,
                   'value': 8000.0}
        self.cd = {'id': self.sys_id << 8 | 0x11,
                   'type': float,
                   'unit': None,
                   'range': None,
                   'default': 800.0,
                   'value': 800.0}
        self.gain_scheduling = {'id': self.sys_id << 8 | 0x12,
                             'type': float,
                             'unit': None,
                             'range': None,
                             'default': 0,
                             'value': 0}
        self.dfilter_enabled = {'id': self.sys_id << 8 | 0x13,
                             'type': bool,
                             'unit': None,
                             'range': None,
                             'default': True,
                             'value': True}
        self.dfilter_cutoff = {'id': self.sys_id << 8 | 0x14,
                             'type': float,
                             'unit': None,
                             'range': None,
                             'default': 800,
                             'value': 800}
        self.reset_integral = {'id': self.sys_id << 8 | 0x15,
                               'type': bool,
                               'unit': None,
                               'range': None,
                               'default': False,
                               'value': False}
        self.disable_sensor_input = {'id': self.sys_id << 8 | 0x16,
                               'type': bool,
                               'unit': None,
                               'range': None,
                               'default': False,
                               'value': False}
        self.output = {'id': self.sys_id << 8 | 0x17,
                               'type': float,
                               'unit': None,
                               'range': None,
                               'default': False,
                               'value': False}
        self.pid_disabled = {'id': self.sys_id << 8 | 0x18,
                             'type': bool,
                             'unit': None,
                             'range': None,
                             'default': False,
                             'value': False}

        ControlStage.__init__(self, channel, board)
        self.name = self.__class__.__name__

